package org.xiaojian999.superpowers;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xiaojian999.superpowers.network.PayloadRegistry;

import java.util.Locale;

public class Glungus implements ModInitializer {
    public static final String MOD_ID = "glungus";
    private static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModEntities.register();
        // Auto-generates and registers all C2S/S2C payloads if necessary.
        // - Annotation-driven (@AutoPayload) and reflection-based convention (ID+CODEC)
        // - Bidirectional GenericPayload fallback for dynamic features without a dedicated class
        // - Idempotent: safe if a payload was already registered manually elsewhere
        PayloadRegistry.registerBuiltins();
        PowerManager.initialize();
        if (isDevBuild()) {
            LOGGER.warn("Running Glungus developer build {} — this build is unstable and not for public release.", getVersion());
        }
    }

    /**
     * Returns the resolved mod version string as declared in fabric.mod.json
     * (e.g. "1.0-SNAPSHOT" for dev builds, "1.0.0" for releases).
     */
    public static String getVersion() {
        return FabricLoader.getInstance().getModContainer(MOD_ID)
                .map(c -> c.getMetadata().getVersion().getFriendlyString())
                .orElse("unknown");
    }

    /**
     * Developer builds are identified by version suffixes such as
     * {@code -SNAPSHOT}, {@code -dev}, {@code -alpha}, {@code -beta},
     * {@code -rc}, {@code -pre}, or any hyphenated pre-release marker.
     * Also returns true when running in Fabric's development environment
     * (IDE / runClient) even if version looks like a release.
     */
    public static boolean isDevBuild() {
        // Fabric dev env (loom runClient) counts as dev even if version was overwritten
        if (FabricLoader.getInstance().isDevelopmentEnvironment()) {
            return true;
        }
        String v = getVersion().toLowerCase(Locale.ROOT);
        if (v.equals("unknown")) {
            return false;
        }
        return v.contains("snapshot")
                || v.contains("dev")
                || v.contains("alpha")
                || v.contains("beta")
                || v.contains("rc")
                || v.contains("pre")
                || v.contains("nightly")
                || v.contains("-"); // any hyphenated pre-release (e.g. 1.0-1, 1.2.0-rc1)
    }
}
