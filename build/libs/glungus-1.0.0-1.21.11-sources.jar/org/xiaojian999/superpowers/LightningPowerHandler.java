package org.xiaojian999.superpowers;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1675;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Lightning powers: chain lightning, targeted strikes, and the Storm Form ultimate. */
final class LightningPowerHandler {
    private static final double LIGHTNING_BEAM_RANGE = 20.0D;
    private static final float LIGHTNING_BEAM_DAMAGE = 6.0F;
    private static final double LIGHTNING_BEAM_CHAIN_RADIUS = 6.0D;
    private static final int LIGHTNING_BEAM_MAX_TARGETS = 5;
    private static final double LIGHTNING_BEAM_CHAIN_DAMAGE_LOSS = 0.2D;
    private static final int LIGHTNING_BEAM_COOLDOWN = 60;
    private static final double LIGHTNING_STRIKE_RANGE = 40.0D;
    private static final float LIGHTNING_STRIKE_AOE_DAMAGE = 4.0F;
    private static final double LIGHTNING_STRIKE_AOE_RADIUS = 3.5D;
    private static final int LIGHTNING_STRIKE_COOLDOWN = 120;
    private static final int LIGHTNING_FORM_DURATION = 600;
    private static final int LIGHTNING_FORM_COOLDOWN = 600;
    private static final double LIGHTNING_FORM_PARTICLE_RADIUS = 1.5D;
    private static final double LIGHTNING_FORM_TOUCH_RADIUS = 2.0D;
    private static final float BIG_LIGHTNING_DAMAGE = 10.0F;
    private static final int LIGHTNING_FORM_STRIKE_COOLDOWN = 20;

    private static final Map<SlotKey, Integer> LIGHTNING_FORM_TICKS = new HashMap<>();
    private static final Set<UUID> CLIENT_LIGHTNING_FORM_PLAYERS = new HashSet<>();
    private static final Map<UUID, Integer> STORM_STRIKE_COOLDOWNS = new HashMap<>();

    private LightningPowerHandler() {
    }

    static int fireChainLightning(class_3222 player, SlotKey slotKey) {
        int remainingTicks = PowerCooldowns.beamRemaining(slotKey);
        if (remainingTicks > 0) {
            PowerManager.sendPowerStatus(player);
            PowerManager.sendCooldownMessage(player, "Chain Lightning", remainingTicks);
            return 0;
        }

        class_3218 world = (class_3218) player.method_51469();
        class_243 start = player.method_5836(1.0F);
        class_243 direction = player.method_5828(1.0F).method_1029();
        class_243 maximumEnd = start.method_1019(direction.method_1021(LIGHTNING_BEAM_RANGE));

        class_3965 blockHit = world.method_17742(new class_3959(
                start,
                maximumEnd,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                player
        ));
        class_238 searchBox = player.method_5829().method_18804(direction.method_1021(LIGHTNING_BEAM_RANGE)).method_1014(1.0D);
        class_3966 entityHit = class_1675.method_18075(
                player,
                start,
                maximumEnd,
                searchBox,
                entity -> !entity.method_7325() && entity.method_5863(),
                LIGHTNING_BEAM_RANGE * LIGHTNING_BEAM_RANGE
        );

        class_243 beamEnd = blockHit.method_17783() == class_239.class_240.field_1333 ? maximumEnd : blockHit.method_17784();
        class_1309 primaryTarget = null;
        if (entityHit != null
                && (blockHit.method_17783() == class_239.class_240.field_1333
                || entityHit.method_17784().method_1025(start) <= beamEnd.method_1025(start))) {
            beamEnd = entityHit.method_17784();
            if (entityHit.method_17782() instanceof class_1309 livingTarget && livingTarget.method_5805()) {
                primaryTarget = livingTarget;
            }
        }

        spawnLightningBeamParticles(world, start, beamEnd);
        world.method_43128(
                null,
                beamEnd.field_1352,
                beamEnd.field_1351,
                beamEnd.field_1350,
                class_3417.field_14956,
                class_3419.field_15248,
                1.0F,
                1.3F
        );

        int struck = 0;
        if (primaryTarget != null) {
            Set<UUID> hit = new HashSet<>();
            class_1309 current = primaryTarget;
            double damage = LIGHTNING_BEAM_DAMAGE;
            while (current != null && struck < LIGHTNING_BEAM_MAX_TARGETS) {
                hit.add(current.method_5667());
                struck++;
                current.method_64397(world, world.method_48963().method_48802(player), (float) damage);

                class_1309 next = findChainTarget(world, player, current, hit);
                if (next != null) {
                    class_243 from = current.method_73189().method_1031(0.0D, current.method_17682() * 0.5D, 0.0D);
                    class_243 to = next.method_73189().method_1031(0.0D, next.method_17682() * 0.5D, 0.0D);
                    spawnLightningArcParticles(world, from, to);
                    world.method_43128(
                            null,
                            to.field_1352,
                            to.field_1351,
                            to.field_1350,
                            class_3417.field_14956,
                            class_3419.field_15248,
                            1.0F - struck * 0.12F,
                            1.4F
                    );
                }
                current = next;
                damage *= 1.0D - LIGHTNING_BEAM_CHAIN_DAMAGE_LOSS;
            }
        }

        PowerCooldowns.setBeam(slotKey, LIGHTNING_BEAM_COOLDOWN);
        PowerManager.sendPowerStatus(player);
        if (struck > 0) {
            player.method_7353(class_2561.method_43470(
                    "Chain Lightning struck " + struck + " " + (struck == 1 ? "enemy" : "enemies") + "!"
            ), true);
        } else {
            player.method_7353(class_2561.method_43470("Chain Lightning — no target in range."), true);
        }
        return 1;
    }

    private static class_1309 findChainTarget(
            class_3218 world,
            class_3222 player,
            class_1309 source,
            Set<UUID> hit
    ) {
        class_238 area = source.method_5829().method_1014(LIGHTNING_BEAM_CHAIN_RADIUS);
        List<class_1297> candidates = world.method_8333(
                player,
                area,
                entity -> entity instanceof class_1309 livingEntity
                        && livingEntity.method_5805()
                        && !entity.method_7325()
                        && !hit.contains(entity.method_5667())
        );
        class_1309 nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (class_1297 candidate : candidates) {
            double distance = candidate.method_5858(source);
            if (distance > LIGHTNING_BEAM_CHAIN_RADIUS * LIGHTNING_BEAM_CHAIN_RADIUS) {
                continue;
            }
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearest = (class_1309) candidate;
            }
        }
        return nearest;
    }

    private static void spawnLightningBeamParticles(class_3218 world, class_243 start, class_243 end) {
        class_243 beam = end.method_1020(start);
        double length = beam.method_1033();
        if (length == 0.0D) {
            return;
        }

        class_243 direction = beam.method_1029();
        for (double distance = 0.0D; distance <= length; distance += 0.4D) {
            class_243 position = start.method_1019(direction.method_1021(distance));
            world.method_65096(
                    class_2398.field_29644,
                    position.field_1352,
                    position.field_1351,
                    position.field_1350,
                    2,
                    0.08D,
                    0.08D,
                    0.08D,
                    0.02D
            );
            if ((int) (distance * 10.0D) % 12 == 0) {
                world.method_65096(class_2398.field_28479, position.field_1352, position.field_1351, position.field_1350, 1, 0.05D, 0.05D, 0.05D, 0.0D);
            }
        }
        world.method_65096(
                class_2398.field_29644,
                end.field_1352,
                end.field_1351,
                end.field_1350,
                14,
                0.4D,
                0.4D,
                0.4D,
                0.06D
        );
    }

    private static void spawnLightningArcParticles(class_3218 world, class_243 from, class_243 to) {
        class_243 delta = to.method_1020(from);
        double length = delta.method_1033();
        if (length == 0.0D) {
            return;
        }
        int segments = Math.max(4, (int) (length * 2.0D));
        class_243 side = new class_243(-delta.field_1350, 0.0D, delta.field_1352);
        boolean canOffset = side.method_1027() > 1.0E-4D;
        if (canOffset) {
            side = side.method_1029();
        }
        double arcHeight = Math.min(1.5D, length * 0.2D);
        for (int segment = 0; segment <= segments; segment++) {
            double t = (double) segment / segments;
            class_243 position = from.method_35590(to, t);
            double offset = canOffset ? Math.sin(segment * 1.7D) * 0.35D : 0.0D;
            double lift = Math.sin(t * Math.PI) * arcHeight;
            world.method_65096(
                    class_2398.field_29644,
                    position.field_1352 + side.field_1352 * offset,
                    position.field_1351 + lift,
                    position.field_1350 + side.field_1350 * offset,
                    2,
                    0.07D,
                    0.07D,
                    0.07D,
                    0.02D
            );
        }
        world.method_65096(
                class_2398.field_29644,
                to.field_1352,
                to.field_1351,
                to.field_1350,
                12,
                0.35D,
                0.35D,
                0.35D,
                0.05D
        );
    }

    static int summonLightningStrike(class_3222 player, SlotKey slotKey) {
        int remainingTicks = PowerCooldowns.secondPowerRemaining(slotKey);
        if (remainingTicks > 0) {
            PowerManager.sendPowerStatus(player);
            PowerManager.sendCooldownMessage(player, "Lightning Strike", remainingTicks);
            return 0;
        }

        class_3218 world = (class_3218) player.method_51469();
        class_243 start = player.method_5836(1.0F);
        class_243 direction = player.method_5828(1.0F).method_1029();
        class_243 maximumEnd = start.method_1019(direction.method_1021(LIGHTNING_STRIKE_RANGE));
        class_3965 blockHit = world.method_17742(new class_3959(
                start,
                maximumEnd,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                player
        ));
        if (blockHit.method_17783() != class_239.class_240.field_1332) {
            player.method_7353(class_2561.method_43470("Lightning Strike — aim at a block."), true);
            return 0;
        }

        class_243 strikePos = blockHit.method_17784();
        class_1538 bolt = new class_1538(class_1299.field_6112, world);
        bolt.method_5814(strikePos.field_1352, strikePos.field_1351, strikePos.field_1350);
        world.method_8649(bolt);

        // Nearby enemies (never the caster) take a small amount of extra damage.
        class_238 area = new class_238(
                strikePos.field_1352 - LIGHTNING_STRIKE_AOE_RADIUS,
                strikePos.field_1351 - LIGHTNING_STRIKE_AOE_RADIUS,
                strikePos.field_1350 - LIGHTNING_STRIKE_AOE_RADIUS,
                strikePos.field_1352 + LIGHTNING_STRIKE_AOE_RADIUS,
                strikePos.field_1351 + LIGHTNING_STRIKE_AOE_RADIUS,
                strikePos.field_1350 + LIGHTNING_STRIKE_AOE_RADIUS
        );
        List<class_1297> targets = world.method_8333(
                player,
                area,
                entity -> entity instanceof class_1309 livingEntity
                        && livingEntity.method_5805()
                        && !entity.method_7325()
        );
        int hit = 0;
        for (class_1297 entity : targets) {
            if (entity.method_5707(strikePos) > LIGHTNING_STRIKE_AOE_RADIUS * LIGHTNING_STRIKE_AOE_RADIUS) {
                continue;
            }
            entity.method_64397(world, world.method_48963().method_48802(player), LIGHTNING_STRIKE_AOE_DAMAGE);
            hit++;
        }

        world.method_65096(
                class_2398.field_29644,
                strikePos.field_1352,
                strikePos.field_1351 + 1.0D,
                strikePos.field_1350,
                30,
                1.5D,
                1.5D,
                1.5D,
                0.08D
        );
        PowerCooldowns.setSecondPower(slotKey, LIGHTNING_STRIKE_COOLDOWN);
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("Lightning Strike — " + hit + " nearby enemies zapped!"), true);
        return 1;
    }

    static int startForm(class_3222 player, SlotKey slotKey) {
        // Only one storm form per player; end a form started from the other slot first.
        List<SlotKey> otherForms = LIGHTNING_FORM_TICKS.keySet().stream()
                .filter(key -> key.playerUuid().equals(player.method_5667()) && !key.equals(slotKey))
                .toList();
        for (SlotKey other : otherForms) {
            endForm(player, other);
        }

        LIGHTNING_FORM_TICKS.put(slotKey, LIGHTNING_FORM_DURATION);
        player.method_31549().field_7478 = true;
        player.method_31549().field_7479 = true;
        player.method_7355();
        player.method_5648(true);
        class_3218 world = (class_3218) player.method_51469();
        broadcastFormState(world, player.method_5667(), true);
        world.method_43128(
                null,
                player.method_23317(),
                player.method_23318(),
                player.method_23321(),
                class_3417.field_14865,
                class_3419.field_15248,
                1.6F,
                1.1F
        );
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470(
                "Storm Form active — you are living lightning for 30s! Touch enemies to fry them."
        ), true);
        return 1;
    }

    static void endForm(class_3222 player, SlotKey slotKey) {
        if (LIGHTNING_FORM_TICKS.remove(slotKey) == null) {
            return;
        }

        if (player.method_51469() instanceof class_3218 endWorld) {
            broadcastFormState(endWorld, player.method_5667(), false);
        }
        if (!player.method_68878() && !player.method_7325()) {
            player.method_31549().field_7478 = false;
            player.method_31549().field_7479 = false;
            player.method_7355();
        }
        player.method_5648(false);
        PowerCooldowns.setUltimate(slotKey, LIGHTNING_FORM_COOLDOWN);
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("Storm Form ended. Cooldown: 30s."), true);
    }

    static void disableForm(class_3222 player) {
        List<SlotKey> activeForms = LIGHTNING_FORM_TICKS.keySet().stream()
                .filter(key -> key.playerUuid().equals(player.method_5667()))
                .toList();
        for (SlotKey slotKey : activeForms) {
            endForm(player, slotKey);
        }
    }

    static boolean isFormActive(UUID playerUuid) {
        return LIGHTNING_FORM_TICKS.keySet().stream()
                .anyMatch(key -> key.playerUuid().equals(playerUuid));
    }

    static boolean isFormActive(SlotKey slotKey) {
        return LIGHTNING_FORM_TICKS.containsKey(slotKey);
    }

    static Integer getFormRemaining(SlotKey slotKey) {
        return LIGHTNING_FORM_TICKS.get(slotKey);
    }

    static boolean isClientFormActive(UUID playerUuid) {
        return CLIENT_LIGHTNING_FORM_PLAYERS.contains(playerUuid);
    }

    static void setClientFormActive(UUID playerUuid, boolean active) {
        if (active) {
            CLIENT_LIGHTNING_FORM_PLAYERS.add(playerUuid);
        } else {
            CLIENT_LIGHTNING_FORM_PLAYERS.remove(playerUuid);
        }
    }

    static void sendActiveFormStates(class_3222 joiningPlayer, MinecraftServer server) {
        // A player joining mid-form still needs to hide the transformed player.
        for (SlotKey key : LIGHTNING_FORM_TICKS.keySet()) {
            if (server.method_3760().method_14602(key.playerUuid()) != null) {
                ServerPlayNetworking.send(joiningPlayer, new LightningFormStatePayload(key.playerUuid(), true));
            }
        }
    }

    private static void broadcastFormState(class_3218 world, UUID playerUuid, boolean active) {
        LightningFormStatePayload payload = new LightningFormStatePayload(playerUuid, active);
        for (class_3222 player : world.method_8503().method_3760().method_14571()) {
            ServerPlayNetworking.send(player, payload);
        }
    }

    static void tickPlayer(class_3222 player) {
        if (isFormActive(player.method_5667()) && !player.method_31549().field_7478) {
            player.method_31549().field_7478 = true;
            player.method_7355();
        }
    }

    static void tickServer(MinecraftServer server) {
        // Iterate a snapshot because endForm removes from the map.
        for (SlotKey slotKey : List.copyOf(LIGHTNING_FORM_TICKS.keySet())) {
            class_3222 player = server.method_3760().method_14602(slotKey.playerUuid());
            if (player == null) {
                LIGHTNING_FORM_TICKS.remove(slotKey);
                continue;
            }
            int remaining = LIGHTNING_FORM_TICKS.getOrDefault(slotKey, 0) - 1;
            if (remaining <= 0) {
                endForm(player, slotKey);
                continue;
            }
            LIGHTNING_FORM_TICKS.put(slotKey, remaining);
            if (player.method_51469() instanceof class_3218 world) {
                tickStormForm(world, player, slotKey);
            }
        }

        STORM_STRIKE_COOLDOWNS.entrySet().removeIf(entry -> {
            int remaining = entry.getValue() - 1;
            if (remaining <= 0) {
                return true;
            }
            entry.setValue(remaining);
            return false;
        });
    }

    private static void tickStormForm(class_3218 world, class_3222 player, SlotKey slotKey) {
        class_243 center = player.method_73189().method_1031(0.0D, player.method_17682() * 0.5D, 0.0D);
        world.method_65096(
                class_2398.field_29644,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                14,
                LIGHTNING_FORM_PARTICLE_RADIUS,
                LIGHTNING_FORM_PARTICLE_RADIUS,
                LIGHTNING_FORM_PARTICLE_RADIUS,
                0.02D
        );
        if (world.field_9229.method_43048(3) == 0) {
            world.method_65096(
                    class_2398.field_28479,
                    center.field_1352,
                    center.field_1351,
                    center.field_1350,
                    4,
                    LIGHTNING_FORM_PARTICLE_RADIUS * 0.6D,
                    LIGHTNING_FORM_PARTICLE_RADIUS * 0.6D,
                    LIGHTNING_FORM_PARTICLE_RADIUS * 0.6D,
                    0.01D
            );
        }

        class_238 area = player.method_5829().method_1014(LIGHTNING_FORM_TOUCH_RADIUS);
        List<class_1297> touching = world.method_8333(
                player,
                area,
                entity -> entity instanceof class_1309 livingEntity
                        && livingEntity.method_5805()
                        && !entity.method_7325()
        );
        for (class_1297 entity : touching) {
            if (player.method_5858(entity) > LIGHTNING_FORM_TOUCH_RADIUS * LIGHTNING_FORM_TOUCH_RADIUS) {
                continue;
            }
            if (STORM_STRIKE_COOLDOWNS.containsKey(entity.method_5667())) {
                continue;
            }
            strikeBigLightning(world, player, entity);
            STORM_STRIKE_COOLDOWNS.put(entity.method_5667(), LIGHTNING_FORM_STRIKE_COOLDOWN);
        }
    }

    private static void strikeBigLightning(class_3218 world, class_3222 owner, class_1297 target) {
        class_243 position = target.method_73189().method_1031(0.0D, target.method_17682() * 0.5D, 0.0D);
        BigLightningEntity bolt = new BigLightningEntity(ModEntities.BIG_LIGHTNING, world);
        bolt.method_5814(position.field_1352, position.field_1351, position.field_1350);
        world.method_8649(bolt);

        double radius = 3.0D;
        class_238 area = new class_238(
                position.field_1352 - radius,
                position.field_1351 - 3.0D,
                position.field_1350 - radius,
                position.field_1352 + radius,
                position.field_1351 + 3.0D,
                position.field_1350 + radius
        );
        List<class_1297> struck = world.method_8333(
                owner,
                area,
                entity -> entity instanceof class_1309 livingEntity
                        && livingEntity.method_5805()
                        && !entity.method_7325()
        );
        for (class_1297 entity : struck) {
            if (entity.method_5707(position) > radius * radius) {
                continue;
            }
            entity.method_64397(world, world.method_48963().method_48809(), BIG_LIGHTNING_DAMAGE);
        }

        world.method_43128(
                null,
                position.field_1352,
                position.field_1351,
                position.field_1350,
                class_3417.field_14956,
                class_3419.field_15248,
                2.0F,
                0.9F
        );
        world.method_65096(
                class_2398.field_29644,
                position.field_1352,
                position.field_1351,
                position.field_1350,
                30,
                1.5D,
                1.5D,
                1.5D,
                0.1D
        );
    }

    static void removePlayer(class_3222 player) {
        disableForm(player);
        CLIENT_LIGHTNING_FORM_PLAYERS.remove(player.method_5667());
    }

    static void clearAll() {
        LIGHTNING_FORM_TICKS.clear();
        CLIENT_LIGHTNING_FORM_PLAYERS.clear();
        STORM_STRIKE_COOLDOWNS.clear();
    }
}
