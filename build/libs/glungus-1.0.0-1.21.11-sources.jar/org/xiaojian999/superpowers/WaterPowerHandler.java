package org.xiaojian999.superpowers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_6908;

/** Water powers: the water cannon, the Tidal Wave, and the Water Meteor ultimate. */
final class WaterPowerHandler {
    private static final int WATER_CANNON_COOLDOWN = 300;
    private static final double WATER_CANNON_SPEED = 1.25D;
    private static final int WATER_CANNON_LIFETIME = 80;
    private static final double WATER_CANNON_PROJECTILE_SIZE = 1.4D;
    private static final double WATER_CANNON_BLAST_RADIUS = 5.0D;
    private static final float WATER_CANNON_DAMAGE = 18.0F;
    private static final int WATER_CANNON_CRATER_RADIUS = 4;
    private static final int WATER_CANNON_CRATER_DEPTH = 3;
    private static final int TIDAL_WAVE_COOLDOWN = 400;
    private static final double TIDAL_WAVE_SPEED = 0.8D;
    private static final double TIDAL_WAVE_RANGE = 24.0D;
    private static final int TIDAL_WAVE_DURATION = 30;
    private static final double TIDAL_WAVE_HALF_WIDTH = 4.5D;
    private static final double TIDAL_WAVE_HEIGHT = 5.0D;
    private static final float TIDAL_WAVE_DAMAGE = 18.0F;
    private static final double TIDAL_WAVE_KNOCKBACK = 3.0D;
    private static final int WATER_METEOR_COOLDOWN = 1200;
    private static final double WATER_METEOR_SPEED = 0.42D;
    private static final double WATER_METEOR_GRAVITY = 0.012D;
    private static final double WATER_METEOR_SEARCH_RADIUS = 12.0D;
    private static final double WATER_METEOR_SPAWN_HEIGHT = 24.0D;
    private static final int WATER_METEOR_LIFETIME = 180;
    private static final double WATER_METEOR_PROJECTILE_SIZE = 2.8D;
    private static final double WATER_METEOR_BLAST_RADIUS = 8.0D;
    private static final float WATER_METEOR_DAMAGE = 30.0F;
    private static final int WATER_METEOR_CRATER_RADIUS = 6;
    private static final int WATER_METEOR_CRATER_DEPTH = 4;

    private static final Map<class_3218, List<ActiveWaterProjectile>> ACTIVE_WATER_PROJECTILES = new HashMap<>();
    private static final Map<class_3218, List<ActiveTidalWave>> ACTIVE_TIDAL_WAVES = new HashMap<>();

    private WaterPowerHandler() {
    }

    static int fireWaterCannon(class_3222 player, SlotKey slotKey) {
        int remainingTicks = PowerCooldowns.beamRemaining(slotKey);
        if (remainingTicks > 0) {
            PowerManager.sendPowerStatus(player);
            PowerManager.sendCooldownMessage(player, "Water Cannon", remainingTicks);
            return 0;
        }

        class_3218 world = (class_3218) player.method_51469();
        class_243 direction = player.method_5828(1.0F).method_1029();
        class_243 position = player.method_5836(1.0F).method_1019(direction.method_1021(1.2D));
        ACTIVE_WATER_PROJECTILES.computeIfAbsent(world, ignored -> new ArrayList<>())
                .add(new ActiveWaterProjectile(
                        player.method_5667(),
                        position,
                        direction.method_1021(WATER_CANNON_SPEED),
                        0.0D,
                        WATER_CANNON_LIFETIME,
                        WATER_CANNON_PROJECTILE_SIZE,
                        false
                ));
        PowerCooldowns.setBeam(slotKey, WATER_CANNON_COOLDOWN);
        world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), class_3417.field_14810, class_3419.field_15248, 1.4F, 0.7F);
        player.method_7353(class_2561.method_43470("Water Cannon fired!"), true);
        PowerManager.sendPowerStatus(player);
        return 1;
    }

    static int startTidalWave(class_3222 player, SlotKey slotKey) {
        int remainingTicks = PowerCooldowns.secondPowerRemaining(slotKey);
        if (remainingTicks > 0) {
            PowerManager.sendPowerStatus(player);
            PowerManager.sendCooldownMessage(player, "Tidal Wave", remainingTicks);
            return 0;
        }
        if (!isNearOcean(player)) {
            player.method_7353(class_2561.method_43470("Tidal Wave requires an ocean within 8 blocks."), true);
            return 0;
        }

        class_3218 world = (class_3218) player.method_51469();
        class_243 look = player.method_5828(1.0F);
        class_243 direction = new class_243(look.field_1352, 0.0D, look.field_1350);
        if (direction.method_1027() < 0.0001D) {
            class_2350 facing = player.method_5735();
            direction = new class_243(facing.method_10148(), 0.0D, facing.method_10165());
        }
        direction = direction.method_1029();
        class_243 position = player.method_73189().method_1019(direction.method_1021(2.0D));
        ACTIVE_TIDAL_WAVES.computeIfAbsent(world, ignored -> new ArrayList<>())
                .add(new ActiveTidalWave(player.method_5667(), position, direction, TIDAL_WAVE_DURATION));
        PowerCooldowns.setSecondPower(slotKey, TIDAL_WAVE_COOLDOWN);
        world.method_43128(null, position.field_1352, position.field_1351, position.field_1350, class_3417.field_14810, class_3419.field_15248, 2.0F, 0.55F);
        player.method_7353(class_2561.method_43470("Tidal Wave unleashed!"), true);
        PowerManager.sendPowerStatus(player);
        return 1;
    }

    static void startWaterMeteor(class_3222 player, SlotKey slotKey) {
        class_3218 world = (class_3218) player.method_51469();
        class_243 target = findNearestEnemyTarget(player, world);
        if (target == null) {
            double angle = player.method_59922().method_43058() * Math.PI * 2.0D;
            double distance = Math.sqrt(player.method_59922().method_43058()) * WATER_METEOR_SEARCH_RADIUS;
            target = new class_243(
                    player.method_23317() + Math.cos(angle) * distance,
                    player.method_23318(),
                    player.method_23321() + Math.sin(angle) * distance
            );
        }
        double spawnY = target.field_1351 + WATER_METEOR_SPAWN_HEIGHT;
        class_243 position = new class_243(target.field_1352, spawnY, target.field_1350);
        ACTIVE_WATER_PROJECTILES.computeIfAbsent(world, ignored -> new ArrayList<>())
                .add(new ActiveWaterProjectile(
                        player.method_5667(),
                        position,
                        new class_243(0.0D, -WATER_METEOR_SPEED, 0.0D),
                        WATER_METEOR_GRAVITY,
                        WATER_METEOR_LIFETIME,
                        WATER_METEOR_PROJECTILE_SIZE,
                        true
                ));
        PowerCooldowns.setUltimate(slotKey, WATER_METEOR_COOLDOWN);
        world.method_43128(null, target.field_1352, spawnY, target.field_1350, class_3417.field_14810, class_3419.field_15248, 2.0F, 0.45F);
        player.method_7353(class_2561.method_43470("Water Meteor summoned — brace for impact!"), true);
    }

    private static boolean isNearOcean(class_3222 player) {
        class_3218 world = (class_3218) player.method_51469();
        class_2338 origin = player.method_24515();
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                if (dx * dx + dz * dz > 64) {
                    continue;
                }
                if (world.method_23753(origin.method_10069(dx, 0, dz)).method_40220(class_6908.field_36509)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static class_243 findNearestEnemyTarget(class_3222 player, class_3218 world) {
        class_238 searchBox = player.method_5829().method_1014(WATER_METEOR_SEARCH_RADIUS);
        List<class_1297> candidates = world.method_8333(
                player,
                searchBox,
                entity -> entity instanceof class_1309 livingEntity
                        && livingEntity.method_5805()
                        && !entity.method_7325()
        );
        class_1297 nearest = null;
        double nearestDistanceSquared = Double.MAX_VALUE;
        for (class_1297 candidate : candidates) {
            double distanceSquared = player.method_5858(candidate);
            if (distanceSquared > WATER_METEOR_SEARCH_RADIUS * WATER_METEOR_SEARCH_RADIUS) {
                continue;
            }
            if (distanceSquared < nearestDistanceSquared) {
                nearest = candidate;
                nearestDistanceSquared = distanceSquared;
            }
        }
        return nearest == null ? null : nearest.method_73189();
    }

    static void tick(class_3218 world) {
        tickWaterProjectiles(world);
        tickTidalWaves(world);
    }

    private static void tickWaterProjectiles(class_3218 world) {
        List<ActiveWaterProjectile> projectiles = ACTIVE_WATER_PROJECTILES.get(world);
        if (projectiles == null) {
            return;
        }

        for (int index = projectiles.size() - 1; index >= 0; index--) {
            ActiveWaterProjectile projectile = projectiles.get(index);
            class_3222 owner = world.method_8503().method_3760().method_14602(projectile.ownerUuid);
            if (owner == null || owner.method_51469() != world) {
                projectiles.remove(index);
                continue;
            }

            projectile.remainingTicks--;
            class_243 nextPosition = projectile.position.method_1019(projectile.velocity);
            class_3965 blockHit = world.method_17742(new class_3959(
                    projectile.position,
                    nextPosition,
                    class_3959.class_3960.field_17558,
                    class_3959.class_242.field_1348,
                    owner
            ));
            spawnWaterProjectileParticles(world, projectile);

            if (blockHit.method_17783() == class_239.class_240.field_1332) {
                impactWaterProjectile(world, projectile, blockHit.method_17784(), owner);
                projectiles.remove(index);
                continue;
            }

            projectile.position = nextPosition;
            projectile.velocity = projectile.velocity.method_1031(0.0D, -projectile.gravity, 0.0D);
            if (projectile.remainingTicks <= 0) {
                projectiles.remove(index);
            }
        }

        if (projectiles.isEmpty()) {
            ACTIVE_WATER_PROJECTILES.remove(world);
        }
    }

    private static void spawnWaterProjectileParticles(class_3218 world, ActiveWaterProjectile projectile) {
        class_243 position = projectile.position;
        int count = projectile.meteor ? 18 : 8;
        world.method_65096(class_2398.field_11202, position.field_1352, position.field_1351, position.field_1350, count,
                projectile.size, projectile.size, projectile.size, 0.08D);
        world.method_65096(class_2398.field_11247, position.field_1352, position.field_1351, position.field_1350, projectile.meteor ? 8 : 3,
                projectile.size * 0.7D, projectile.size * 0.7D, projectile.size * 0.7D, 0.04D);
    }

    private static void impactWaterProjectile(
            class_3218 world,
            ActiveWaterProjectile projectile,
            class_243 impactPosition,
            class_3222 owner
    ) {
        double blastRadius = projectile.meteor ? WATER_METEOR_BLAST_RADIUS : WATER_CANNON_BLAST_RADIUS;
        float damage = projectile.meteor ? WATER_METEOR_DAMAGE : WATER_CANNON_DAMAGE;
        class_238 area = new class_238(
                impactPosition.field_1352 - blastRadius,
                impactPosition.field_1351 - blastRadius,
                impactPosition.field_1350 - blastRadius,
                impactPosition.field_1352 + blastRadius,
                impactPosition.field_1351 + blastRadius,
                impactPosition.field_1350 + blastRadius
        );
        List<class_1297> targets = world.method_8333(owner, area, entity -> entity instanceof class_1309 livingEntity
                && livingEntity.method_5805() && !entity.method_7325());
        for (class_1297 entity : targets) {
            if (entity.method_5707(impactPosition) > blastRadius * blastRadius) {
                continue;
            }
            class_1309 target = (class_1309) entity;
            target.method_64397(world, world.method_48963().method_48802(owner), damage);
            class_243 away = target.method_73189().method_1020(impactPosition);
            double distance = away.method_1033();
            if (distance > 0.001D) {
                double force = projectile.meteor ? 2.4D : 1.2D;
                class_243 knockback = away.method_1021(force / distance);
                target.method_5762(knockback.field_1352, projectile.meteor ? 1.15D : 0.65D, knockback.field_1350);
                target.field_64356 = true;
            }
        }

        class_2338 center = class_2338.method_49638(impactPosition);
        if (projectile.meteor) {
            carveExplosionCrater(world, center, WATER_METEOR_CRATER_RADIUS, WATER_METEOR_CRATER_DEPTH, owner);
        } else {
            createWaterCrater(world, center, WATER_CANNON_CRATER_RADIUS, WATER_CANNON_CRATER_DEPTH, owner);
        }
        world.method_65096(class_2398.field_11221, impactPosition.field_1352, impactPosition.field_1351, impactPosition.field_1350, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        world.method_65096(class_2398.field_11202, impactPosition.field_1352, impactPosition.field_1351, impactPosition.field_1350, projectile.meteor ? 180 : 100,
                blastRadius * 0.6D, blastRadius * 0.35D, blastRadius * 0.6D, 0.15D);
        world.method_60511(null, impactPosition.field_1352, impactPosition.field_1351, impactPosition.field_1350,
                class_3417.field_15152, class_3419.field_15248, 2.2F, projectile.meteor ? 0.45F : 0.7F);
    }

    private static void carveExplosionCrater(
            class_3218 world,
            class_2338 center,
            int radius,
            int depth,
            class_3222 owner
    ) {
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                double horizontalDistance = Math.sqrt(x * x + z * z);
                if (horizontalDistance > radius) {
                    continue;
                }
                int columnDepth = Math.max(1, (int) Math.ceil((1.0D - horizontalDistance / radius) * depth));
                for (int y = -columnDepth; y <= 2; y++) {
                    class_2338 position = center.method_10069(x, y, z);
                    if (isBreakableCraterBlock(world.method_8320(position))) {
                        world.method_8651(position, false, owner);
                    }
                }
            }
        }
    }

    private static void createWaterCrater(
            class_3218 world,
            class_2338 center,
            int radius,
            int depth,
            class_3222 owner
    ) {
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                double horizontalDistance = Math.sqrt(x * x + z * z);
                if (horizontalDistance > radius) {
                    continue;
                }
                int columnDepth = Math.max(1, (int) Math.ceil((1.0D - horizontalDistance / radius) * depth));
                for (int y = -columnDepth; y <= 1; y++) {
                    class_2338 position = center.method_10069(x, y, z);
                    if (isBreakableCraterBlock(world.method_8320(position))) {
                        world.method_8651(position, false, owner);
                    }
                }
                for (int y = -columnDepth; y <= 1; y++) {
                    class_2338 position = center.method_10069(x, y, z);
                    if (world.method_8320(position).method_26215()) {
                        world.method_8652(position, class_2246.field_10382.method_9564(), class_2248.field_31036);
                    }
                }
            }
        }
    }

    private static boolean isBreakableCraterBlock(class_2680 state) {
        return !state.method_26215()
                && !state.method_27852(class_2246.field_9987)
                && !state.method_27852(class_2246.field_10499)
                && !state.method_27852(class_2246.field_10027)
                && !state.method_27852(class_2246.field_10613);
    }

    private static void tickTidalWaves(class_3218 world) {
        List<ActiveTidalWave> waves = ACTIVE_TIDAL_WAVES.get(world);
        if (waves == null) {
            return;
        }

        for (int index = waves.size() - 1; index >= 0; index--) {
            ActiveTidalWave wave = waves.get(index);
            class_3222 owner = world.method_8503().method_3760().method_14602(wave.ownerUuid);
            if (owner == null || owner.method_51469() != world) {
                waves.remove(index);
                continue;
            }

            wave.remainingTicks--;
            wave.position = wave.position.method_1019(wave.direction.method_1021(TIDAL_WAVE_SPEED));
            class_243 side = new class_243(-wave.direction.field_1350, 0.0D, wave.direction.field_1352);
            class_238 area = new class_238(
                    wave.position.field_1352 - TIDAL_WAVE_HALF_WIDTH,
                    wave.position.field_1351 - 2.0D,
                    wave.position.field_1350 - TIDAL_WAVE_HALF_WIDTH,
                    wave.position.field_1352 + TIDAL_WAVE_HALF_WIDTH,
                    wave.position.field_1351 + TIDAL_WAVE_HEIGHT,
                    wave.position.field_1350 + TIDAL_WAVE_HALF_WIDTH
            );
            List<class_1297> targets = world.method_8333(owner, area, entity -> entity instanceof class_1309 livingEntity
                    && livingEntity.method_5805() && !entity.method_7325());
            for (class_1297 entity : targets) {
                if (!wave.hitEntities.add(entity.method_5667())) {
                    continue;
                }
                class_1309 target = (class_1309) entity;
                target.method_64397(world, world.method_48963().method_48802(owner), TIDAL_WAVE_DAMAGE);
                target.method_5762(
                        wave.direction.field_1352 * TIDAL_WAVE_KNOCKBACK,
                        0.9D,
                        wave.direction.field_1350 * TIDAL_WAVE_KNOCKBACK
                );
                target.field_64356 = true;
            }

            for (double lateral = -TIDAL_WAVE_HALF_WIDTH; lateral <= TIDAL_WAVE_HALF_WIDTH; lateral += 1.0D) {
                for (double vertical = 0.0D; vertical <= TIDAL_WAVE_HEIGHT; vertical += 1.0D) {
                    class_243 particlePosition = wave.position.method_1019(side.method_1021(lateral)).method_1031(0.0D, vertical, 0.0D);
                    world.method_65096(class_2398.field_11202, particlePosition.field_1352, particlePosition.field_1351, particlePosition.field_1350,
                            4, 0.35D, 0.35D, 0.35D, 0.08D);
                    if ((int) vertical % 2 == 0) {
                        world.method_65096(class_2398.field_11247, particlePosition.field_1352, particlePosition.field_1351, particlePosition.field_1350,
                                1, 0.2D, 0.2D, 0.2D, 0.02D);
                    }
                }
            }

            if (wave.remainingTicks <= 0 || wave.position.method_1022(owner.method_73189()) > TIDAL_WAVE_RANGE + 3.0D) {
                waves.remove(index);
            }
        }

        if (waves.isEmpty()) {
            ACTIVE_TIDAL_WAVES.remove(world);
        }
    }

    static void clearAll() {
        ACTIVE_WATER_PROJECTILES.clear();
        ACTIVE_TIDAL_WAVES.clear();
    }

    private static final class ActiveWaterProjectile {
        private final UUID ownerUuid;
        private final double gravity;
        private final double size;
        private final boolean meteor;
        private class_243 position;
        private class_243 velocity;
        private int remainingTicks;

        private ActiveWaterProjectile(
                UUID ownerUuid,
                class_243 position,
                class_243 velocity,
                double gravity,
                int remainingTicks,
                double size,
                boolean meteor
        ) {
            this.ownerUuid = ownerUuid;
            this.position = position;
            this.velocity = velocity;
            this.gravity = gravity;
            this.remainingTicks = remainingTicks;
            this.size = size;
            this.meteor = meteor;
        }
    }

    private static final class ActiveTidalWave {
        private final UUID ownerUuid;
        private final class_243 direction;
        private final Set<UUID> hitEntities = new HashSet<>();
        private class_243 position;
        private int remainingTicks;

        private ActiveTidalWave(UUID ownerUuid, class_243 position, class_243 direction, int durationTicks) {
            this.ownerUuid = ownerUuid;
            this.position = position;
            this.direction = direction;
            this.remainingTicks = durationTicks;
        }
    }
}
