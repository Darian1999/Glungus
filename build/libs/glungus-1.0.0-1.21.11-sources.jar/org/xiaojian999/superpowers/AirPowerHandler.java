package org.xiaojian999.superpowers;

import org.xiaojian999.superpowers.math.GlungFastMath;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/** Air powers: flight, the Wind Burst push, and the Tempest Tornado ultimate. */
final class AirPowerHandler {
    private static final int AIR_PUSH_COOLDOWN = 60;
    private static final double AIR_PUSH_RANGE = 20.0D;
    private static final double AIR_PUSH_CONE_DOT = 0.5D;
    private static final int AIR_TORNADO_DURATION = 80;
    private static final double AIR_TORNADO_RADIUS = 8.0D;
    private static final float AIR_TORNADO_DAMAGE = 3.5F;

    private static final Set<UUID> AIR_FLIGHT_PLAYERS = new HashSet<>();
    private static final Map<class_3218, List<ActiveTornado>> ACTIVE_TORNADOES = new HashMap<>();

    private AirPowerHandler() {
    }

    static int toggleFlight(class_3222 player) {
        if (AIR_FLIGHT_PLAYERS.contains(player.method_5667())) {
            disableFlight(player);
            PowerManager.sendPowerStatus(player);
            player.method_7353(class_2561.method_43470("Air flight disabled."), true);
            return 1;
        }

        AIR_FLIGHT_PLAYERS.add(player.method_5667());
        player.method_31549().field_7478 = true;
        player.method_31549().field_7479 = true;
        player.method_7355();
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("Air flight enabled. Gravity reduced by 15%."), true);
        return 1;
    }

    static void disableFlight(class_3222 player) {
        if (!AIR_FLIGHT_PLAYERS.remove(player.method_5667())) {
            return;
        }

        if (!player.method_68878() && !player.method_7325()) {
            player.method_31549().field_7478 = false;
            player.method_31549().field_7479 = false;
            player.method_7355();
        }
    }

    static boolean isFlightActive(UUID playerUuid) {
        return AIR_FLIGHT_PLAYERS.contains(playerUuid);
    }

    public static boolean isAirFlightActive(class_1297 entity) {
        return entity instanceof class_3222 player && AIR_FLIGHT_PLAYERS.contains(player.method_5667());
    }

    static int pushAirCone(class_3222 player, SlotKey slotKey) {
        int remainingTicks = PowerCooldowns.secondPowerRemaining(slotKey);
        if (remainingTicks > 0) {
            PowerManager.sendPowerStatus(player);
            PowerManager.sendCooldownMessage(player, "Wind Burst", remainingTicks);
            return 0;
        }

        class_3218 world = (class_3218) player.method_51469();
        class_243 start = player.method_5836(1.0F);
        class_243 direction = player.method_5828(1.0F).method_1029();
        class_238 searchBox = player.method_5829()
                .method_18804(direction.method_1021(AIR_PUSH_RANGE))
                .method_1014(4.0D);
        List<class_1297> targets = world.method_8333(
                player,
                searchBox,
                entity -> !entity.method_7325() && entity.method_5863() && entity.method_5805()
        );
        int pushedEntities = 0;
        for (class_1297 target : targets) {
            class_243 toTarget = target.method_73189().method_1020(start);
            double distance = toTarget.method_1033();
            if (distance < 0.01D || distance > AIR_PUSH_RANGE) {
                continue;
            }
            if (direction.method_1026(toTarget.method_1029()) < AIR_PUSH_CONE_DOT) {
                continue;
            }

            double force = 2.0D + (AIR_PUSH_RANGE - distance) / AIR_PUSH_RANGE;
            class_243 push = direction.method_1021(force).method_1031(0.0D, 0.35D, 0.0D);
            target.method_60491(push);
            target.field_64356 = true;
            pushedEntities++;
        }

        PowerCooldowns.setSecondPower(slotKey, AIR_PUSH_COOLDOWN);
        world.method_65096(class_2398.field_11204, start.field_1352, start.field_1351, start.field_1350, 90, 3.0D, 2.0D, 3.0D, 0.12D);
        world.method_65096(class_2398.field_47494, start.field_1352 + direction.field_1352 * 3.0D, start.field_1351 + direction.field_1351 * 3.0D, start.field_1350 + direction.field_1350 * 3.0D, 18, 1.5D, 1.5D, 1.5D, 0.08D);
        world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), class_3417.field_47723, class_3419.field_15248, 1.4F, 1.0F);
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("Wind Burst launched — " + pushedEntities + " entities pushed."), true);
        return 1;
    }

    static void startTornado(class_3222 player) {
        class_3218 world = (class_3218) player.method_51469();
        ACTIVE_TORNADOES.computeIfAbsent(world, ignored -> new ArrayList<>())
                .add(new ActiveTornado(player.method_5667(), AIR_TORNADO_DURATION));

        class_243 center = player.method_73189().method_1031(0.0D, 1.0D, 0.0D);
        world.method_65096(class_2398.field_49140, center.field_1352, center.field_1351, center.field_1350, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        world.method_65096(class_2398.field_11204, center.field_1352, center.field_1351, center.field_1350, 120, 4.0D, 3.0D, 4.0D, 0.15D);
        world.method_43128(null, center.field_1352, center.field_1351, center.field_1350, class_3417.field_47723, class_3419.field_15248, 2.2F, 0.65F);
        player.method_7353(class_2561.method_43470("Tempest Tornado unleashed!"), true);
    }

    static void tickPlayer(class_3222 player) {
        if (AIR_FLIGHT_PLAYERS.contains(player.method_5667()) && !player.method_31549().field_7478) {
            player.method_31549().field_7478 = true;
            player.method_7355();
        }
    }

    static void tick(class_3218 world) {
        List<ActiveTornado> tornadoes = ACTIVE_TORNADOES.get(world);
        if (tornadoes == null) {
            return;
        }

        for (int index = tornadoes.size() - 1; index >= 0; index--) {
            ActiveTornado tornado = tornadoes.get(index);
            class_3222 owner = world.method_8503().method_3760().method_14602(tornado.ownerUuid);
            if (owner == null || owner.method_51469() != world) {
                tornadoes.remove(index);
                continue;
            }

            tornado.remainingTicks--;
            tornado.elapsedTicks++;
            class_243 center = owner.method_73189().method_1031(0.0D, 1.0D, 0.0D);
            class_238 area = owner.method_5829().method_1009(AIR_TORNADO_RADIUS, 5.0D, AIR_TORNADO_RADIUS);
            List<class_1297> targets = world.method_8333(
                    owner,
                    area,
                    entity -> !entity.method_7325() && entity.method_5863() && entity.method_5805()
            );

            for (class_1297 target : targets) {
                class_243 offset = target.method_73189().method_1020(center);
                // GlungFastMath: fast hypot + fast invSqrt for horizontal distance
                double horizontalDistance = GlungFastMath.hypotFast(offset.field_1352, offset.field_1350);
                if (horizontalDistance > AIR_TORNADO_RADIUS || Math.abs(offset.field_1351) > 5.0D) {
                    continue;
                }

                // Use GlungFastMath tangent/pull helpers (table trig, fast normalize)
                class_243 tangent = GlungFastMath.tornadoTangent(center, target.method_73189(), 0.36D);
                class_243 pull = horizontalDistance < 0.01D ? class_243.field_1353
                        : GlungFastMath.tornadoPull(center, target.method_73189(), 0.09D);
                double lift = 0.42D + Math.max(0.0D, AIR_TORNADO_RADIUS - horizontalDistance) * 0.035D;
                target.method_5762(tangent.field_1352 + pull.field_1352, lift, tangent.field_1350 + pull.field_1350);
                target.field_64356 = true;

                if (target instanceof class_1309 livingTarget && tornado.elapsedTicks % 10 == 0) {
                    livingTarget.method_64397(world, world.method_48963().method_48802(owner), AIR_TORNADO_DAMAGE);
                }
            }

            if (tornado.elapsedTicks % 2 == 0) {
                for (int angle = 0; angle < 360; angle += 30) {
                    // GlungFastMath: table-based sin/cos, no toRadians allocation
                    double radians = angle * GlungFastMath.DEG_TO_RAD + tornado.elapsedTicks * 0.18D;
                    double radius = 2.0D + ((angle / 30 + tornado.elapsedTicks / 4) % 5) * 1.25D;
                    double x = center.field_1352 + GlungFastMath.fastCos(radians) * radius;
                    double z = center.field_1350 + GlungFastMath.fastSin(radians) * radius;
                    double y = center.field_1351 - 2.0D + ((angle / 30 + tornado.elapsedTicks) % 12) * 0.65D;
                    world.method_65096(class_2398.field_11204, x, y, z, 3, 0.25D, 0.3D, 0.25D, 0.02D);
                    world.method_65096(class_2398.field_47494, x, y, z, 1, 0.1D, 0.1D, 0.1D, 0.03D);
                }
            }

            if (tornado.remainingTicks <= 0) {
                world.method_60511(null, center.field_1352, center.field_1351, center.field_1350, class_3417.field_49049, class_3419.field_15248, 1.5F, 0.8F);
                tornadoes.remove(index);
            }
        }

        if (tornadoes.isEmpty()) {
            ACTIVE_TORNADOES.remove(world);
        }
    }

    static void removePlayer(UUID playerUuid) {
        AIR_FLIGHT_PLAYERS.remove(playerUuid);
    }

    static void clearAll() {
        AIR_FLIGHT_PLAYERS.clear();
        ACTIVE_TORNADOES.clear();
    }

    private static final class ActiveTornado {
        private final UUID ownerUuid;
        private final int durationTicks;
        private int remainingTicks;
        private int elapsedTicks;

        private ActiveTornado(UUID ownerUuid, int durationTicks) {
            this.ownerUuid = ownerUuid;
            this.durationTicks = durationTicks;
            this.remainingTicks = durationTicks;
        }
    }
}
