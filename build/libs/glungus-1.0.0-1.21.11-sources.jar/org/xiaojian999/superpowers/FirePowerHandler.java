package org.xiaojian999.superpowers;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Fire powers: the flamethrower beam, fire immunity, and the Ring of Fire ultimate. */
final class FirePowerHandler {
    private static final int FIRE_BEAM_DURATION = 100;
    private static final double FIRE_BEAM_RANGE = 10.0D;
    private static final double FIRE_BEAM_WIDTH = 1.2D;
    private static final int FIRE_BEAM_IGNITE_SECONDS = 5;
    private static final int FIRE_BEAM_MAX_IGNITIONS = 12;
    private static final int FIRE_BEAM_COOLDOWN = 100;
    private static final int FIRE_RESISTANCE_REFRESH_TICKS = 100;
    private static final int RING_OF_FIRE_DURATION = 100;
    private static final double RING_OF_FIRE_RADIUS = 9.0D;
    private static final double RING_OF_FIRE_SPEED = 0.3D;
    private static final double RING_OF_FIRE_THICKNESS = 1.5D;
    private static final double RING_OF_FIRE_HEIGHT = 2.5D;
    private static final float RING_OF_FIRE_DAMAGE = 24.0F;
    private static final int RING_OF_FIRE_IGNITE_SECONDS = 6;

    private static final Set<UUID> FIRE_IMMUNE_PLAYERS = new HashSet<>();
    private static final Map<SlotKey, Integer> FIRE_BEAM_TICKS = new HashMap<>();
    private static final Map<class_3218, List<ActiveFireRing>> ACTIVE_FIRE_RINGS = new HashMap<>();

    private FirePowerHandler() {
    }

    static int fireFlamethrower(class_3222 player, SlotKey slotKey) {
        if (FIRE_BEAM_TICKS.containsKey(slotKey)) {
            PowerManager.sendPowerStatus(player);
            player.method_7353(class_2561.method_43470("Your flamethrower is already burning."), true);
            return 0;
        }

        int remainingTicks = PowerCooldowns.beamRemaining(slotKey);
        if (remainingTicks > 0) {
            PowerManager.sendPowerStatus(player);
            PowerManager.sendCooldownMessage(player, "Flamethrower", remainingTicks);
            return 0;
        }

        FIRE_BEAM_TICKS.put(slotKey, FIRE_BEAM_DURATION);
        class_3218 world = (class_3218) player.method_51469();
        world.method_43128(
                null,
                player.method_23317(),
                player.method_23318(),
                player.method_23321(),
                class_3417.field_15013,
                class_3419.field_15248,
                1.2F,
                0.8F
        );
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("Flamethrower ignited — 5 seconds of fire!"), true);
        return 1;
    }

    static int toggleFireImmunity(class_3222 player) {
        UUID playerUuid = player.method_5667();
        if (FIRE_IMMUNE_PLAYERS.contains(playerUuid)) {
            FIRE_IMMUNE_PLAYERS.remove(playerUuid);
            player.method_6016(class_1294.field_5918);
            PowerManager.sendPowerStatus(player);
            player.method_7353(class_2561.method_43470("Fire immunity disabled."), true);
            return 1;
        }

        FIRE_IMMUNE_PLAYERS.add(playerUuid);
        player.method_20803(0);
        player.method_6092(new class_1293(
                class_1294.field_5918,
                FIRE_RESISTANCE_REFRESH_TICKS,
                0,
                false,
                false,
                false
        ));
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("Fire immunity enabled — you are immune to fire and lava."), true);
        return 1;
    }

    static void clearFireState(class_3222 player) {
        UUID playerUuid = player.method_5667();
        FIRE_IMMUNE_PLAYERS.remove(playerUuid);
        removeAll(FIRE_BEAM_TICKS, playerUuid);
        player.method_6016(class_1294.field_5918);
    }

    static boolean isImmune(UUID playerUuid) {
        return FIRE_IMMUNE_PLAYERS.contains(playerUuid);
    }

    static boolean isBeamActive(SlotKey slotKey) {
        return FIRE_BEAM_TICKS.containsKey(slotKey);
    }

    static Integer getActiveBeamTicks(SlotKey slotKey) {
        return FIRE_BEAM_TICKS.get(slotKey);
    }

    static void startRingOfFire(class_3222 player) {
        class_3218 world = (class_3218) player.method_51469();
        class_243 look = player.method_5828(1.0F);
        class_243 direction = new class_243(look.field_1352, 0.0D, look.field_1350);
        if (direction.method_1027() < 0.0001D) {
            class_2350 facing = player.method_5735();
            direction = new class_243(facing.method_10148(), 0.0D, facing.method_10165());
        }
        direction = direction.method_1029();
        class_243 center = player.method_33571().method_1019(direction.method_1021(2.5D));

        ACTIVE_FIRE_RINGS.computeIfAbsent(world, ignored -> new ArrayList<>())
                .add(new ActiveFireRing(player.method_5667(), direction, center, RING_OF_FIRE_RADIUS, RING_OF_FIRE_DURATION));

        world.method_65096(
                class_2398.field_11239,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                80,
                RING_OF_FIRE_RADIUS,
                1.5D,
                RING_OF_FIRE_RADIUS,
                0.05D
        );
        world.method_65096(
                class_2398.field_11240,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                120,
                RING_OF_FIRE_RADIUS,
                2.0D,
                RING_OF_FIRE_RADIUS,
                0.1D
        );
        world.method_43128(
                null,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                class_3417.field_15013,
                class_3419.field_15248,
                2.0F,
                0.6F
        );
        player.method_7353(class_2561.method_43470("The Ring of Fire has been unleashed!"), true);
    }

    static void tickPlayer(class_3222 player) {
        if (FIRE_IMMUNE_PLAYERS.contains(player.method_5667())
                && !player.method_6059(class_1294.field_5918)) {
            player.method_6092(new class_1293(
                    class_1294.field_5918,
                    FIRE_RESISTANCE_REFRESH_TICKS,
                    0,
                    false,
                    false,
                    false
            ));
        }
    }

    static void tickServer(MinecraftServer server) {
        FIRE_BEAM_TICKS.entrySet().removeIf(entry -> {
            SlotKey slotKey = entry.getKey();
            class_3222 player = server.method_3760().method_14602(slotKey.playerUuid());
            if (player == null) {
                return true;
            }

            tickFireBeam(player);
            int next = entry.getValue() - 1;
            if (next <= 0) {
                PowerCooldowns.setBeam(slotKey, FIRE_BEAM_COOLDOWN);
                PowerManager.sendPowerStatus(player);
                return true;
            }
            entry.setValue(next);
            return false;
        });
    }

    private static void tickFireBeam(class_3222 player) {
        class_3218 world = (class_3218) player.method_51469();
        class_243 start = player.method_5836(1.0F);
        class_243 direction = player.method_5828(1.0F).method_1029();
        class_243 maximumEnd = start.method_1019(direction.method_1021(FIRE_BEAM_RANGE));

        spawnFireBeamParticles(world, start, maximumEnd);
        igniteBlocksAlongBeam(world, start, maximumEnd, player);

        class_238 searchBox = player.method_5829()
                .method_18804(direction.method_1021(FIRE_BEAM_RANGE))
                .method_1014(FIRE_BEAM_WIDTH);
        List<class_1297> targets = world.method_8333(
                player,
                searchBox,
                entity -> entity instanceof class_1309 livingEntity
                        && livingEntity.method_5805()
                        && !entity.method_7325()
        );
        for (class_1297 target : targets) {
            class_243 toTarget = target.method_73189().method_1020(start);
            double along = toTarget.method_1026(direction);
            if (along < 0.0D || along > FIRE_BEAM_RANGE) {
                continue;
            }
            class_243 closest = start.method_1019(direction.method_1021(along));
            if (target.method_73189().method_1025(closest) <= FIRE_BEAM_WIDTH * FIRE_BEAM_WIDTH) {
                ((class_1309) target).method_5639(FIRE_BEAM_IGNITE_SECONDS);
            }
        }
    }

    private static void spawnFireBeamParticles(class_3218 world, class_243 start, class_243 end) {
        class_243 beam = end.method_1020(start);
        double length = beam.method_1033();
        if (length == 0.0D) {
            return;
        }

        class_243 direction = beam.method_1029();
        for (double distance = 0.0D; distance <= length; distance += 0.4D) {
            class_243 position = start.method_1019(direction.method_1021(distance));
            world.method_65096(
                    class_2398.field_11240,
                    position.field_1352,
                    position.field_1351,
                    position.field_1350,
                    2,
                    0.06D,
                    0.06D,
                    0.06D,
                    0.015D
            );
            if ((int) (distance * 5.0D) % 10 == 0) {
                world.method_65096(
                        class_2398.field_11239,
                        position.field_1352,
                        position.field_1351,
                        position.field_1350,
                        1,
                        0.05D,
                        0.05D,
                        0.05D,
                        0.0D
                );
            }
        }
        world.method_65096(
                class_2398.field_11240,
                end.field_1352,
                end.field_1351,
                end.field_1350,
                10,
                0.25D,
                0.25D,
                0.25D,
                0.05D
        );
    }

    private static void igniteBlocksAlongBeam(
            class_3218 world,
            class_243 start,
            class_243 end,
            class_3222 player
    ) {
        class_243 beam = end.method_1020(start);
        double length = beam.method_1033();
        if (length == 0.0D) {
            return;
        }

        class_243 direction = beam.method_1029();
        class_2338 playerPos = player.method_24515();
        int ignited = 0;
        for (double distance = 0.0D; distance <= length && ignited < FIRE_BEAM_MAX_IGNITIONS; distance += 0.5D) {
            class_2338 center = class_2338.method_49638(start.method_1019(direction.method_1021(distance)));
            for (int dx = -1; dx <= 1 && ignited < FIRE_BEAM_MAX_IGNITIONS; dx++) {
                for (int dy = -1; dy <= 1 && ignited < FIRE_BEAM_MAX_IGNITIONS; dy++) {
                    for (int dz = -1; dz <= 1 && ignited < FIRE_BEAM_MAX_IGNITIONS; dz++) {
                        class_2338 position = center.method_10069(dx, dy, dz);
                        if (isNearPlayer(position, playerPos)) {
                            continue;
                        }
                        if (tryIgniteBlock(world, position)) {
                            ignited++;
                        }
                    }
                }
            }
        }
    }

    private static boolean isNearPlayer(class_2338 position, class_2338 playerPos) {
        return Math.abs(position.method_10263() - playerPos.method_10263()) <= 1
                && Math.abs(position.method_10264() - playerPos.method_10264()) <= 1
                && Math.abs(position.method_10260() - playerPos.method_10260()) <= 1;
    }

    private static boolean tryIgniteBlock(class_3218 world, class_2338 position) {
        class_2680 state = world.method_8320(position);
        if (!state.method_26215() || !class_2246.field_10036.method_9564().method_26184(world, position)) {
            return false;
        }
        world.method_8652(position, class_2246.field_10036.method_9564(), class_2248.field_31036);
        return true;
    }

    static void tick(class_3218 world) {
        List<ActiveFireRing> rings = ACTIVE_FIRE_RINGS.get(world);
        if (rings == null) {
            return;
        }

        for (int index = rings.size() - 1; index >= 0; index--) {
            ActiveFireRing ring = rings.get(index);
            class_3222 owner = world.method_8503().method_3760().method_14602(ring.ownerUuid);
            if (owner == null || owner.method_51469() != world) {
                rings.remove(index);
                continue;
            }

            ring.remainingTicks--;
            ring.elapsedTicks++;
            ring.position = ring.position.method_1019(ring.direction.method_1021(RING_OF_FIRE_SPEED));

            class_238 area = new class_238(
                    ring.position.field_1352 - ring.radius - 2.0D,
                    ring.position.field_1351 - RING_OF_FIRE_HEIGHT,
                    ring.position.field_1350 - ring.radius - 2.0D,
                    ring.position.field_1352 + ring.radius + 2.0D,
                    ring.position.field_1351 + RING_OF_FIRE_HEIGHT,
                    ring.position.field_1350 + ring.radius + 2.0D
            );
            List<class_1297> targets = world.method_8333(
                    owner,
                    area,
                    entity -> entity instanceof class_1309 livingEntity
                            && livingEntity.method_5805()
                            && !entity.method_7325()
            );
            for (class_1297 entity : targets) {
                class_243 entityPos = entity.method_73189();
                double horizontalDistance = Math.sqrt(
                        (entityPos.field_1352 - ring.position.field_1352) * (entityPos.field_1352 - ring.position.field_1352)
                                + (entityPos.field_1350 - ring.position.field_1350) * (entityPos.field_1350 - ring.position.field_1350)
                );
                if (Math.abs(horizontalDistance - ring.radius) <= RING_OF_FIRE_THICKNESS
                        && Math.abs(entityPos.field_1351 - ring.position.field_1351) <= RING_OF_FIRE_HEIGHT) {
                    class_1309 livingTarget = (class_1309) entity;
                    livingTarget.method_5639(RING_OF_FIRE_IGNITE_SECONDS);
                    livingTarget.method_64397(world, world.method_48963().method_48802(owner), RING_OF_FIRE_DAMAGE);
                }
            }

            Set<class_2338> positionsToIgnite = new HashSet<>();
            int samples = 36;
            for (int sample = 0; sample < samples; sample++) {
                double angle = Math.toRadians(sample * 10.0D) + ring.elapsedTicks * 0.18D;
                double x = ring.position.field_1352 + Math.cos(angle) * ring.radius;
                double z = ring.position.field_1350 + Math.sin(angle) * ring.radius;
                double y = ring.position.field_1351;
                world.method_65096(class_2398.field_11240, x, y, z, 2, 0.18D, 0.12D, 0.18D, 0.02D);
                if (sample % 4 == 0) {
                    world.method_65096(class_2398.field_11239, x, y + 0.3D, z, 1, 0.06D, 0.06D, 0.06D, 0.01D);
                }
                if (sample % 3 == 0) {
                    world.method_65096(class_2398.field_11240, x, y + 1.2D, z, 1, 0.1D, 0.35D, 0.1D, 0.03D);
                }

                class_2338 center = class_2338.method_49637(x, y, z);
                for (int dx = -1; dx <= 1; dx++) {
                    for (int dy = -1; dy <= 1; dy++) {
                        for (int dz = -1; dz <= 1; dz++) {
                            positionsToIgnite.add(center.method_10069(dx, dy, dz));
                        }
                    }
                }
            }
            class_2338 ownerPos = owner.method_24515();
            for (class_2338 position : positionsToIgnite) {
                if (isNearPlayer(position, ownerPos)) {
                    continue;
                }
                tryIgniteBlock(world, position);
            }

            if (ring.remainingTicks <= 0) {
                rings.remove(index);
            }
        }

        if (rings.isEmpty()) {
            ACTIVE_FIRE_RINGS.remove(world);
        }
    }

    static void removePlayer(UUID playerUuid) {
        FIRE_IMMUNE_PLAYERS.remove(playerUuid);
        removeAll(FIRE_BEAM_TICKS, playerUuid);
    }

    static void clearAll() {
        FIRE_IMMUNE_PLAYERS.clear();
        FIRE_BEAM_TICKS.clear();
        ACTIVE_FIRE_RINGS.clear();
    }

    private static <V> void removeAll(Map<SlotKey, V> map, UUID playerUuid) {
        map.keySet().removeIf(key -> key.playerUuid().equals(playerUuid));
    }

    private static final class ActiveFireRing {
        private final UUID ownerUuid;
        private final class_243 direction;
        private final double radius;
        private class_243 position;
        private int remainingTicks;
        private int elapsedTicks;

        private ActiveFireRing(UUID ownerUuid, class_243 direction, class_243 position, double radius, int durationTicks) {
            this.ownerUuid = ownerUuid;
            this.direction = direction;
            this.position = position;
            this.radius = radius;
            this.remainingTicks = durationTicks;
        }
    }
}
