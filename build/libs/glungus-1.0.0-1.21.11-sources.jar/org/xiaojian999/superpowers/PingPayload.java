package org.xiaojian999.superpowers;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import org.xiaojian999.superpowers.network.AutoPayload;
import org.xiaojian999.superpowers.network.PayloadDirection;

/**
 * Example payload demonstrating auto-generation: no CODEC field is defined,
 * so {@link org.xiaojian999.superpowers.network.PayloadRegistry} will auto-generate
 * a VAR_INT codec from the single {@code int value} component and auto-register
 * it C2S if necessary. This file exists to demonstrate the feature – it is not
 * used by core powers but shows that new payloads require zero boilerplate beyond
 * the record + @AutoPayload.
 */
@AutoPayload(value = "ping", direction = PayloadDirection.C2S)
public record PingPayload(int value) implements class_8710 {
    public static final class_8710.class_9154<PingPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(Glungus.MOD_ID, "ping"));

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
