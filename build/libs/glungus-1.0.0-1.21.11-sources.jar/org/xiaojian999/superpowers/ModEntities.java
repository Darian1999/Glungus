package org.xiaojian999.superpowers;

import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Entity types added by the mod. Mirrors the vanilla lightning bolt setup
 * (zero-sized, wide tracking range, no position updates), but the type is
 * dedicated to cosmetic "big" bolts so the client can render them scaled up.
 */
public final class ModEntities {
    public static final class_1299<BigLightningEntity> BIG_LIGHTNING = class_2378.method_39197(
            class_7923.field_41177,
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(Glungus.MOD_ID, "big_lightning")),
            class_1299.class_1300.method_5903(BigLightningEntity::new, class_1311.field_17715)
                    .method_17687(0.0F, 0.0F)
                    .method_27299(16)
                    .method_27300(Integer.MAX_VALUE)
                    .method_5904()
                    .method_5905(class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(Glungus.MOD_ID, "big_lightning")))
    );

    private ModEntities() {
    }

    /** Forces the entity types to be registered. Called from the mod initializer. */
    public static void register() {
        // The static field above registers the types; touching the class is enough.
    }
}
