package org.xiaojian999.superpowers;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.xiaojian999.superpowers.network.AutoPayload;
import org.xiaojian999.superpowers.network.PayloadDirection;

@AutoPayload(direction = PayloadDirection.C2S)
public record GodLaserPayload(boolean active) implements class_8710 {
    public static final class_8710.class_9154<GodLaserPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(Glungus.MOD_ID, "god_laser"));
    public static final class_9139<class_9129, GodLaserPayload> CODEC = class_9139.method_56434(
            class_9135.field_48550.method_56432(value -> value != 0, active -> active ? 1 : 0),
            GodLaserPayload::active,
            GodLaserPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}