package org.xiaojian999.superpowers;

import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1675;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2388;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_6880;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** The God powerset: creative godhood, instant kills, a held laser, and blessings. */
final class GodPowerHandler {
    private static final int LASER_RANGE = 100;
    private static final double LASER_KILL_RADIUS = 20.0D;
    private static final double LASER_BLOCK_RADIUS = 1.0D;
    private static final double BLESS_RANGE = 32.0D;
    private static final int BLESS_DURATION = 1200;
    private static final int AURA_PARTICLE_INTERVAL = 2;
    private static final float GOD_FLIGHT_SPEED_MIN = 0.01f;
    private static final float GOD_FLIGHT_SPEED_MAX = 0.20f;
    private static final float SPEED_STEP = 0.01f;
    private static final double LEVITATE_RADIUS = 30.0D;
    private static final int LEVITATE_DURATION = 600;
    private static final int LEVITATE_AMPLIFIER = 1;

    // ----- Divine arsenal: smite, annihilate, holy nova, omnipotence, banish -----
    private static final double SMITE_RANGE = 40.0D;
    private static final float SMITE_AOE_DAMAGE = 12.0F;
    private static final double SMITE_AOE_RADIUS = 4.0D;
    private static final int SMITE_COOLDOWN = 30;

    private static final double ANNIHILATE_RANGE = 40.0D;
    private static final double ANNIHILATE_RADIUS = 6.0D;
    private static final float ANNIHILATE_DAMAGE = 20.0F;
    private static final int ANNIHILATE_COOLDOWN = 600;

    private static final double NOVA_RADIUS = 24.0D;
    private static final float NOVA_DAMAGE = 10.0F;
    private static final double NOVA_KNOCKBACK = 2.4D;
    private static final int NOVA_COOLDOWN = 400;

    private static final int OMNIPOTENCE_DURATION = 300;
    private static final int OMNIPOTENCE_COOLDOWN = 600;
    private static final int OMNIPOTENCE_REFRESH_INTERVAL = 20;

    private static final double BANISH_RANGE = 32.0D;
    private static final float BANISH_DAMAGE = 25.0F;
    private static final int BANISH_COOLDOWN = 200;

    private static final Set<UUID> GOD_MODE_PLAYERS = new HashSet<>();
    private static final Set<UUID> GOD_NOCLIP_PLAYERS = new HashSet<>();
    private static final Set<UUID> CLIENT_GOD_NOCLIP_PLAYERS = new HashSet<>();
    private static final Set<UUID> ACTIVE_LASERS = new HashSet<>();
    private static final Map<UUID, class_1934> PREVIOUS_GAME_MODES = new HashMap<>();
    private static final Map<UUID, Integer> SMITE_COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Integer> ANNIHILATE_COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Integer> NOVA_COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Integer> OMNIPOTENCE_COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Integer> BANISH_COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Integer> OMNIPOTENCE_TICKS = new HashMap<>();

    private GodPowerHandler() {
    }

    static int toggleGodMode(class_3222 player) {
        UUID playerUuid = player.method_5667();
        if (GOD_MODE_PLAYERS.contains(playerUuid)) {
            disableGodMode(player);
            PowerManager.sendPowerStatus(player);
            player.method_7353(class_2561.method_43470("God Mode disabled."), true);
            return 1;
        }

        PREVIOUS_GAME_MODES.put(playerUuid, player.field_13974.method_14257());
        GOD_MODE_PLAYERS.add(playerUuid);
        player.method_7336(class_1934.field_9220);
        // God Mode starts without noclip; press backslash (\\) to toggle phasing through walls.
        player.field_5960 = false;
        player.method_31549().field_7479 = false;
        player.method_7355();
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470(
                "God Mode enabled — KP7 bless, KP8 levitate, KP9 laser, KP0 smite, KP. blast, KPENTER nova, KP* omnipotence, KP/ banish, \\ noclip."
        ), true);
        return 1;
    }

    static boolean isActive(UUID playerUuid) {
        return GOD_MODE_PLAYERS.contains(playerUuid);
    }

    static boolean isNoClipActive(UUID playerUuid) {
        return GOD_NOCLIP_PLAYERS.contains(playerUuid);
    }

    static boolean isClientNoClipActive(UUID playerUuid) {
        return CLIENT_GOD_NOCLIP_PLAYERS.contains(playerUuid);
    }

    static void setClientNoClipActive(UUID playerUuid, boolean active) {
        if (active) {
            CLIENT_GOD_NOCLIP_PLAYERS.add(playerUuid);
        } else {
            CLIENT_GOD_NOCLIP_PLAYERS.remove(playerUuid);
        }
    }

    static int toggleNoClip(class_3222 player) {
        UUID playerUuid = player.method_5667();
        if (!isActive(playerUuid)) {
            return 0;
        }
        boolean enabled;
        if (GOD_NOCLIP_PLAYERS.contains(playerUuid)) {
            GOD_NOCLIP_PLAYERS.remove(playerUuid);
            enabled = false;
        } else {
            GOD_NOCLIP_PLAYERS.add(playerUuid);
            enabled = true;
        }
        // Keep server-side noClip in sync immediately; the END_SERVER_TICK loop
        // also reapplies isNoClipActive every tick.
        player.field_5960 = enabled;
        if (enabled) {
            // Lock flying on — noclip without flight lets you fall through the floor.
            player.method_31549().field_7478 = true;
            player.method_31549().field_7479 = true;
            player.method_7355();
        }
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470(
                enabled ? "God Mode no-clip enabled — phase through walls (flight locked)." : "God Mode no-clip disabled."
        ), true);
        return 1;
    }

    static void setLaserActive(class_3222 player, boolean active) {
        if (active && isActive(player.method_5667())) {
            if (ACTIVE_LASERS.add(player.method_5667())) {
                player.method_51469().method_43128(
                        null,
                        player.method_23317(),
                        player.method_23318(),
                        player.method_23321(),
                        class_3417.field_14858,
                        class_3419.field_15248,
                        0.8F,
                        1.8F
                );
            }
        } else {
            ACTIVE_LASERS.remove(player.method_5667());
        }
    }

    static void tickPlayer(class_3222 player) {
        if (!isActive(player.method_5667())) {
            return;
        }

        if (player.field_13974.method_14257() != class_1934.field_9220) {
            player.method_7336(class_1934.field_9220);
        }
        // God Mode noclip is opt-in via backslash; otherwise keep spectator-style noclip disabled.
        // The END_SERVER_TICK loop already sets player.noClip via PowerManager.isNoClipActive,
        // so we don't force it off here when toggled on.
        class_3218 world = (class_3218) player.method_51469();
        tickOmnipotence(player, world);
        if (world.method_75260() % AURA_PARTICLE_INTERVAL == 0) {
            world.method_65096(
                    class_2398.field_29642,
                    player.method_23317(),
                    player.method_23318() + player.method_17682() * 0.55D,
                    player.method_23321(),
                    10, // decreased from 18
                    0.7D,
                    0.9D,
                    0.7D,
                    0.03D
            );
        }
        // HACKY LIGHT (no block placement): give the god permanent Night Vision
        // plus a client-side fullbright mixin, so the player *appears* to be a
        // light source without ever calling world.setBlockState(Blocks.LIGHT).
        // This avoids overwriting/breaking the block at the player's feet and
        // leaves no holes when God Mode ends. A soft halo of END_ROD particles
        // sells the visual illusion.
        var nightVision = player.method_6112(class_1294.field_5925);
        if (nightVision == null || nightVision.method_5584() < 200) {
            player.method_6092(new class_1293(
                    class_1294.field_5925, 400, 0, false, false, false));
        }
        if (world.method_75260() % 3 == 0) {
            class_243 halo = player.method_73189().method_1031(0.0D, player.method_17682() * 0.5D, 0.0D);
            world.method_65096(class_2398.field_11207, halo.field_1352, halo.field_1351, halo.field_1350, 2, 0.25D, 0.35D, 0.25D, 0.01D);
        }
        // No-clip flight lock: while noclip is on, the god must stay airborne.
        // Re-assert flying/allowFlying every tick so double-tapping space cannot drop them.
        if (GOD_NOCLIP_PLAYERS.contains(player.method_5667())) {
            boolean updated = false;
            if (!player.method_31549().field_7478) {
                player.method_31549().field_7478 = true;
                updated = true;
            }
            if (!player.method_31549().field_7479) {
                player.method_31549().field_7479 = true;
                updated = true;
            }
            if (updated) {
                player.method_7355();
            }
        }
    }

    static void tickServer(MinecraftServer server) {
        tickCooldowns();
        for (UUID playerUuid : Set.copyOf(ACTIVE_LASERS)) {
            class_3222 player = server.method_3760().method_14602(playerUuid);
            if (player == null || !isActive(playerUuid) || !(player.method_51469() instanceof class_3218 world)) {
                ACTIVE_LASERS.remove(playerUuid);
                continue;
            }
            fireLaser(world, player);
        }
    }

    private static void fireLaser(class_3218 world, class_3222 player) {
        class_243 start = player.method_5836(1.0F);
        class_243 direction = player.method_5828(1.0F).method_1029();
        class_243 end = start.method_1019(direction.method_1021(LASER_RANGE));

        // The beam bores a small tunnel through everything in its 100-block path.
        for (double distance = 2.0D; distance <= LASER_RANGE; distance += 0.5D) {
            class_243 position = start.method_1019(direction.method_1021(distance));
            class_2338 center = class_2338.method_49638(position);
            for (int x = -1; x <= 1; x++) {
                for (int y = -1; y <= 1; y++) {
                    for (int z = -1; z <= 1; z++) {
                        class_2338 blockPos = center.method_10069(x, y, z);
                        if (blockPos.method_10262(player.method_24515()) < 4.0D) {
                            continue;
                        }
                        class_2680 state = world.method_8320(blockPos);
                        if (isDestructible(state)) {
                            world.method_8651(blockPos, false, player);
                        }
                    }
                }
            }
        }

        class_238 searchBox = new class_238(
                Math.min(start.field_1352, end.field_1352) - LASER_KILL_RADIUS,
                Math.min(start.field_1351, end.field_1351) - LASER_KILL_RADIUS,
                Math.min(start.field_1350, end.field_1350) - LASER_KILL_RADIUS,
                Math.max(start.field_1352, end.field_1352) + LASER_KILL_RADIUS,
                Math.max(start.field_1351, end.field_1351) + LASER_KILL_RADIUS,
                Math.max(start.field_1350, end.field_1350) + LASER_KILL_RADIUS
        );
        List<class_1297> targets = world.method_8333(
                player,
                searchBox,
                entity -> entity instanceof class_1308 mob && mob.method_5805() && !mob.method_7325()
        );
        for (class_1297 target : targets) {
            if (distanceSquaredToSegment(target.method_73189(), start, end) <= LASER_KILL_RADIUS * LASER_KILL_RADIUS) {
                class_1308 mob = (class_1308) target;
                mob.method_6033(0.0F);
                mob.method_5768(world);
            }
        }

        for (double distance = 0.0D; distance <= LASER_RANGE; distance += 1.0D) {
            class_243 position = start.method_1019(direction.method_1021(distance));
            world.method_65096(class_2398.field_29642, position.field_1352, position.field_1351, position.field_1350, 2, 0.12D, 0.12D, 0.12D, 0.02D);
        }
    }

    static int blessTarget(class_3222 player) {
        if (!isActive(player.method_5667())) {
            return 0;
        }
        class_3218 world = (class_3218) player.method_51469();
        class_243 start = player.method_5836(1.0F);
        class_243 direction = player.method_5828(1.0F).method_1029();
        class_243 maximumEnd = start.method_1019(direction.method_1021(BLESS_RANGE));
        class_3965 blockHit = world.method_17742(new class_3959(
                start,
                maximumEnd,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                player
        ));
        class_243 blockEnd = blockHit.method_17783() == class_239.class_240.field_1333 ? maximumEnd : blockHit.method_17784();
        class_3966 entityHit = class_1675.method_18075(
                player,
                start,
                maximumEnd,
                player.method_5829().method_18804(direction.method_1021(BLESS_RANGE)).method_1014(1.0D),
                entity -> entity instanceof class_1308 mob && mob.method_5805() && !mob.method_7325(),
                BLESS_RANGE * BLESS_RANGE
        );
        if (entityHit == null
                || (blockHit.method_17783() != class_239.class_240.field_1333
                && entityHit.method_17784().method_1025(start) > blockEnd.method_1025(start))) {
            player.method_7353(class_2561.method_43470("God Mode blessing failed — look directly at a mob."), true);
            return 0;
        }

        class_1308 target = (class_1308) entityHit.method_17782();
        target.method_6092(new class_1293(class_1294.field_5924, BLESS_DURATION, 1, false, true, true));
        target.method_6092(new class_1293(class_1294.field_5910, BLESS_DURATION, 1, false, true, true));
        target.method_6092(new class_1293(class_1294.field_5907, BLESS_DURATION, 1, false, true, true));
        target.method_6092(new class_1293(class_1294.field_5904, BLESS_DURATION, 1, false, true, true));
        target.method_6092(new class_1293(class_1294.field_5918, BLESS_DURATION, 0, false, true, true));
        target.method_6092(new class_1293(class_1294.field_5912, BLESS_DURATION, 0, false, true, true));

        class_243 position = target.method_73189().method_1031(0.0D, target.method_17682() * 0.5D, 0.0D);
        world.method_65096(class_2398.field_29642, position.field_1352, position.field_1351, position.field_1350, 80, 0.8D, 1.0D, 0.8D, 0.08D);
        world.method_43128(null, position.field_1352, position.field_1351, position.field_1350, class_3417.field_14891, class_3419.field_15248, 1.2F, 1.3F);
        player.method_7353(class_2561.method_43470("The " + target.method_5476().getString() + " has been blessed."), true);
        return 1;
    }

    /**
     * Levitates every mob within 30 blocks of the player up into the sky
     * (the player themselves and other players are never affected).
     */
    static int levitateMobs(class_3222 player) {
        if (!isActive(player.method_5667())) {
            return 0;
        }
        class_3218 world = (class_3218) player.method_51469();
        class_238 searchBox = new class_238(
                player.method_23317() - LEVITATE_RADIUS,
                player.method_23318() - LEVITATE_RADIUS,
                player.method_23321() - LEVITATE_RADIUS,
                player.method_23317() + LEVITATE_RADIUS,
                player.method_23318() + LEVITATE_RADIUS,
                player.method_23321() + LEVITATE_RADIUS
        );
        List<class_1297> mobs = world.method_8333(
                player,
                searchBox,
                entity -> entity instanceof class_1308 mob && mob.method_5805() && !mob.method_7325()
        );
        int count = 0;
        for (class_1297 entity : mobs) {
            if (entity.method_5858(player) > LEVITATE_RADIUS * LEVITATE_RADIUS) {
                continue;
            }
            class_1309 mob = (class_1309) entity;
            mob.method_6092(new class_1293(
                    class_1294.field_5902,
                    LEVITATE_DURATION,
                    LEVITATE_AMPLIFIER,
                    false,
                    true,
                    true
            ));
            count++;
        }

        class_243 center = player.method_73189().method_1031(0.0D, player.method_17682() * 0.5D, 0.0D);
        world.method_65096(class_2398.field_29642, center.field_1352, center.field_1351, center.field_1350, 120, 0.9D, 1.0D, 0.9D, 0.08D);
        world.method_43128(null, center.field_1352, center.field_1351, center.field_1350, class_3417.field_14858, class_3419.field_15248, 1.0F, 0.7F);
        player.method_7353(class_2561.method_43470(count + " mob(s) are ascending to the sky."), true);
        return 1;
    }

    static void adjustFlightSpeed(class_3222 player, int direction){
        if (!isActive(player.method_5667()) || direction == 0) {
            return;
        }

        float currentSpeed = player.method_31549().method_7252();
        float adjustedSpeed = currentSpeed + (direction > 0 ? SPEED_STEP : -SPEED_STEP);
        adjustedSpeed = Math.clamp(adjustedSpeed, GOD_FLIGHT_SPEED_MIN, GOD_FLIGHT_SPEED_MAX);
        adjustedSpeed = Math.round(adjustedSpeed * 1000.0F) / 1000.0F;
        player.method_31549().method_7248(adjustedSpeed);
        player.method_7355();
        player.method_7353(class_2561.method_43470(String.format("God Mode flight speed: %.2f", adjustedSpeed)), true);
    }

    /** Calls down a lightning bolt on whatever the god is looking at. */
    static int smiteTarget(class_3222 player) {
        if (!isActive(player.method_5667()) || onCooldown(SMITE_COOLDOWNS, player, "Smite")) {
            return 0;
        }
        class_3218 world = (class_3218) player.method_51469();
        class_243 start = player.method_5836(1.0F);
        class_243 direction = player.method_5828(1.0F).method_1029();
        class_243 maximumEnd = start.method_1019(direction.method_1021(SMITE_RANGE));
        class_3965 blockHit = world.method_17742(new class_3959(
                start,
                maximumEnd,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                player
        ));
        class_243 blockEnd = blockHit.method_17783() == class_239.class_240.field_1333 ? maximumEnd : blockHit.method_17784();
        class_3966 entityHit = class_1675.method_18075(
                player,
                start,
                maximumEnd,
                player.method_5829().method_18804(direction.method_1021(SMITE_RANGE)).method_1014(1.0D),
                entity -> entity instanceof class_1309 living && living.method_5805() && !entity.method_7325(),
                SMITE_RANGE * SMITE_RANGE
        );

        class_243 strikePos;
        if (entityHit != null
                && (blockHit.method_17783() == class_239.class_240.field_1333
                || entityHit.method_17784().method_1025(start) <= blockEnd.method_1025(start))) {
            strikePos = entityHit.method_17784();
        } else if (blockHit.method_17783() == class_239.class_240.field_1332) {
            strikePos = blockHit.method_17784();
        } else {
            player.method_7353(class_2561.method_43470("Smite failed — aim at a mob or the ground."), true);
            return 0;
        }

        class_1538 bolt = new class_1538(class_1299.field_6112, world);
        bolt.method_5814(strikePos.field_1352, strikePos.field_1351, strikePos.field_1350);
        world.method_8649(bolt);

        class_238 area = new class_238(
                strikePos.field_1352 - SMITE_AOE_RADIUS,
                strikePos.field_1351 - SMITE_AOE_RADIUS,
                strikePos.field_1350 - SMITE_AOE_RADIUS,
                strikePos.field_1352 + SMITE_AOE_RADIUS,
                strikePos.field_1351 + SMITE_AOE_RADIUS,
                strikePos.field_1350 + SMITE_AOE_RADIUS
        );
        int struck = 0;
        for (class_1297 entity : world.method_8333(
                player,
                area,
                e -> e instanceof class_1309 living && living.method_5805() && !e.method_7325()
        )) {
            if (entity.method_5707(strikePos) > SMITE_AOE_RADIUS * SMITE_AOE_RADIUS) {
                continue;
            }
            entity.method_64397(world, world.method_48963().method_48802(player), SMITE_AOE_DAMAGE);
            struck++;
        }
        world.method_65096(
                class_2398.field_29644,
                strikePos.field_1352,
                strikePos.field_1351 + 1.0D,
                strikePos.field_1350,
                40,
                2.0D,
                2.0D,
                2.0D,
                0.1D
        );
        world.method_43128(
                null,
                strikePos.field_1352,
                strikePos.field_1351,
                strikePos.field_1350,
                class_3417.field_14865,
                class_3419.field_15248,
                2.0F,
                1.0F
        );
        SMITE_COOLDOWNS.put(player.method_5667(), SMITE_COOLDOWN);
        player.method_7353(class_2561.method_43470("SMITE — the heavens strike down! " + struck + " hit."), true);
        return 1;
    }

    /** Obliterates blocks and enemies in a sphere around the aimed-at point. */
    static int annihilateArea(class_3222 player) {
        if (!isActive(player.method_5667()) || onCooldown(ANNIHILATE_COOLDOWNS, player, "Annihilate")) {
            return 0;
        }
        class_3218 world = (class_3218) player.method_51469();
        class_243 start = player.method_5836(1.0F);
        class_243 direction = player.method_5828(1.0F).method_1029();
        class_243 maximumEnd = start.method_1019(direction.method_1021(ANNIHILATE_RANGE));
        class_3965 blockHit = world.method_17742(new class_3959(
                start,
                maximumEnd,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                player
        ));
        if (blockHit.method_17783() != class_239.class_240.field_1332) {
            player.method_7353(class_2561.method_43470("Annihilate — aim at the ground or a structure."), true);
            return 0;
        }

        class_243 center = blockHit.method_17784();
        class_2338 centerPos = class_2338.method_49638(center);
        int radius = (int) Math.ceil(ANNIHILATE_RADIUS);
        int destroyed = 0;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    class_2338 position = centerPos.method_10069(dx, dy, dz);
                    if (position.method_10262(centerPos) > ANNIHILATE_RADIUS * ANNIHILATE_RADIUS) {
                        continue;
                    }
                    if (isDestructible(world.method_8320(position))) {
                        world.method_8651(position, false, player);
                        destroyed++;
                    }
                }
            }
        }

        class_238 area = new class_238(
                center.field_1352 - ANNIHILATE_RADIUS,
                center.field_1351 - ANNIHILATE_RADIUS,
                center.field_1350 - ANNIHILATE_RADIUS,
                center.field_1352 + ANNIHILATE_RADIUS,
                center.field_1351 + ANNIHILATE_RADIUS,
                center.field_1350 + ANNIHILATE_RADIUS
        );
        int blasted = 0;
        for (class_1297 entity : world.method_8333(
                player,
                area,
                e -> e instanceof class_1309 living && living.method_5805() && !e.method_7325()
        )) {
            if (entity.method_5707(center) > ANNIHILATE_RADIUS * ANNIHILATE_RADIUS) {
                continue;
            }
            entity.method_64397(world, world.method_48963().method_48802(player), ANNIHILATE_DAMAGE);
            class_243 away = entity.method_73189().method_1020(center);
            double length = away.method_1033();
            if (length > 0.01D) {
                away = away.method_1021(1.8D / length);
                entity.method_5762(away.field_1352, 0.4D, away.field_1350);
                entity.field_64356 = true;
            }
            blasted++;
        }

        world.method_65096(class_2398.field_11221, center.field_1352, center.field_1351, center.field_1350, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        world.method_65096(
                class_2398.field_11239,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                60,
                ANNIHILATE_RADIUS * 0.6D,
                ANNIHILATE_RADIUS * 0.6D,
                ANNIHILATE_RADIUS * 0.6D,
                0.1D
        );
        world.method_65096(
                new class_2388(class_2398.field_11217, class_2246.field_10566.method_9564()),
                center.field_1352,
                center.field_1351,
                center.field_1350,
                80,
                ANNIHILATE_RADIUS,
                ANNIHILATE_RADIUS,
                ANNIHILATE_RADIUS,
                0.3D
        );
        world.method_60511(
                null,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                class_3417.field_15152,
                class_3419.field_15248,
                3.0F,
                0.5F
        );
        ANNIHILATE_COOLDOWNS.put(player.method_5667(), ANNIHILATE_COOLDOWN);
        player.method_7353(class_2561.method_43470(
                "ANNIHILATE — " + destroyed + " blocks reduced to dust, " + blasted + " enemies blasted!"
        ), true);
        return 1;
    }

    /** Heals the god fully and smites every enemy around them with holy light. */
    static int holyNova(class_3222 player) {
        if (!isActive(player.method_5667()) || onCooldown(NOVA_COOLDOWNS, player, "Holy Nova")) {
            return 0;
        }
        class_3218 world = (class_3218) player.method_51469();
        class_243 center = player.method_73189().method_1031(0.0D, player.method_17682() * 0.5D, 0.0D);

        player.method_6033(player.method_6063());
        player.method_5646();
        removeHarmfulEffects(player);

        class_238 area = new class_238(
                center.field_1352 - NOVA_RADIUS,
                center.field_1351 - NOVA_RADIUS,
                center.field_1350 - NOVA_RADIUS,
                center.field_1352 + NOVA_RADIUS,
                center.field_1351 + NOVA_RADIUS,
                center.field_1350 + NOVA_RADIUS
        );
        int smitten = 0;
        for (class_1297 entity : world.method_8333(
                player,
                area,
                e -> e instanceof class_1309 living && living.method_5805() && !e.method_7325()
        )) {
            if (entity.method_5707(center) > NOVA_RADIUS * NOVA_RADIUS) {
                continue;
            }
            entity.method_64397(world, world.method_48963().method_48831(), NOVA_DAMAGE);
            class_243 away = entity.method_73189().method_1020(center);
            double length = away.method_1033();
            if (length > 0.01D) {
                away = away.method_1021(NOVA_KNOCKBACK / length);
                entity.method_5762(away.field_1352, 0.45D, away.field_1350);
                entity.field_64356 = true;
            }
            smitten++;
        }
        world.method_65096(class_2398.field_11220, center.field_1352, center.field_1351, center.field_1350, 40, 0.6D, 1.0D, 0.6D, 0.2D);
        world.method_65096(class_2398.field_29642, center.field_1352, center.field_1351, center.field_1350, 120, NOVA_RADIUS, NOVA_RADIUS, NOVA_RADIUS, 0.05D);
        world.method_43128(null, center.field_1352, center.field_1351, center.field_1350, class_3417.field_14703, class_3419.field_15248, 1.6F, 1.2F);
        NOVA_COOLDOWNS.put(player.method_5667(), NOVA_COOLDOWN);
        player.method_7353(class_2561.method_43470(
                "HOLY NOVA — you are restored, and " + smitten + " enemies are smitten by your light!"
        ), true);
        return 1;
    }

    private static void removeHarmfulEffects(class_3222 player) {
        List<class_6880<class_1291>> harmfulEffects = List.of(
                class_1294.field_5920,
                class_1294.field_5899,
                class_1294.field_5903,
                class_1294.field_5911,
                class_1294.field_5909,
                class_1294.field_5901,
                class_1294.field_5919,
                class_1294.field_5916,
                class_1294.field_38092,
                class_1294.field_5921,
                class_1294.field_5902,
                class_1294.field_5908
        );
        for (class_6880<class_1291> effect : harmfulEffects) {
            player.method_6016(effect);
        }
    }

    /**
     * Omnipotence: for 15 seconds the god becomes a simulation of omnipotence —
     * no damage source can harm them and their body is flooded with divine power.
     */
    static int activateOmnipotence(class_3222 player) {
        if (!isActive(player.method_5667()) || onCooldown(OMNIPOTENCE_COOLDOWNS, player, "Omnipotence")) {
            return 0;
        }
        UUID playerUuid = player.method_5667();
        OMNIPOTENCE_TICKS.put(playerUuid, OMNIPOTENCE_DURATION);
        OMNIPOTENCE_COOLDOWNS.put(playerUuid, OMNIPOTENCE_COOLDOWN);
        applyOmnipotenceEffects(player);

        class_243 center = player.method_73189().method_1031(0.0D, player.method_17682() * 0.5D, 0.0D);
        class_3218 world = (class_3218) player.method_51469();
        world.method_65096(class_2398.field_11220, center.field_1352, center.field_1351, center.field_1350, 60, 0.5D, 1.0D, 0.5D, 0.2D);
        world.method_65096(class_2398.field_29642, center.field_1352, center.field_1351, center.field_1350, 120, 3.0D, 2.0D, 3.0D, 0.05D);
        world.method_43128(
                null,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                class_3417.field_14703,
                class_3419.field_15248,
                1.6F,
                1.1F
        );
        player.method_7353(class_2561.method_43470(
                "OMNIPOTENCE — for 15 seconds nothing can harm you, and everything falls before you!"
        ), true);
        return 1;
    }

    static boolean isOmnipotenceActive(UUID playerUuid) {
        return OMNIPOTENCE_TICKS.getOrDefault(playerUuid, 0) > 0;
    }

    private static void applyOmnipotenceEffects(class_3222 player) {
        player.method_6092(new class_1293(class_1294.field_5910, OMNIPOTENCE_DURATION, 9, false, true, true));
        player.method_6092(new class_1293(class_1294.field_5907, OMNIPOTENCE_DURATION, 9, false, true, true));
        player.method_6092(new class_1293(class_1294.field_5924, OMNIPOTENCE_DURATION, 4, false, true, true));
        player.method_6092(new class_1293(class_1294.field_5898, OMNIPOTENCE_DURATION, 4, false, true, true));
        player.method_6092(new class_1293(class_1294.field_5904, OMNIPOTENCE_DURATION, 2, false, true, true));
        player.method_6092(new class_1293(class_1294.field_5917, OMNIPOTENCE_DURATION, 5, false, true, true));
        player.method_6092(new class_1293(class_1294.field_5913, OMNIPOTENCE_DURATION, 2, false, true, true));
        player.method_6092(new class_1293(class_1294.field_5918, OMNIPOTENCE_DURATION, 0, false, true, true));
        player.method_6092(new class_1293(class_1294.field_5925, OMNIPOTENCE_DURATION, 0, false, true, true));
    }

    private static void tickOmnipotence(class_3222 player, class_3218 world) {
        UUID playerUuid = player.method_5667();
        int remaining = OMNIPOTENCE_TICKS.getOrDefault(playerUuid, 0);
        if (remaining <= 0) {
            return;
        }
        OMNIPOTENCE_TICKS.put(playerUuid, remaining - 1);
        // Re-top the divine statuses so the simulated omnipotence never flickers.
        if (remaining % OMNIPOTENCE_REFRESH_INTERVAL == 0) {
            applyOmnipotenceEffects(player);
        }
        class_243 center = player.method_73189().method_1031(0.0D, player.method_17682() * 0.5D, 0.0D);
        world.method_65096(class_2398.field_29642, center.field_1352, center.field_1351, center.field_1350, 3, 1.2D, 1.5D, 1.2D, 0.04D);
    }

    /** Throws the looked-at mob into the void: heavy damage plus wither and darkness. */
    static int banishTarget(class_3222 player) {
        if (!isActive(player.method_5667()) || onCooldown(BANISH_COOLDOWNS, player, "Banish")) {
            return 0;
        }
        class_3218 world = (class_3218) player.method_51469();
        class_243 start = player.method_5836(1.0F);
        class_243 direction = player.method_5828(1.0F).method_1029();
        class_243 maximumEnd = start.method_1019(direction.method_1021(BANISH_RANGE));
        class_3965 blockHit = world.method_17742(new class_3959(
                start,
                maximumEnd,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                player
        ));
        class_243 blockEnd = blockHit.method_17783() == class_239.class_240.field_1333 ? maximumEnd : blockHit.method_17784();
        class_3966 entityHit = class_1675.method_18075(
                player,
                start,
                maximumEnd,
                player.method_5829().method_18804(direction.method_1021(BANISH_RANGE)).method_1014(1.0D),
                e -> e instanceof class_1308 mob && mob.method_5805() && !e.method_7325(),
                BANISH_RANGE * BANISH_RANGE
        );
        if (entityHit == null
                || (blockHit.method_17783() != class_239.class_240.field_1333
                && entityHit.method_17784().method_1025(start) > blockEnd.method_1025(start))) {
            player.method_7353(class_2561.method_43470("Banishment failed — look directly at a mob."), true);
            return 0;
        }

        class_1309 target = (class_1309) entityHit.method_17782();
        target.method_64397(world, world.method_48963().method_48829(), BANISH_DAMAGE);
        target.method_6092(new class_1293(class_1294.field_5920, 100, 1, false, true, true));
        target.method_6092(new class_1293(class_1294.field_38092, 200, 0, false, true, true));
        class_243 position = target.method_73189().method_1031(0.0D, target.method_17682() * 0.5D, 0.0D);
        world.method_65096(class_2398.field_23190, position.field_1352, position.field_1351, position.field_1350, 60, 0.5D, 1.0D, 0.5D, 0.15D);
        world.method_65096(class_2398.field_11214, position.field_1352, position.field_1351, position.field_1350, 40, 0.8D, 1.2D, 0.8D, 0.1D);
        world.method_43128(
                null,
                position.field_1352,
                position.field_1351,
                position.field_1350,
                class_3417.field_14879,
                class_3419.field_15248,
                1.4F,
                0.7F
        );
        BANISH_COOLDOWNS.put(player.method_5667(), BANISH_COOLDOWN);
        player.method_7353(class_2561.method_43470("The " + target.method_5476().getString() + " has been banished to the void."), true);
        return 1;
    }

    private static boolean onCooldown(
            Map<UUID, Integer> cooldowns,
            class_3222 player,
            String abilityName
    ) {
        int remainingTicks = cooldowns.getOrDefault(player.method_5667(), 0);
        if (remainingTicks > 0) {
            PowerManager.sendCooldownMessage(player, abilityName, remainingTicks);
            return true;
        }
        return false;
    }

    private static void tickCooldowns() {
        tickCooldownMap(SMITE_COOLDOWNS);
        tickCooldownMap(ANNIHILATE_COOLDOWNS);
        tickCooldownMap(NOVA_COOLDOWNS);
        tickCooldownMap(OMNIPOTENCE_COOLDOWNS);
        tickCooldownMap(BANISH_COOLDOWNS);
    }

    private static void tickCooldownMap(Map<UUID, Integer> cooldowns) {
        cooldowns.entrySet().removeIf(entry -> {
            int remaining = entry.getValue() - 1;
            if (remaining <= 0) {
                return true;
            }
            entry.setValue(remaining);
            return false;
        });
    }

    private static boolean isDestructible(class_2680 state) {
        return !state.method_26215()
                && !state.method_27852(class_2246.field_9987)
                && !state.method_27852(class_2246.field_10499)
                && !state.method_27852(class_2246.field_10027)
                && !state.method_27852(class_2246.field_10613);
    }

    private static double distanceSquaredToSegment(class_243 point, class_243 start, class_243 end) {
        class_243 segment = end.method_1020(start);
        double lengthSquared = segment.method_1027();
        if (lengthSquared < 1.0E-6D) {
            return point.method_1025(start);
        }
        double progress = point.method_1020(start).method_1026(segment) / lengthSquared;
        progress = Math.max(0.0D, Math.min(1.0D, progress));
        return point.method_1025(start.method_1019(segment.method_1021(progress)));
    }

    private static void disableGodMode(class_3222 player) {
        UUID playerUuid = player.method_5667();
        ACTIVE_LASERS.remove(playerUuid);
        GOD_MODE_PLAYERS.remove(playerUuid);
        GOD_NOCLIP_PLAYERS.remove(playerUuid);
        CLIENT_GOD_NOCLIP_PLAYERS.remove(playerUuid);
        OMNIPOTENCE_TICKS.remove(playerUuid);
        // HACKY LIGHT cleanup: remove the fake Night Vision we applied; no block to remove.
        player.method_6016(class_1294.field_5925);
        class_1934 previousGameMode = PREVIOUS_GAME_MODES.remove(playerUuid);
        if (previousGameMode != null && player.field_13974.method_14257() == class_1934.field_9220) {
            player.method_7336(previousGameMode);
        }
        player.field_5960 = false;
    }

    static void removePlayer(class_3222 player) {
        UUID playerUuid = player.method_5667();
        disableGodMode(player);
        SMITE_COOLDOWNS.remove(playerUuid);
        ANNIHILATE_COOLDOWNS.remove(playerUuid);
        NOVA_COOLDOWNS.remove(playerUuid);
        OMNIPOTENCE_COOLDOWNS.remove(playerUuid);
        BANISH_COOLDOWNS.remove(playerUuid);
        OMNIPOTENCE_TICKS.remove(playerUuid);
        GOD_NOCLIP_PLAYERS.remove(playerUuid);
        CLIENT_GOD_NOCLIP_PLAYERS.remove(playerUuid);
    }

    static void clearAll() {
        GOD_MODE_PLAYERS.clear();
        GOD_NOCLIP_PLAYERS.clear();
        CLIENT_GOD_NOCLIP_PLAYERS.clear();
        ACTIVE_LASERS.clear();
        PREVIOUS_GAME_MODES.clear();
        SMITE_COOLDOWNS.clear();
        ANNIHILATE_COOLDOWNS.clear();
        NOVA_COOLDOWNS.clear();
        OMNIPOTENCE_COOLDOWNS.clear();
        BANISH_COOLDOWNS.clear();
        OMNIPOTENCE_TICKS.clear();
    }
}
