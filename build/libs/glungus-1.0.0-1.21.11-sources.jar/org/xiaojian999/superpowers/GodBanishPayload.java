package org.xiaojian999.superpowers;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import org.xiaojian999.superpowers.network.AutoPayload;
import org.xiaojian999.superpowers.network.PayloadDirection;

@AutoPayload(direction = PayloadDirection.C2S)
public record GodBanishPayload() implements class_8710 {
    public static final class_8710.class_9154<GodBanishPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(Glungus.MOD_ID, "god_banish"));
    public static final class_9139<class_9129, GodBanishPayload> CODEC =
            class_9139.method_56431(new GodBanishPayload());

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}