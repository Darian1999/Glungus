package org.xiaojian999.superpowers.network;

import org.xiaojian999.superpowers.Glungus;

import java.util.Arrays;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Fallback dynamic payload used when a feature needs network traffic but no
 * dedicated {@link class_8710} class exists yet.
 * <p>
 * This is the core of the "auto-generate if necessary" feature: any code can
 * send arbitrary bytes on a named {@code channel} without defining a new record.
 * The payload is registered bidirectionally ({@code C2S} and {@code S2C}) once
 * at startup via {@link PayloadRegistry}, and then multiplexed by {@code channel}.
 * <p>
 * <b>Example – sending without a dedicated class:</b>
 * <pre>{@code
 * // Client -> Server
 * PayloadRegistry.sendGenericC2S(player, "my_feature/toggle", buf -> buf.writeBoolean(true));
 *
 * // Server handler registered via
 * PayloadRegistry.registerGenericC2SHandler("my_feature/toggle", (payload, context) -> {
 *     boolean value = payload.dataAsBuf().readBoolean();
 * });
 * }</pre>
 */
public record GenericPayload(class_2960 channel, byte[] data) implements class_8710 {

    public static final class_8710.class_9154<GenericPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(Glungus.MOD_ID, "generic"));

    // Bidirectional codec: channel + raw bytes. Use Identifier codec + byte array.
    @SuppressWarnings("unchecked")
    public static final class_9139<class_9129, GenericPayload> CODEC = class_9139.method_56435(
            class_2960.field_48267,
            GenericPayload::channel,
            class_9135.field_48987,
            GenericPayload::data,
            GenericPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }

    /**
     * Convenience factory for a channel under the {@code glungus} namespace.
     */
    public static GenericPayload of(String path, byte[] data) {
        return new GenericPayload(class_2960.method_60655(Glungus.MOD_ID, path), data);
    }

    /**
     * Convenience factory for an arbitrary identifier channel.
     */
    public static GenericPayload of(class_2960 channel, byte[] data) {
        return new GenericPayload(channel, data);
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof GenericPayload that)) return false;
        return channel.equals(that.channel) && Arrays.equals(data, that.data);
    }

    @Override
    public int hashCode() {
        return 31 * channel.hashCode() + Arrays.hashCode(data);
    }

    @Override
    public String toString() {
        return "GenericPayload[channel=" + channel + ", bytes=" + data.length + "]";
    }
}
