package org.xiaojian999.superpowers;

import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1937;

/**
 * A purely visual lightning bolt for the Lightning ultimate. It is cosmetic
 * (never sets fire, powers rods, or strikes entities on its own), so the mod
 * applies the "big lightning" damage itself. The 75% larger appearance is
 * handled client-side by {@code BigLightningEntityRenderer}.
 */
public class BigLightningEntity extends class_1538 {
    public BigLightningEntity(class_1299<? extends class_1538> entityType, class_1937 world) {
        super(entityType, world);
        this.method_29498(true);
    }
}
