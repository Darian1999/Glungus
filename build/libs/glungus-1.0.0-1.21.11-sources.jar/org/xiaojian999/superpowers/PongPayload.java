package org.xiaojian999.superpowers;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import org.xiaojian999.superpowers.network.AutoPayload;
import org.xiaojian999.superpowers.network.PayloadDirection;

/**
 * Example empty payload – demonstrates auto-generation of a unit codec.
 * No CODEC field; registry will generate {@code PacketCodec.unit(new PongPayload())}
 * and register it BOTH directions as an example of bidirectional auto-generation.
 */
@AutoPayload(value = "pong", direction = PayloadDirection.BOTH)
public record PongPayload() implements class_8710 {
    public static final class_8710.class_9154<PongPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(Glungus.MOD_ID, "pong"));

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
