package org.xiaojian999.superpowers;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import org.xiaojian999.superpowers.math.GlungFastMath;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Nature powers: the Flower Trail toggle, the spinning Vine Ring, and the
 * Earthquake of Lucifer ultimate.
 */
final class NaturePowerHandler {
    // ----- Flower trail -----
    // One flower every 0.25 seconds (5 ticks), and never on a block that already
    // holds a flower (the trail never stacks).
    private static final int FLOWER_PLACEMENT_INTERVAL = 5;
    private static final int FLOWER_LIFETIME_TICKS = 200; // 10 seconds
    private static final double FLOWER_DAMAGE_HORIZONTAL = 0.9D;
    private static final double FLOWER_DAMAGE_VERTICAL = 1.4D;
    private static final float FLOWER_TRAIL_DAMAGE = 4.0F; // 2 hearts
    private static final int FLOWER_TRAIL_DAMAGE_INTERVAL = 20; // once per second
    private static final class_2248[] TRAIL_FLOWERS = {
            class_2246.field_10449,
            class_2246.field_10182,
            class_2246.field_10226,
            class_2246.field_10573,
            class_2246.field_10554,
            class_2246.field_9995,
            class_2246.field_10086,
            class_2246.field_10548
    };

    // ----- Vine ring (second power) -----
    private static final int VINE_RING_DURATION = 600; // 30 seconds
    private static final int VINE_RING_COOLDOWN = 600; // 30 seconds after it ends
    private static final double VINE_RING_RADIUS = 1.7D;
    private static final double VINE_RING_THICKNESS = 0.9D;
    private static final double VINE_RING_VERTICAL_HALF = 0.95D;
    private static final float VINE_RING_DAMAGE = 5.0F; // 2.5 hearts per hit
    private static final int VINE_RING_HIT_COOLDOWN = 12;
    private static final double VINE_RING_PUSH = 1.6D;

    // ----- Earthquake of Lucifer (ultimate) -----
    private static final int EARTHQUAKE_DURATION = 1200; // 60 seconds
    private static final int EARTHQUAKE_COOLDOWN = 3000; // 150 seconds — the longest ultimate cooldown
    private static final double EARTHQUAKE_RADIUS = 24.0D;
    private static final int EARTHQUAKE_DAMAGE_INTERVAL = 25;
    private static final int EARTHQUAKE_JOLT_INTERVAL = 8;
    private static final int EARTHQUAKE_TOSS_INTERVAL = 32;
    private static final int EARTHQUAKE_IGNITION_COUNT = 90;

    private static final Set<UUID> FLOWER_TRAIL_PLAYERS = new HashSet<>();
    private static final Map<class_3218, List<ActiveFlower>> ACTIVE_FLOWERS = new HashMap<>();
    private static final Map<class_3218, Set<class_2338>> FLOWER_POSITIONS = new HashMap<>();
    private static final Map<UUID, Integer> TRAIL_DAMAGE_COOLDOWNS = new HashMap<>();

    private static final Map<SlotKey, Integer> VINE_RING_TICKS = new HashMap<>();
    private static final Map<UUID, Map<UUID, Integer>> VINE_RING_HIT_COOLDOWNS = new HashMap<>();

    private static final Map<UUID, ActiveEarthquake> ACTIVE_EARTHQUAKES = new HashMap<>();

    private NaturePowerHandler() {
    }

    // ----- Flower trail -----

    static int toggleFlowerTrail(class_3222 player) {
        UUID playerUuid = player.method_5667();
        if (FLOWER_TRAIL_PLAYERS.contains(playerUuid)) {
            FLOWER_TRAIL_PLAYERS.remove(playerUuid);
            PowerManager.sendPowerStatus(player);
            player.method_7353(class_2561.method_43470("Flower trail disabled — your flowers will fade away."), true);
            return 1;
        }

        FLOWER_TRAIL_PLAYERS.add(playerUuid);
        class_3218 world = (class_3218) player.method_51469();
        class_243 center = player.method_73189();
        world.method_65096(class_2398.field_11211, center.field_1352, center.field_1351 + 1.0D, center.field_1350, 24, 0.8D, 1.0D, 0.8D, 0.08D);
        world.method_43128(
                null,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                class_3417.field_20607,
                class_3419.field_15248,
                1.2F,
                1.0F
        );
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("Flower trail enabled — walk and flowers bloom beneath you."), true);
        return 1;
    }

    static boolean isFlowerTrailActive(UUID playerUuid) {
        return FLOWER_TRAIL_PLAYERS.contains(playerUuid);
    }

    private static void placeTrailFlower(class_3218 world, class_3222 player) {
        if (!player.method_24828()) {
            return;
        }
        // The flower goes into the air block the player's feet are standing in, just
        // above the ground block that supports it — never into the ground itself. The
        // small upward epsilon keeps float drift from flooring onto the block below.
        class_2338 position = class_2338.method_49637(player.method_23317(), player.method_23318() + 0.1D, player.method_23321());
        Set<class_2338> positions = FLOWER_POSITIONS.computeIfAbsent(world, ignored -> new HashSet<>());
        // Skip when this exact spot already has a trail flower (tracked here) or any
        // other block — a placed flower is never overwritten by a new one.
        if (positions.contains(position) || !world.method_8320(position).method_26215()) {
            return;
        }

        class_2680 flower = TRAIL_FLOWERS[world.field_9229.method_43048(TRAIL_FLOWERS.length)].method_9564();
        if (!flower.method_26184(world, position)) {
            return;
        }

        world.method_8652(position, flower, class_2248.field_31036);
        ACTIVE_FLOWERS.computeIfAbsent(world, ignored -> new ArrayList<>())
                .add(new ActiveFlower(player.method_5667(), position, flower, FLOWER_LIFETIME_TICKS));
        positions.add(position);

        double x = position.method_10263() + 0.5D;
        double z = position.method_10260() + 0.5D;
        world.method_65096(class_2398.field_11211, x, position.method_10264() + 1.0D, z, 3, 0.3D, 0.2D, 0.3D, 0.02D);
        world.method_65096(class_2398.field_17741, x, position.method_10264() + 0.9D, z, 2, 0.2D, 0.2D, 0.2D, 0.02D);
    }

    private static void tickFlowers(class_3218 world) {
        List<ActiveFlower> flowers = ACTIVE_FLOWERS.get(world);
        if (flowers == null || flowers.isEmpty()) {
            return;
        }

        for (int index = flowers.size() - 1; index >= 0; index--) {
            ActiveFlower flower = flowers.get(index);
            flower.remainingTicks--;
            if (flower.remainingTicks <= 0) {
                removeFlower(world, flower);
                flowers.remove(index);
            }
        }

        if (!flowers.isEmpty()) {
            damageMobsOnTrail(world, flowers);
        }
        if (flowers.isEmpty()) {
            ACTIVE_FLOWERS.remove(world);
        }
    }

    private static void removeFlower(class_3218 world, ActiveFlower flower) {
        if (world.method_8320(flower.position) == flower.placedState) {
            world.method_8652(flower.position, class_2246.field_10124.method_9564(), class_2248.field_31036);
            double x = flower.position.method_10263() + 0.5D;
            double z = flower.position.method_10260() + 0.5D;
            world.method_65096(
                    class_2398.field_11211,
                    x,
                    flower.position.method_10264() + 1.0D,
                    z,
                    4,
                    0.3D,
                    0.2D,
                    0.3D,
                    0.03D
            );
        }
        Set<class_2338> positions = FLOWER_POSITIONS.get(world);
        if (positions != null) {
            positions.remove(flower.position);
        }
    }

    private static void damageMobsOnTrail(class_3218 world, List<ActiveFlower> flowers) {
        for (ActiveFlower flower : flowers) {
            class_2338 position = flower.position;
            class_238 area = new class_238(
                    position.method_10263() - FLOWER_DAMAGE_HORIZONTAL,
                    position.method_10264() - 0.2D,
                    position.method_10260() - FLOWER_DAMAGE_HORIZONTAL,
                    position.method_10263() + 1.0D + FLOWER_DAMAGE_HORIZONTAL,
                    position.method_10264() + FLOWER_DAMAGE_VERTICAL,
                    position.method_10260() + 1.0D + FLOWER_DAMAGE_HORIZONTAL
            );
            List<class_1297> entities = world.method_8333(
                    null,
                    area,
                    entity -> entity instanceof class_1309 livingEntity
                            && livingEntity.method_5805()
                            && !entity.method_7325()
            );
            for (class_1297 entity : entities) {
                UUID entityUuid = entity.method_5667();
                if (entityUuid.equals(flower.ownerUuid)
                        || TRAIL_DAMAGE_COOLDOWNS.getOrDefault(entityUuid, 0) > 0) {
                    continue;
                }
                class_3222 owner = world.method_8503().method_3760().method_14602(flower.ownerUuid);
                class_1309 target = (class_1309) entity;
                target.method_64397(
                        world,
                        owner != null
                                ? world.method_48963().method_48802(owner)
                                : world.method_48963().method_48831(),
                        FLOWER_TRAIL_DAMAGE
                );
                TRAIL_DAMAGE_COOLDOWNS.put(entityUuid, FLOWER_TRAIL_DAMAGE_INTERVAL);
                class_243 targetPos = target.method_73189();
                world.method_65096(
                        class_2398.field_17741,
                        targetPos.field_1352,
                        targetPos.field_1351 + target.method_17682() * 0.5D,
                        targetPos.field_1350,
                        6,
                        0.4D,
                        0.4D,
                        0.4D,
                        0.04D
                );
            }
        }
    }

    // ----- Vine ring -----

    static int startVineRing(class_3222 player, SlotKey slotKey) {
        if (VINE_RING_TICKS.containsKey(slotKey)) {
            PowerManager.sendPowerStatus(player);
            player.method_7353(class_2561.method_43470("Your vine ring is already spinning."), true);
            return 0;
        }

        int remainingTicks = PowerCooldowns.secondPowerRemaining(slotKey);
        if (remainingTicks > 0) {
            PowerManager.sendPowerStatus(player);
            PowerManager.sendCooldownMessage(player, "Vine Ring", remainingTicks);
            return 0;
        }

        VINE_RING_TICKS.put(slotKey, VINE_RING_DURATION);
        class_3218 world = (class_3218) player.method_51469();
        class_243 center = player.method_73189().method_1031(0.0D, player.method_17682() * 0.55D, 0.0D);
        for (int angle = 0; angle < 360; angle += 20) {
            double radians = angle * GlungFastMath.DEG_TO_RAD;
            double x = center.field_1352 + GlungFastMath.fastCos(radians) * VINE_RING_RADIUS;
            double z = center.field_1350 + GlungFastMath.fastSin(radians) * VINE_RING_RADIUS;
            world.method_65096(class_2398.field_28803, x, center.field_1351, z, 2, 0.1D, 0.1D, 0.1D, 0.02D);
        }
        world.method_43128(
                null,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                class_3417.field_20605,
                class_3419.field_15248,
                1.2F,
                1.5F
        );
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("Vine Ring summoned — a thorned halo spins around you for 30s!"), true);
        return 1;
    }

    static boolean isVineRingActive(SlotKey slotKey) {
        return VINE_RING_TICKS.containsKey(slotKey);
    }

    static Integer getVineRingRemaining(SlotKey slotKey) {
        return VINE_RING_TICKS.get(slotKey);
    }

    private static void endVineRing(class_3222 player, SlotKey slotKey) {
        VINE_RING_TICKS.remove(slotKey);
        PowerCooldowns.setSecondPower(slotKey, VINE_RING_COOLDOWN);
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("Your vine ring unravels. Cooldown: 30s."), true);
    }

    private static void tickVineRing(class_3218 world, class_3222 player, SlotKey slotKey) {
        class_243 center = player.method_73189().method_1031(0.0D, player.method_17682() * 0.55D, 0.0D);
        double spin = world.method_75260() * 0.4D;

        for (int sample = 0; sample < 14; sample++) {
            double angle = spin + sample * GlungFastMath.TAU / 14.0D;
            double x = center.field_1352 + GlungFastMath.fastCos(angle) * VINE_RING_RADIUS;
            double z = center.field_1350 + GlungFastMath.fastSin(angle) * VINE_RING_RADIUS;
            world.method_65096(class_2398.field_28803, x, center.field_1351, z, 1, 0.05D, 0.05D, 0.05D, 0.01D);
            if (sample % 3 == 0) {
                world.method_65096(class_2398.field_11211, x, center.field_1351, z, 1, 0.06D, 0.06D, 0.06D, 0.01D);
            }
            if (sample % 5 == 0) {
                world.method_65096(class_2398.field_43379, x, center.field_1351 + 0.3D, z, 1, 0.08D, 0.08D, 0.08D, 0.01D);
            }
        }

        class_238 area = new class_238(
                center.field_1352 - VINE_RING_RADIUS - 1.0D,
                center.field_1351 - 1.3D,
                center.field_1350 - VINE_RING_RADIUS - 1.0D,
                center.field_1352 + VINE_RING_RADIUS + 1.0D,
                center.field_1351 + 1.3D,
                center.field_1350 + VINE_RING_RADIUS + 1.0D
        );
        List<class_1297> targets = world.method_8333(
                player,
                area,
                entity -> entity instanceof class_1309 livingEntity
                        && livingEntity.method_5805()
                        && !entity.method_7325()
        );
        Map<UUID, Integer> hitCooldowns = VINE_RING_HIT_COOLDOWNS.computeIfAbsent(player.method_5667(), ignored -> new HashMap<>());
        for (class_1297 entity : targets) {
            class_243 entityPos = entity.method_73189();
            double horizontalDistance = Math.sqrt(
                    (entityPos.field_1352 - center.field_1352) * (entityPos.field_1352 - center.field_1352)
                            + (entityPos.field_1350 - center.field_1350) * (entityPos.field_1350 - center.field_1350)
            );
            double verticalCenter = entityPos.field_1351 + entity.method_17682() * 0.5D;
            if (Math.abs(horizontalDistance - VINE_RING_RADIUS) > VINE_RING_THICKNESS
                    || Math.abs(verticalCenter - center.field_1351) > VINE_RING_VERTICAL_HALF) {
                continue;
            }
            if (hitCooldowns.getOrDefault(entity.method_5667(), 0) > 0) {
                continue;
            }

            class_243 away = new class_243(entityPos.field_1352 - center.field_1352, 0.0D, entityPos.field_1350 - center.field_1350);
            double length = away.method_1033();
            if (length < 0.01D) {
                away = new class_243(1.0D, 0.0D, 0.0D);
            } else {
                away = away.method_1021(1.0D / length);
            }
            class_1309 target = (class_1309) entity;
            target.method_5762(away.field_1352 * VINE_RING_PUSH, 0.35D, away.field_1350 * VINE_RING_PUSH);
            target.field_64356 = true;
            target.method_64397(world, world.method_48963().method_48802(player), VINE_RING_DAMAGE);
            hitCooldowns.put(entity.method_5667(), VINE_RING_HIT_COOLDOWN);

            world.method_65096(class_2398.field_28803, entityPos.field_1352, entityPos.field_1351 + 1.0D, entityPos.field_1350, 8, 0.3D, 0.4D, 0.3D, 0.05D);
            world.method_43128(
                    null,
                    entityPos.field_1352,
                    entityPos.field_1351,
                    entityPos.field_1350,
                    class_3417.field_20606,
                    class_3419.field_15248,
                    0.8F,
                    1.2F
            );
        }
    }

    private static void tickVineRings(MinecraftServer server) {
        for (SlotKey slotKey : List.copyOf(VINE_RING_TICKS.keySet())) {
            class_3222 player = server.method_3760().method_14602(slotKey.playerUuid());
            if (player == null) {
                VINE_RING_TICKS.remove(slotKey);
                continue;
            }
            int remaining = VINE_RING_TICKS.getOrDefault(slotKey, 0) - 1;
            if (remaining <= 0) {
                endVineRing(player, slotKey);
                continue;
            }
            VINE_RING_TICKS.put(slotKey, remaining);
            if (player.method_51469() instanceof class_3218 world) {
                tickVineRing(world, player, slotKey);
            }
        }

        VINE_RING_HIT_COOLDOWNS.entrySet().removeIf(playerEntry -> {
            playerEntry.getValue().entrySet().removeIf(hitEntry -> {
                int remaining = hitEntry.getValue() - 1;
                if (remaining <= 0) {
                    return true;
                }
                hitEntry.setValue(remaining);
                return false;
            });
            return playerEntry.getValue().isEmpty();
        });
    }

    // ----- Earthquake of Lucifer -----

    static void startEarthquake(class_3222 player, SlotKey slotKey) {
        UUID playerUuid = player.method_5667();
        ACTIVE_EARTHQUAKES.put(playerUuid, new ActiveEarthquake(EARTHQUAKE_DURATION));
        PowerCooldowns.setUltimate(slotKey, EARTHQUAKE_COOLDOWN);

        class_3218 world = (class_3218) player.method_51469();
        broadcastEarthquake(world, playerUuid, true);
        class_243 center = player.method_73189();
        world.method_65096(class_2398.field_11221, center.field_1352, center.field_1351 + 1.0D, center.field_1350, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        world.method_60511(
                null,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                class_3417.field_15152,
                class_3419.field_15248,
                3.0F,
                0.35F
        );
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("EARTHQUAKE OF LUCIFER — the ground itself rebels for 60 seconds!"), true);
    }

    static boolean isEarthquakeActive(UUID playerUuid) {
        return ACTIVE_EARTHQUAKES.containsKey(playerUuid);
    }

    static Integer getEarthquakeRemaining(UUID playerUuid) {
        ActiveEarthquake earthquake = ACTIVE_EARTHQUAKES.get(playerUuid);
        return earthquake == null ? null : earthquake.remainingTicks;
    }

    static void sendActiveEarthquakes(class_3222 joiningPlayer, MinecraftServer server) {
        for (UUID uuid : ACTIVE_EARTHQUAKES.keySet()) {
            if (server.method_3760().method_14602(uuid) != null) {
                ServerPlayNetworking.send(joiningPlayer, new NatureEarthquakePayload(uuid, true));
            }
        }
    }

    private static void broadcastEarthquake(class_3218 world, UUID playerUuid, boolean active) {
        NatureEarthquakePayload payload = new NatureEarthquakePayload(playerUuid, active);
        for (class_3222 player : world.method_8503().method_3760().method_14571()) {
            ServerPlayNetworking.send(player, payload);
        }
    }

    private static void tickEarthquakes(MinecraftServer server) {
        for (UUID playerUuid : List.copyOf(ACTIVE_EARTHQUAKES.keySet())) {
            ActiveEarthquake earthquake = ACTIVE_EARTHQUAKES.get(playerUuid);
            class_3222 player = server.method_3760().method_14602(playerUuid);
            if (player == null) {
                ACTIVE_EARTHQUAKES.remove(playerUuid);
                continue;
            }

            earthquake.remainingTicks--;
            earthquake.elapsedTicks++;
            if (earthquake.remainingTicks <= 0) {
                endEarthquake(player);
                continue;
            }
            if (player.method_51469() instanceof class_3218 world) {
                tickEarthquake(world, player, earthquake);
            }
        }
    }

    private static void tickEarthquake(class_3218 world, class_3222 player, ActiveEarthquake earthquake) {
        class_243 center = player.method_73189();

        if (earthquake.elapsedTicks % EARTHQUAKE_DAMAGE_INTERVAL == 0) {
            class_238 area = player.method_5829().method_1009(EARTHQUAKE_RADIUS, 12.0D, EARTHQUAKE_RADIUS);
            List<class_1297> targets = world.method_8333(
                    player,
                    area,
                    entity -> entity instanceof class_1309 livingEntity
                            && livingEntity.method_5805()
                            && !entity.method_7325()
            );
            for (class_1297 entity : targets) {
                double distance = entity.method_5707(center);
                if (distance > EARTHQUAKE_RADIUS * EARTHQUAKE_RADIUS) {
                    continue;
                }
                double closeness = 1.0D - Math.sqrt(distance) / EARTHQUAKE_RADIUS;
                float damage = (float) (5.0D + closeness * 6.0D);
                ((class_1309) entity).method_64397(world, world.method_48963().method_48802(player), damage);
                class_243 entityPos = entity.method_73189();
                world.method_65096(class_2398.field_11205, entityPos.field_1352, entityPos.field_1351 + 1.0D, entityPos.field_1350, 8, 0.4D, 0.4D, 0.4D, 0.1D);
            }
        }

        if (earthquake.elapsedTicks % EARTHQUAKE_JOLT_INTERVAL == 0) {
            class_238 area = player.method_5829().method_1009(EARTHQUAKE_RADIUS, 8.0D, EARTHQUAKE_RADIUS);
            List<class_1297> targets = world.method_8333(
                    player,
                    area,
                    entity -> entity instanceof class_1309 livingEntity
                            && livingEntity.method_5805()
                            && !entity.method_7325()
            );
            for (class_1297 entity : targets) {
                if (entity.method_5707(center) > EARTHQUAKE_RADIUS * EARTHQUAKE_RADIUS) {
                    continue;
                }
                // GlungFastMath jitter via deterministic hash for stable shake without Random contention
            double joltX = (GlungFastMath.hash01(entity.method_24515().method_10263(), earthquake.elapsedTicks, 0) - 0.5) * 0.6D;
            double joltZ = (GlungFastMath.hash01(entity.method_24515().method_10260(), earthquake.elapsedTicks, 1) - 0.5) * 0.6D;
                double lift = earthquake.elapsedTicks % EARTHQUAKE_TOSS_INTERVAL == 0
                        ? 0.5D + GlungFastMath.hash01(entity.method_24515().method_10264(), earthquake.elapsedTicks, 2) * 0.25D
                        : 0.05D;
                entity.method_5762(joltX, lift, joltZ);
                entity.field_64356 = true;
            }
        }

        spawnEarthquakeParticles(world, player, center, earthquake.elapsedTicks);
    }

    private static void spawnEarthquakeParticles(
            class_3218 world,
            class_3222 player,
            class_243 center,
            int elapsedTicks
    ) {
        int samples = 6;
        for (int sample = 0; sample < samples; sample++) {
            double angle = world.field_9229.method_43058() * Math.PI * 2.0D;
            double distance = Math.sqrt(world.field_9229.method_43058()) * EARTHQUAKE_RADIUS;
            int x = (int) Math.floor(center.field_1352 + Math.cos(angle) * distance);
            int z = (int) Math.floor(center.field_1350 + Math.sin(angle) * distance);
            int surfaceY = world.method_8624(class_2902.class_2903.field_13197, x, z);
            double y = surfaceY + 1.0D;

            world.method_65096(
                    new class_2388(class_2398.field_11217, class_2246.field_10566.method_9564()),
                    x + 0.5D,
                    y,
                    z + 0.5D,
                    5,
                    0.6D,
                    0.15D,
                    0.6D,
                    0.3D
            );
            if (world.field_9229.method_43048(3) == 0) {
                world.method_65096(
                        new class_2388(class_2398.field_11217, class_2246.field_10445.method_9564()),
                        x + 0.5D,
                        y + 0.6D,
                        z + 0.5D,
                        3,
                        0.4D,
                        0.5D,
                        0.4D,
                        0.35D
                );
            }
            if (world.field_9229.method_43048(4) == 0) {
                world.method_65096(
                        new class_2388(class_2398.field_11206, class_2246.field_10340.method_9564()),
                        x + 0.5D,
                        y + 0.2D,
                        z + 0.5D,
                        2,
                        0.3D,
                        0.3D,
                        0.3D,
                        0.05D
                );
            }
            if (world.field_9229.method_43048(5) == 0) {
                world.method_65096(class_2398.field_11239, x + 0.5D, y - 0.2D, z + 0.5D, 2, 0.2D, 0.1D, 0.2D, 0.05D);
            }
            if (world.field_9229.method_43048(4) == 0) {
                world.method_65096(class_2398.field_11237, x + 0.5D, y, z + 0.5D, 2, 0.3D, 0.3D, 0.3D, 0.02D);
            }
        }

        if (elapsedTicks % 30 == 0) {
            double angle = world.field_9229.method_43058() * Math.PI * 2.0D;
            double distance = 6.0D + world.field_9229.method_43058() * (EARTHQUAKE_RADIUS - 8.0D);
            double x = center.field_1352 + Math.cos(angle) * distance;
            double z = center.field_1350 + Math.sin(angle) * distance;
            int surfaceY = world.method_8624(class_2902.class_2903.field_13197, (int) Math.floor(x), (int) Math.floor(z));
            world.method_65096(class_2398.field_11221, x, surfaceY + 1.0D, z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            world.method_65096(
                    new class_2388(class_2398.field_11217, class_2246.field_10566.method_9564()),
                    x,
                    surfaceY + 1.0D,
                    z,
                    25,
                    1.5D,
                    0.6D,
                    1.5D,
                    0.4D
            );
            world.method_43128(
                    null,
                    x,
                    surfaceY + 1.0D,
                    z,
                    class_3417.field_15026,
                    class_3419.field_15248,
                    1.8F,
                    0.5F
            );
        }

        if (elapsedTicks % 10 == 0 && player.method_5805()) {
            double x = player.method_23317();
            double z = player.method_23321();
            world.method_65096(class_2398.field_11237, x, player.method_23318() + 0.2D, z, 3, 0.5D, 0.3D, 0.5D, 0.02D);
        }
    }

    private static void endEarthquake(class_3222 player) {
        UUID playerUuid = player.method_5667();
        ACTIVE_EARTHQUAKES.remove(playerUuid);
        if (player.method_51469() instanceof class_3218 world) {
            broadcastEarthquake(world, playerUuid, false);
            igniteScorchedBlocks(world, player);
            class_243 center = player.method_73189();
            world.method_65096(class_2398.field_11221, center.field_1352, center.field_1351 + 1.0D, center.field_1350, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            world.method_65096(
                    class_2398.field_11239,
                    center.field_1352,
                    center.field_1351 + 1.0D,
                    center.field_1350,
                    60,
                    EARTHQUAKE_RADIUS * 0.35D,
                    2.0D,
                    EARTHQUAKE_RADIUS * 0.35D,
                    0.1D
            );
            world.method_60511(
                    null,
                    center.field_1352,
                    center.field_1351,
                    center.field_1350,
                    class_3417.field_15152,
                    class_3419.field_15248,
                    2.6F,
                    0.3F
            );
        }
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("The Earthquake of Lucifer subsides — the land is set ablaze!"), true);
    }

    private static void igniteScorchedBlocks(class_3218 world, class_3222 player) {
        class_2338 playerPos = player.method_24515();
        int ignited = 0;
        int attempts = 0;
        while (ignited < EARTHQUAKE_IGNITION_COUNT && attempts < EARTHQUAKE_IGNITION_COUNT * 4) {
            attempts++;
            double angle = world.field_9229.method_43058() * Math.PI * 2.0D;
            double distance = 3.0D + Math.sqrt(world.field_9229.method_43058()) * (EARTHQUAKE_RADIUS - 3.0D);
            int x = (int) Math.floor(player.method_23317() + Math.cos(angle) * distance);
            int z = (int) Math.floor(player.method_23321() + Math.sin(angle) * distance);
            int surfaceY = world.method_8624(class_2902.class_2903.field_13197, x, z);
            class_2338 position = new class_2338(x, surfaceY, z);
            if (isNearPlayer(position, playerPos)) {
                continue;
            }
            for (int dy = 0; dy <= 2 && ignited < EARTHQUAKE_IGNITION_COUNT; dy++) {
                if (tryIgniteBlock(world, position.method_10086(dy))) {
                    ignited++;
                }
            }
        }
    }

    private static boolean isNearPlayer(class_2338 position, class_2338 playerPos) {
        return Math.abs(position.method_10263() - playerPos.method_10263()) <= 1
                && Math.abs(position.method_10264() - playerPos.method_10264()) <= 1
                && Math.abs(position.method_10260() - playerPos.method_10260()) <= 1;
    }

    private static boolean tryIgniteBlock(class_3218 world, class_2338 position) {
        class_2680 state = world.method_8320(position);
        if (!state.method_26215() || !class_2246.field_10036.method_9564().method_26184(world, position)) {
            return false;
        }
        world.method_8652(position, class_2246.field_10036.method_9564(), class_2248.field_31036);
        return true;
    }

    // ----- Per-tick orchestration -----

    static void tick(class_3218 world) {
        tickFlowers(world);
    }

    static void tickServer(MinecraftServer server) {
        TRAIL_DAMAGE_COOLDOWNS.entrySet().removeIf(entry -> {
            int remaining = entry.getValue() - 1;
            if (remaining <= 0) {
                return true;
            }
            entry.setValue(remaining);
            return false;
        });

        if (server.method_3780() % FLOWER_PLACEMENT_INTERVAL == 0) {
            for (UUID playerUuid : FLOWER_TRAIL_PLAYERS) {
                class_3222 player = server.method_3760().method_14602(playerUuid);
                if (player != null && player.method_51469() instanceof class_3218 world) {
                    placeTrailFlower(world, player);
                }
            }
        }

        tickVineRings(server);
        tickEarthquakes(server);
    }

    /** Stops every Nature effect when the player switches to another power. */
    static void clearState(class_3222 player) {
        UUID playerUuid = player.method_5667();
        FLOWER_TRAIL_PLAYERS.remove(playerUuid);
        VINE_RING_HIT_COOLDOWNS.remove(playerUuid);
        for (SlotKey key : List.copyOf(VINE_RING_TICKS.keySet())) {
            if (key.playerUuid().equals(playerUuid)) {
                VINE_RING_TICKS.remove(key);
            }
        }
        ActiveEarthquake earthquake = ACTIVE_EARTHQUAKES.remove(playerUuid);
        if (earthquake != null && player.method_51469() instanceof class_3218 world) {
            broadcastEarthquake(world, playerUuid, false);
        }
    }

    static void removePlayer(class_3222 player) {
        clearState(player);
    }

    static void clearAll() {
        FLOWER_TRAIL_PLAYERS.clear();
        ACTIVE_FLOWERS.clear();
        FLOWER_POSITIONS.clear();
        TRAIL_DAMAGE_COOLDOWNS.clear();
        VINE_RING_TICKS.clear();
        VINE_RING_HIT_COOLDOWNS.clear();
        ACTIVE_EARTHQUAKES.clear();
    }

    private static final class ActiveFlower {
        private final UUID ownerUuid;
        private final class_2338 position;
        private final class_2680 placedState;
        private int remainingTicks;

        private ActiveFlower(UUID ownerUuid, class_2338 position, class_2680 placedState, int lifetimeTicks) {
            this.ownerUuid = ownerUuid;
            this.position = position;
            this.placedState = placedState;
            this.remainingTicks = lifetimeTicks;
        }
    }

    private static final class ActiveEarthquake {
        private int remainingTicks;
        private int elapsedTicks;

        private ActiveEarthquake(int durationTicks) {
            this.remainingTicks = durationTicks;
        }
    }
}
