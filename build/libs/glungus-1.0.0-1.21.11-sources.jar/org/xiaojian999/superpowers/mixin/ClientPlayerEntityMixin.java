package org.xiaojian999.superpowers.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.xiaojian999.superpowers.client.GhostHud;

import java.util.function.Predicate;
import net.minecraft.class_12392;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_746;

/**
 * The local player's position is normally driven by client-side movement
 * prediction, so the server's possession snap never reaches the camera. This
 * snaps the client player onto the possessed body at the end of every tick,
 * which makes the camera track the body smoothly instead of drifting off.
 *
 * <p>The same mixin keeps the possessed body out of the crosshair target: while
 * possessing, the player's eye is inside the body's bounding box, so the entity
 * raycast would always hit the body itself and mining or attacking would target
 * it instead of the block or enemy behind it.
 */
@Mixin(class_746.class)
public abstract class ClientPlayerEntityMixin {
    @Inject(method = "tick", at = @At("RETURN"))
    private void superpowers$possessedBodySnap(CallbackInfo ci) {
        int mobId = GhostHud.getPossessedMobId();
        if (mobId < 0) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return;
        }
        class_1297 mob = client.field_1687.method_8469(mobId);
        if (mob == null || !mob.method_5805()) {
            return;
        }
        class_746 player = (class_746) (Object) this;
        player.method_5814(mob.method_23317(), mob.method_23318(), mob.method_23321());
        player.method_18799(mob.method_18798());
    }

    @Redirect(
            method = "getCrosshairTarget(Lnet/minecraft/entity/Entity;DDF)Lnet/minecraft/util/hit/HitResult;",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/projectile/ProjectileUtil;raycast(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Box;Ljava/util/function/Predicate;D)Lnet/minecraft/util/hit/EntityHitResult;")
    )
    private static class_3966 superpowers$possessedRaycast(
            class_1297 entity,
            class_243 min,
            class_243 max,
            class_238 box,
            Predicate<class_1297> predicate,
            double maxDistance
    ) {
        return class_1675.method_18075(entity, min, max, box, superpowers$excludePossessedBody(predicate), maxDistance);
    }

    @Redirect(
            method = "getCrosshairTarget(FLnet/minecraft/entity/Entity;)Lnet/minecraft/util/hit/HitResult;",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/component/type/AttackRangeComponent;getHitResult(Lnet/minecraft/entity/Entity;FLjava/util/function/Predicate;)Lnet/minecraft/util/hit/HitResult;")
    )
    private class_239 superpowers$possessedAttackRange(
            class_12392 component,
            class_1297 entity,
            float tickDelta,
            Predicate<class_1297> predicate
    ) {
        return component.method_76733(entity, tickDelta, superpowers$excludePossessedBody(predicate));
    }

    /**
     * Excludes the possessed body from entity targeting, mirroring how the
     * raycast never hits the player themselves.
     */
    private static Predicate<class_1297> superpowers$excludePossessedBody(Predicate<class_1297> canHit) {
        int possessedMobId = GhostHud.getPossessedMobId();
        if (possessedMobId < 0) {
            return canHit;
        }
        return canHit.and(entity -> entity == null || entity.method_5628() != possessedMobId);
    }
}
