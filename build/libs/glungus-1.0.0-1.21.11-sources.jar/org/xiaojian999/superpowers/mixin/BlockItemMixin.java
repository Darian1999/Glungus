package org.xiaojian999.superpowers.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.xiaojian999.superpowers.PowerManager;

/**
 * A phasing player (Ghost Form / Storm Form) can be standing inside the space
 * a block is being placed into, and vanilla {@code canPlace} treats the
 * player's own bounding box as an obstruction — so block placement fails while
 * no-clipping. This mirrors Carpet's {@code creativeNoClip} fix: when the
 * placer is currently phasing, check collisions against everything except the
 * placer themselves.
 */
@Mixin(class_1747.class)
public abstract class BlockItemMixin {
    @Redirect(
            method = "canPlace(Lnet/minecraft/item/ItemPlacementContext;Lnet/minecraft/block/BlockState;)Z",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;canPlace(Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/ShapeContext;)Z")
    )
    private boolean superpowers$canPlaceWhilePhasing(
            class_1937 world,
            class_2680 state,
            class_2338 pos,
            class_3726 context,
            class_1750 placementContext,
            class_2680 stateOuter
    ) {
        class_1657 player = placementContext.method_8036();
        if (player != null && PowerManager.isNoClipActive(player)) {
            class_265 shape = state.method_26194(world, pos, context);
            return shape.method_1110() || world.method_8611(player, shape.method_66507(pos));
        }
        return world.method_8628(state, pos, context);
    }
}
