package org.xiaojian999.superpowers.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_2627;
import net.minecraft.class_3619;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.xiaojian999.superpowers.PowerManager;

/**
 * When a piston pushes a shulker box, {@code pushEntities} shoves every entity
 * in the box's path. A phasing player (Ghost Form / Storm Form) standing inside
 * the box would get teleported/pushed around by it; mirroring Carpet's
 * {@code creativeNoClip} fix, report {@link class_3619#field_15975} for players
 * currently no-clipping so the shulker passes straight through them.
 */
@Mixin(class_2627.class)
public abstract class ShulkerBoxBlockEntityMixin {
    @Redirect(
            method = "pushEntities",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getPistonBehavior()Lnet/minecraft/block/piston/PistonBehavior;")
    )
    private class_3619 superpowers$noClipPistonBehavior(class_1297 entity) {
        if (PowerManager.isNoClipActive(entity)) {
            return class_3619.field_15975;
        }
        return entity.method_5657();
    }
}
