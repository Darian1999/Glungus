package org.xiaojian999.superpowers.mixin;

import net.minecraft.class_1680;
import net.minecraft.class_239;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.xiaojian999.superpowers.PowerManager;

@Mixin(class_1680.class)
public abstract class SnowballEntityMixin {
    @Inject(method = "onCollision", at = @At("HEAD"))
    private void superpowers$onCollision(class_239 hitResult, CallbackInfo callbackInfo) {
        PowerManager.handleSnowballCollision((class_1680) (Object) this, hitResult);
    }
}
