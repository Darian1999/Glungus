package org.xiaojian999.superpowers.mixin;

import net.minecraft.class_1007;
import net.minecraft.class_1058;
import net.minecraft.class_11659;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.xiaojian999.superpowers.PowerManager;
import org.xiaojian999.superpowers.client.GodHud;

/**
 * Hides the first-person hands while the local player is in Lightning (Storm)
 * Form, so the player sees only their particle cloud. Also makes the
 * first-person hands translucent when God noclip is enabled.
 */
@Mixin(class_1007.class)
public abstract class PlayerEntityRendererMixin {
    private static final int GOD_HAND_ALPHA = 90; // same as third-person ~35% opacity
    private static final int GOD_HAND_COLOR = (GOD_HAND_ALPHA << 24) | 0x00FFFFFF;

    @Redirect(
            method = "renderArm",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;submitModelPart(Lnet/minecraft/client/model/ModelPart;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IILnet/minecraft/client/texture/Sprite;)V"
            )
    )
    private void superpowers$godNoClipHandTransparent(
            class_11659 queue,
            class_630 part,
            class_4587 matrices,
            class_1921 layer,
            int light,
            int overlay,
            class_1058 sprite
    ) {
        if (GodHud.isGodNoClipActive()) {
            // Use the 11-arg overload with tintedColor = translucent white
            queue.method_73494(part, matrices, layer, light, overlay, sprite, false, false, GOD_HAND_COLOR, null, 0);
        } else {
            queue.method_73491(part, matrices, layer, light, overlay, sprite);
        }
    }

    @Inject(method = "renderRightArm", at = @At("HEAD"), cancellable = true)
    private void superpowers$hideStormFormRightArm(
            class_4587 matrices,
            class_11659 renderCommandQueue,
            int light,
            class_2960 texture,
            boolean thinArm,
            CallbackInfo callbackInfo
    ) {
        if (isLocalPlayerInStormForm()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method = "renderLeftArm", at = @At("HEAD"), cancellable = true)
    private void superpowers$hideStormFormLeftArm(
            class_4587 matrices,
            class_11659 renderCommandQueue,
            int light,
            class_2960 texture,
            boolean thinArm,
            CallbackInfo callbackInfo
    ) {
        if (isLocalPlayerInStormForm()) {
            callbackInfo.cancel();
        }
    }

    private static boolean isLocalPlayerInStormForm() {
        class_310 client = class_310.method_1551();
        return client.field_1724 != null && PowerManager.isClientLightningFormActive(client.field_1724.method_5667());
    }
}
