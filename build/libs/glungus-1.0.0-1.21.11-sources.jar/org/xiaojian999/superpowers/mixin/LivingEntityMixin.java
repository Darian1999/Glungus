package org.xiaojian999.superpowers.mixin;

import net.minecraft.class_1282;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3486;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.xiaojian999.superpowers.PowerManager;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {
    /** Walking on the water's surface moves 45% faster than normal ground speed. */
    private static final float WATER_WALK_SPEED_MULTIPLIER = 1.45F;

    /**
     * While walking on the water's surface, borrow the ice block's slipperiness
     * so movement glides like ice: low friction keeps momentum going, making the
     * water feel slippery underfoot.
     */
    @Redirect(
            method = "travelMidAir",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/block/Block;getSlipperiness()F")
    )
    private float superpowers$waterWalkSlipperiness(class_2248 block) {
        if (block == class_2246.field_10382 && superpowers$isWalkingOnWaterSurface()) {
            return class_2246.field_10295.method_9499();
        }
        return block.method_9499();
    }

    /**
     * Ground movement speed is resolved through {@code getMovementSpeed(float)}
     * inside {@code travelMidAir}; boost it by 45% while walking on water.
     */
    @Redirect(
            method = "getMovementSpeed(F)F",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getMovementSpeed()F")
    )
    private float superpowers$waterWalkSpeed(class_1309 entity) {
        float speed = entity.method_6029();
        if (superpowers$isWalkingOnWaterSurface()) {
            speed *= WATER_WALK_SPEED_MULTIPLIER;
        }
        return speed;
    }

    /**
     * True only while the player is standing on the water's surface with the
     * Water power active — the same state the surface snap in {@code travel}
     * handles, so land movement is never affected.
     */
    private boolean superpowers$isWalkingOnWaterSurface() {
        if (!((Object) this instanceof class_1657 player)
                || !PowerManager.isWaterWalkingActive(player)
                || player.method_7325()) {
            return false;
        }
        return player.method_73183()
                .method_8316(player.method_23314())
                .method_15767(class_3486.field_15517);
    }

    /** God Mode kills mobs immediately when the player hits them. */
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void superpowers$godModeInstantKill(
            class_3218 world,
            class_1282 source,
            float amount,
            CallbackInfoReturnable<Boolean> callbackInfo
    ) {
        if ((Object) this instanceof class_1308
                && source.method_5529() instanceof class_1657 attacker
                && PowerManager.isGodModeActive(attacker)) {
            class_1309 target = (class_1309) (Object) this;
            target.method_6033(0.0F);
            target.method_5768(world);
            callbackInfo.setReturnValue(true);
        }
    }

    /**
     * Storm Form players are living lightning: no damage source can hurt them
     * while the form is active.
     */
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void superpowers$stormFormInvincible(
            class_3218 world,
            class_1282 source,
            float amount,
            CallbackInfoReturnable<Boolean> callbackInfo
    ) {
        if (PowerManager.isLightningFormActive((class_1309) (Object) this)) {
            callbackInfo.setReturnValue(false);
        }
    }

    /**
     * Omnipotence is a simulation of absolute power: while it lasts, no damage
     * source — not even the void — can touch the god.
     */
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void superpowers$omnipotenceInvincible(
            class_3218 world,
            class_1282 source,
            float amount,
            CallbackInfoReturnable<Boolean> callbackInfo
    ) {
        if (PowerManager.isOmnipotenceActive((class_1309) (Object) this)) {
            callbackInfo.setReturnValue(false);
        }
    }

    @Inject(method = "getGravity", at = @At("RETURN"), cancellable = true)
    private void superpowers$reduceAirGravity(CallbackInfoReturnable<Double> callbackInfo) {
        if ((Object) this instanceof class_1657 player
                && player.method_31549().field_7478
                && !player.method_68878()
                && !player.method_7325()) {
            callbackInfo.setReturnValue(callbackInfo.getReturnValueD() * 0.85D);
        }
    }

    @Inject(method = "travel", at = @At("TAIL"))
    private void superpowers$walkOnWater(class_243 movementInput, CallbackInfo callbackInfo) {
        if (!((Object) this instanceof class_1657 player)
                || !PowerManager.isWaterWalkingActive(player)
                || player.method_7325()) {
            return;
        }

        boolean swimming = player.method_5715()
                || player.method_5681()
                || Math.abs(movementInput.field_1351) > 1.0E-4D;
        if (swimming) {
            // The previous surface snap marks the player as grounded. Clear that stale state
            // before vanilla water movement handles vertical input (jump/sneak) again.
            if (player.method_5799()) {
                player.method_24830(false);
            }
            return;
        }

        class_2338 waterPosition = class_2338.method_49637(player.method_23317(), player.method_23318() - 0.1D, player.method_23321());
        if (!player.method_73183().method_8316(waterPosition).method_15767(class_3486.field_15517)) {
            return;
        }

        double waterSurface = waterPosition.method_10264() + 1.0D;
        if (player.method_23318() < waterSurface + 0.2D && player.method_23318() > waterSurface - 1.5D) {
            player.method_5814(player.method_23317(), waterSurface, player.method_23321());
            player.method_18800(player.method_18798().field_1352, 0.0D, player.method_18798().field_1350);
            player.method_24830(true);
        }
    }
}
