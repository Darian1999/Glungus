package org.xiaojian999.superpowers.client;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_310;

/**
 * Client-side tracker for active Earthquakes of Lucifer, driven by
 * {@code NatureEarthquakePayload}. The camera shakes while the local player is
 * near an epicenter, with intensity fading with distance.
 */
public final class EarthquakeClientState {
    private static final double SHAKE_RADIUS = 32.0D;

    private static final Set<UUID> ACTIVE_EARTHQUAKES = new HashSet<>();

    private EarthquakeClientState() {
    }

    public static void setActive(UUID playerUuid, boolean active) {
        if (active) {
            ACTIVE_EARTHQUAKES.add(playerUuid);
        } else {
            ACTIVE_EARTHQUAKES.remove(playerUuid);
        }
    }

    /** 0 when no quake is shaking the local player, up to 1 right at an epicenter. */
    public static double shakeIntensity() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return 0.0D;
        }
        double intensity = 0.0D;
        for (UUID uuid : ACTIVE_EARTHQUAKES) {
            class_1657 owner = client.field_1687.method_18470(uuid);
            if (owner == null) {
                continue;
            }
            double distance = Math.sqrt(owner.method_5858(client.field_1724));
            if (distance < SHAKE_RADIUS) {
                intensity = Math.max(intensity, 1.0D - distance / SHAKE_RADIUS);
            }
        }
        return intensity;
    }

    public static void clear() {
        ACTIVE_EARTHQUAKES.clear();
    }
}
