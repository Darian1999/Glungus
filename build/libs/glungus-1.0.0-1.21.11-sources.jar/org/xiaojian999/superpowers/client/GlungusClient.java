package org.xiaojian999.superpowers.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_5619;
import org.lwjgl.glfw.GLFW;
import org.xiaojian999.superpowers.*;
import org.xiaojian999.superpowers.network.PayloadDirection;
import org.xiaojian999.superpowers.network.PayloadRegistry;
import org.xiaojian999.superpowers.network.client.PayloadRegistryClient;

import java.util.UUID;

public class GlungusClient implements ClientModInitializer {
    private static boolean godLaserPressed;
    private static boolean devNotificationPending = false;

    private static final class_304.class_11900 KEY_CATEGORY = class_304.class_11900.method_74698(
            class_2960.method_60655(Glungus.MOD_ID, "powers")
    );

    private static final class_304 FIRST_POWER_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.first_power",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_1,
            KEY_CATEGORY
    ));
    private static final class_304 SECOND_POWER_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.second_power",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_2,
            KEY_CATEGORY
    ));
    private static final class_304 ULTIMATE_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.ultimate",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_3,
            KEY_CATEGORY
    ));
    private static final class_304 FOURTH_POWER_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.fourth_power",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_4,
            KEY_CATEGORY
    ));
    private static final class_304 FIFTH_POWER_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.fifth_power",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_5,
            KEY_CATEGORY
    ));
    private static final class_304 SIXTH_POWER_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.sixth_power",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_6,
            KEY_CATEGORY
    ));
    private static final class_304 GHOST_SPEED_UP_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.ghost_speed_up",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_ADD,
            KEY_CATEGORY
    ));
    private static final class_304 GOD_LASER_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.god_laser",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_9,
            KEY_CATEGORY
    ));
    private static final class_304 GOD_BLESS_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.god_bless",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_7,
            KEY_CATEGORY
    ));
    private static final class_304 GOD_LEVITATE_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.god_levitate",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_8,
            KEY_CATEGORY
    ));
    private static final class_304 GOD_SMITE_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.god_smite",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_0,
            KEY_CATEGORY
    ));
    private static final class_304 GOD_ANNIHILATE_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.god_annihilate",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_DECIMAL,
            KEY_CATEGORY
    ));
    private static final class_304 GOD_NOVA_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.god_nova",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_ENTER,
            KEY_CATEGORY
    ));
    private static final class_304 GOD_OMNIPOTENCE_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.god_omnipotence",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_MULTIPLY,
            KEY_CATEGORY
    ));
    private static final class_304 GOD_BANISH_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.god_banish",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_DIVIDE,
            KEY_CATEGORY
    ));
    private static final class_304 GHOST_SPEED_DOWN_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.ghost_speed_down",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_SUBTRACT,
            KEY_CATEGORY
    ));
    private static final class_304 GOD_NOCLIP_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.glungus.god_noclip",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_BACKSLASH,
            KEY_CATEGORY
    ));

    @Override
    public void onInitializeClient() {
        class_5619.method_32173(ModEntities.BIG_LIGHTNING, BigLightningEntityRenderer::new);
        IceHud.initialize();
        AirHud.initialize();
        FireHud.initialize();
        WaterHud.initialize();
        GhostHud.initialize();
        LightningHud.initialize();
        NatureHud.initialize();
        GodHud.initialize();
        DualHud.initialize();
        // Ensure S2C payloads are registered on the client if Glungus common init was missed
        // (e.g. in dev env or when payloads are added at runtime). Also registers generic fallback.
        PayloadRegistry.ensureRegistered(PowerStatusPayload.class, PayloadDirection.S2C);
        PayloadRegistry.ensureRegistered(LightningFormStatePayload.class, PayloadDirection.S2C);
        PayloadRegistry.ensureRegistered(NatureEarthquakePayload.class, PayloadDirection.S2C);
        PayloadRegistryClient.registerGenericClient();

        // Dev-build notice: once the world loads, show a chat message if this is a developer build
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            if (!Glungus.isDevBuild()) return;
            devNotificationPending = true;
        });

        ClientPlayNetworking.registerGlobalReceiver(PowerStatusPayload.ID, (payload, context) ->
                context.client().execute(() -> {
                    HudState.applyStatus(payload.slotIndex(), payload);
                    if (context.client().field_1724 != null) {
                        UUID playerUuid = context.client().field_1724.method_5667();
                        PowerManager.setClientWaterWalking(playerUuid, HudState.isWaterWalking());
                        PowerManager.setClientGhostFormActive(playerUuid, HudState.isGhostFormActive());
                        PowerManager.setClientLightningFormActive(playerUuid, HudState.isLightningFormActive());
                        PowerManager.setClientGodNoClipActive(playerUuid, HudState.isGodNoClipActive());
                    }
                }));
        ClientPlayNetworking.registerGlobalReceiver(LightningFormStatePayload.ID, (payload, context) ->
                context.client().execute(() ->
                        PowerManager.setClientLightningFormActive(payload.playerUuid(), payload.active())));
        ClientPlayNetworking.registerGlobalReceiver(NatureEarthquakePayload.ID, (payload, context) ->
                context.client().execute(() ->
                        EarthquakeClientState.setActive(payload.playerUuid(), payload.active())));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            HudState.tick();
            if (client.method_1562() == null) {
                godLaserPressed = false;
                devNotificationPending = false;
                return;
            }
            // Flush dev-build notification once world is fully loaded and player exists
            if (devNotificationPending && client.field_1724 != null) {
                devNotificationPending = false;
                if (Glungus.isDevBuild()) {
                    String version = Glungus.getVersion();
                    client.field_1724.method_7353(
                            class_2561.method_43470("⚠ You are running a developer build of Glungus (" + version + ") — this build may be unstable and is not intended for public release.")
                                    .method_27695(class_124.field_1065, class_124.field_1067),
                            false
                    );
                }
            }

            boolean laserPressed = GOD_LASER_KEY.method_1434();
            if (laserPressed != godLaserPressed) {
                ClientPlayNetworking.send(new GodLaserPayload(laserPressed));
                godLaserPressed = laserPressed;
            }
            while (GOD_BLESS_KEY.method_1436()) {
                ClientPlayNetworking.send(new GodBlessPayload());
            }
            while (GOD_LEVITATE_KEY.method_1436()) {
                ClientPlayNetworking.send(new GodLevitatePayload());
            }
            while (GOD_SMITE_KEY.method_1436()) {
                ClientPlayNetworking.send(new GodSmitePayload());
            }
            while (GOD_ANNIHILATE_KEY.method_1436()) {
                ClientPlayNetworking.send(new GodAnnihilatePayload());
            }
            while (GOD_NOVA_KEY.method_1436()) {
                ClientPlayNetworking.send(new GodNovaPayload());
            }
            while (GOD_OMNIPOTENCE_KEY.method_1436()) {
                ClientPlayNetworking.send(new GodOmnipotencePayload());
            }
            while (GOD_BANISH_KEY.method_1436()) {
                ClientPlayNetworking.send(new GodBanishPayload());
            }
            while (GOD_NOCLIP_KEY.method_1436()) {
                if (GodHud.isGodModeActive()) {
                    ClientPlayNetworking.send(new GodNoClipPayload());
                }
            }
            if (client.field_1724 != null && GhostHud.isGhostFormActive()) {
                // Ghost Form grants creative flight and phases through walls only
                // while flying; re-assert flight every tick so the player cannot
                // toggle it off mid-form.
                client.field_1724.method_31549().field_7479 = true;
            }
            if (client.field_1724 != null && HudState.isGodNoClipActive()) {
                // God noclip = flight-locked phasing; keep airborne client-side too
                // so space double-tap can't drop the player before the server corrects it.
                if (!client.field_1724.method_31549().field_7478) {
                    client.field_1724.method_31549().field_7478 = true;
                }
                if (!client.field_1724.method_31549().field_7479) {
                    client.field_1724.method_31549().field_7479 = true;
                }
            }

            while (FIRST_POWER_KEY.method_1436()) {
                ClientPlayNetworking.send(new UsePowerPayload(1));
            }
            while (SECOND_POWER_KEY.method_1436()) {
                ClientPlayNetworking.send(new UsePowerPayload(2));
            }
            while (ULTIMATE_KEY.method_1436()) {
                ClientPlayNetworking.send(new UsePowerPayload(3));
            }
            while (FOURTH_POWER_KEY.method_1436()) {
                ClientPlayNetworking.send(new UsePowerPayload(4));
            }
            while (FIFTH_POWER_KEY.method_1436()) {
                ClientPlayNetworking.send(new UsePowerPayload(5));
            }
            while (SIXTH_POWER_KEY.method_1436()) {
                ClientPlayNetworking.send(new UsePowerPayload(6));
            }
            while (GHOST_SPEED_UP_KEY.method_1436()) {
                if (GhostHud.isGhostFormActive()) {
                    ClientPlayNetworking.send(new GhostFlightSpeedPayload(1));
                }
                if (GodHud.isGodModeActive()) {
                    ClientPlayNetworking.send(new GodFlightSpeedPayload(1));
                }
            }
            while (GHOST_SPEED_DOWN_KEY.method_1436()) {
                if (GhostHud.isGhostFormActive()) {
                    ClientPlayNetworking.send(new GhostFlightSpeedPayload(-1));
                }
                if (GodHud.isGodModeActive()) {
                    ClientPlayNetworking.send(new GodFlightSpeedPayload(-1));
                }
            }
        });
    }
}
