package org.xiaojian999.superpowers.client;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.xiaojian999.superpowers.PowerStatusPayload;
import org.xiaojian999.superpowers.Glungus;

import static org.xiaojian999.superpowers.client.AbilityHudSupport.drawAbilityCard;
import static org.xiaojian999.superpowers.client.AbilityHudSupport.drawDecorations;
import static org.xiaojian999.superpowers.client.AbilityHudSupport.drawPanel;

public final class NatureHud {
    private static final class_2960 HUD_ID = class_2960.method_60655(Glungus.MOD_ID, "nature_hud");

    private NatureHud() {
    }

    public static void initialize() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.BOSS_BAR, HUD_ID, NatureHud::render);
    }

    private static void render(class_332 drawContext, class_9779 tickCounter) {
        class_310 client = class_310.method_1551();
        if (HudState.isDual() || client.field_1724 == null || client.field_1690.field_1842) {
            return;
        }
        HudState.Slot slot = HudState.slot(0);
        if (!"nature".equals(slot.power)) {
            return;
        }

        HudData.Layout layout = HudData.layout();
        HudData.PowerConfig config = HudData.power("nature");
        if (layout == null || config == null) {
            return;
        }
        HudData.PowerConfig.Palette palette = config.palette;
        HudData.Layout.Header header = layout.header;

        float inverseGuiScale = 1.0F / client.method_22683().method_4495();
        drawContext.method_51448().pushMatrix();
        drawContext.method_51448().scale(inverseGuiScale);

        int panelWidth = AbilityHudSupport.panelWidth(client, layout);
        int panelX = layout.panel.x;
        int panelY = layout.panel.y;
        int cardY = panelY + layout.card.top;

        drawPanel(drawContext, panelX, panelY, panelWidth, layout.panel.height, HudData.color(config.accent), layout, config);

        int textMaxWidth = panelWidth - header.paddingX * 2;
        AbilityHudSupport.drawTextClipped(
                drawContext,
                client.field_1772,
                config.title,
                panelX + header.paddingX,
                panelY + header.titleY,
                textMaxWidth,
                HudData.color(palette.primaryText)
        );
        AbilityHudSupport.drawTextClipped(
                drawContext,
                client.field_1772,
                config.subtitle,
                panelX + header.paddingX,
                panelY + header.subtitleY,
                textMaxWidth,
                HudData.color(palette.subtitleText)
        );

        drawDecorations(drawContext, panelX, panelY, panelWidth, config);

        int cardGap = layout.card.gap;
        int cardWidth = (panelWidth - header.paddingX * 2 - cardGap * 2) / 3;
        int cardHeight = layout.card.height;
        int firstCardX = panelX + header.paddingX;

        boolean flowerTrailActive = (slot.flags & PowerStatusPayload.NATURE_FLOWER_TRAIL_ACTIVE) != 0;

        drawAbilityCard(
                drawContext,
                client.field_1772,
                firstCardX,
                cardY,
                cardWidth,
                cardHeight,
                layout,
                config.cards.get(0),
                0,
                flowerTrailActive,
                config
        );
        drawAbilityCard(
                drawContext,
                client.field_1772,
                firstCardX + cardWidth + cardGap,
                cardY,
                cardWidth,
                cardHeight,
                layout,
                config.cards.get(1),
                slot.snowballCooldown,
                false,
                config
        );
        drawAbilityCard(
                drawContext,
                client.field_1772,
                firstCardX + (cardWidth + cardGap) * 2,
                cardY,
                cardWidth,
                cardHeight,
                layout,
                config.cards.get(2),
                slot.ultimateCooldown,
                slot.ultimatePromptTicks > 0,
                config
        );

        int footerY = panelY + layout.footer.y;
        AbilityHudSupport.drawCenteredTextClipped(
                drawContext,
                client.field_1772,
                slot.ultimatePromptTicks > 0 ? config.footer.prompt : config.footer.hint,
                panelX + panelWidth / 2,
                footerY,
                panelWidth - header.paddingX * 2,
                HudData.color(slot.ultimatePromptTicks > 0 ? palette.primaryText : palette.dimText)
        );

        drawContext.method_51448().popMatrix();
    }
}
