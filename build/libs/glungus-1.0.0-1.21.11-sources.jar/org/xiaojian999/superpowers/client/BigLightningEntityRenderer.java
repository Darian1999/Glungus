package org.xiaojian999.superpowers.client;

import net.minecraft.class_10041;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_919;

/**
 * Renders {@link org.xiaojian999.superpowers.BigLightningEntity} bolts. The
 * whole bolt model is scaled by 1.75x around its origin, making it 75% bigger
 * than a normal lightning bolt.
 */
public class BigLightningEntityRenderer extends class_919 {
    private static final float SCALE = 1.75F;

    public BigLightningEntityRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public void method_4034(
            class_10041 state,
            class_4587 matrices,
            class_11659 renderCommandQueue,
            class_12075 cameraRenderState
    ) {
        matrices.method_22903();
        matrices.method_22905(SCALE, SCALE, SCALE);
        super.method_4034(state, matrices, renderCommandQueue, cameraRenderState);
        matrices.method_22909();
    }
}
