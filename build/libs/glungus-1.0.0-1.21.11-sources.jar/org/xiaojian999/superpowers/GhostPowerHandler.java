package org.xiaojian999.superpowers;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_10185;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1934;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5134;

/** Ghost powers: spectral form, the Wail of the Damned, Soul Nova, and mob possession. */
final class GhostPowerHandler {
    private static final int GHOST_WAIL_COOLDOWN = 200;
    private static final double GHOST_WAIL_RADIUS = 9.0D;
    private static final float GHOST_WAIL_DAMAGE = 14.0F;
    private static final int GHOST_WAIL_SLOWNESS_DURATION = 120;
    private static final int GHOST_WAIL_SLOWNESS_AMPLIFIER = 1;
    private static final double GHOST_WAIL_KNOCKBACK = 2.2D;
    private static final int GHOST_SOUL_MARK_DURATION = 200;
    private static final int GHOST_SOUL_MARK_TICK_INTERVAL = 8;
    private static final double GHOST_SOUL_NOVA_RADIUS = 14.0D;
    private static final float GHOST_SOUL_NOVA_DAMAGE = 12.0F;
    private static final float GHOST_SOUL_NOVA_MARK_DAMAGE = 20.0F;
    private static final float GHOST_SOUL_NOVA_CHAIN_DAMAGE = 10.0F;
    private static final double GHOST_SOUL_NOVA_CHAIN_RADIUS = 3.5D;
    private static final float GHOST_SOUL_NOVA_HEAL = 4.0F;
    private static final float GHOST_SOUL_NOVA_HEAL_PER_SOUL = 1.0F;
    private static final double POSSESSION_GRAVITY = 0.08D;
    private static final double POSSESSION_TERMINAL_FALL_SPEED = 2.0D;
    private static final float GHOST_FLIGHT_SPEED_STEP = 0.01F;
    private static final float GHOST_FLIGHT_SPEED_MIN = 0.01F;
    private static final float GHOST_FLIGHT_SPEED_MAX = 0.50F;

    private static final Set<UUID> GHOST_FORM_PLAYERS = new HashSet<>();
    private static final Set<UUID> CLIENT_GHOST_FORM_PLAYERS = new HashSet<>();
    private static final Map<UUID, class_1934> GHOST_PREVIOUS_GAMEMODES = new HashMap<>();
    private static final Map<UUID, Float> GHOST_PREVIOUS_FLY_SPEEDS = new HashMap<>();
    private static final Map<UUID, Map<UUID, Integer>> SOUL_MARKED_ENTITIES = new HashMap<>();
    private static final Map<UUID, UUID> POSSESSED_MOBS = new HashMap<>();

    private GhostPowerHandler() {
    }

    static int toggleForm(class_3222 player) {
        UUID playerUuid = player.method_5667();
        if (GHOST_FORM_PLAYERS.contains(playerUuid)) {
            disableForm(player);
            PowerManager.sendPowerStatus(player);
            player.method_7353(class_2561.method_43470("Ghost form disabled."), true);
            return 1;
        }

        GHOST_PREVIOUS_GAMEMODES.put(playerUuid, player.field_13974.method_14257());
        GHOST_PREVIOUS_FLY_SPEEDS.put(playerUuid, player.method_31549().method_7252());
        GHOST_FORM_PLAYERS.add(playerUuid);
        player.method_7336(class_1934.field_9220);
        player.method_31549().field_7478 = true;
        player.method_31549().field_7479 = true;
        player.method_7355();
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("Ghost form enabled — spectral body, creative flight, and wall phasing. Keypad +/- changes flight speed."), true);
        return 1;
    }

    static void disableForm(class_3222 player) {
        endPossession(player);
        UUID playerUuid = player.method_5667();
        if (!GHOST_FORM_PLAYERS.remove(playerUuid)) {
            return;
        }

        class_1934 previousMode = GHOST_PREVIOUS_GAMEMODES.remove(playerUuid);
        if (previousMode != null) {
            player.method_7336(previousMode);
        }
        Float previousFlySpeed = GHOST_PREVIOUS_FLY_SPEEDS.remove(playerUuid);
        if (previousFlySpeed != null) {
            player.method_31549().method_7248(previousFlySpeed);
            player.method_7355();
        }
        if (!player.method_68878() && !player.method_7325()) {
            player.method_31549().field_7478 = false;
            player.method_31549().field_7479 = false;
            player.method_7355();
        }
    }

    static boolean isFormActive(UUID playerUuid) {
        return GHOST_FORM_PLAYERS.contains(playerUuid);
    }

    static void adjustFlightSpeed(class_3222 player, int direction) {
        if (!isFormActive(player.method_5667()) || direction == 0) {
            return;
        }

        float currentSpeed = player.method_31549().method_7252();
        float adjustedSpeed = currentSpeed + (direction > 0 ? GHOST_FLIGHT_SPEED_STEP : -GHOST_FLIGHT_SPEED_STEP);
        adjustedSpeed = Math.max(GHOST_FLIGHT_SPEED_MIN, Math.min(GHOST_FLIGHT_SPEED_MAX, adjustedSpeed));
        adjustedSpeed = Math.round(adjustedSpeed * 1000.0F) / 1000.0F;
        player.method_31549().method_7248(adjustedSpeed);
        player.method_7355();
        player.method_7353(class_2561.method_43470(String.format("Ghost flight speed: %.2f", adjustedSpeed)), true);
    }

    static boolean isClientFormActive(UUID playerUuid) {
        return CLIENT_GHOST_FORM_PLAYERS.contains(playerUuid);
    }

    static void setClientFormActive(UUID playerUuid, boolean active) {
        if (active) {
            CLIENT_GHOST_FORM_PLAYERS.add(playerUuid);
        } else {
            CLIENT_GHOST_FORM_PLAYERS.remove(playerUuid);
        }
    }

    static boolean isPossessing(UUID playerUuid) {
        return POSSESSED_MOBS.containsKey(playerUuid);
    }

    static boolean isPossessed(UUID mobUuid) {
        return POSSESSED_MOBS.containsValue(mobUuid);
    }

    static class_1308 getPossessedMob(class_3222 player) {
        UUID mobUuid = POSSESSED_MOBS.get(player.method_5667());
        if (mobUuid == null || !(player.method_51469() instanceof class_3218 world)) {
            return null;
        }
        class_1297 entity = world.method_66347(mobUuid);
        return entity instanceof class_1308 mob && mob.method_5805() ? mob : null;
    }

    static void possess(class_3222 player, class_1308 mob) {
        endPossession(player);
        startPossession(player, mob);
    }

    static int wailOfTheDamned(class_3222 player, SlotKey slotKey) {
        int remainingTicks = PowerCooldowns.secondPowerRemaining(slotKey);
        if (remainingTicks > 0) {
            PowerManager.sendPowerStatus(player);
            PowerManager.sendCooldownMessage(player, "Wail of the Damned", remainingTicks);
            return 0;
        }

        class_3218 world = (class_3218) player.method_51469();
        class_243 center = player.method_73189();
        class_238 area = player.method_5829().method_1014(GHOST_WAIL_RADIUS);
        List<class_1297> targets = world.method_8333(
                player,
                area,
                entity -> entity instanceof class_1309 livingEntity
                        && livingEntity.method_5805()
                        && !entity.method_7325()
        );
        for (class_1297 entity : targets) {
            if (player.method_5858(entity) > GHOST_WAIL_RADIUS * GHOST_WAIL_RADIUS) {
                continue;
            }
            class_1309 target = (class_1309) entity;
            target.method_64397(world, world.method_48963().method_48802(player), GHOST_WAIL_DAMAGE);
            target.method_37222(new class_1293(
                    class_1294.field_5909,
                    GHOST_WAIL_SLOWNESS_DURATION,
                    GHOST_WAIL_SLOWNESS_AMPLIFIER,
                    false,
                    true,
                    true
            ), player);
            class_243 away = target.method_73189().method_1020(center);
            double distance = away.method_1033();
            if (distance > 0.001D) {
                class_243 knockback = away.method_1021(GHOST_WAIL_KNOCKBACK / distance);
                target.method_5762(knockback.field_1352, 0.5D, knockback.field_1350);
                target.field_64356 = true;
            }

            markSoul(player.method_5667(), target);
            class_243 targetCenter = target.method_73189().method_1031(0.0D, target.method_17682() * 0.5D, 0.0D);
            world.method_65096(
                    class_2398.field_38002,
                    targetCenter.field_1352,
                    targetCenter.field_1351,
                    targetCenter.field_1350,
                    10,
                    0.3D,
                    0.3D,
                    0.3D,
                    0.05D
            );
        }

        world.method_65096(
                class_2398.field_38002,
                center.field_1352,
                center.field_1351 + 1.0D,
                center.field_1350,
                120,
                GHOST_WAIL_RADIUS,
                1.5D,
                GHOST_WAIL_RADIUS,
                0.08D
        );
        world.method_65096(
                class_2398.field_23114,
                center.field_1352,
                center.field_1351 + 1.0D,
                center.field_1350,
                60,
                GHOST_WAIL_RADIUS * 0.6D,
                1.0D,
                GHOST_WAIL_RADIUS * 0.6D,
                0.04D
        );
        world.method_43128(
                null,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                class_3417.field_14588,
                class_3419.field_15248,
                1.6F,
                0.5F
        );
        PowerCooldowns.setSecondPower(slotKey, GHOST_WAIL_COOLDOWN);
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("Wail of the Damned — souls marked! Soul Nova will detonate them."), true);
        return 1;
    }

    private static void markSoul(UUID ghostUuid, class_1309 target) {
        SOUL_MARKED_ENTITIES
                .computeIfAbsent(ghostUuid, ignored -> new HashMap<>())
                .put(target.method_5667(), GHOST_SOUL_MARK_DURATION);
    }

    static void unleashSoulNova(class_3222 player) {
        class_3218 world = (class_3218) player.method_51469();
        UUID playerUuid = player.method_5667();
        class_243 center = player.method_73189().method_1031(0.0D, 1.0D, 0.0D);
        class_238 area = player.method_5829().method_1014(GHOST_SOUL_NOVA_RADIUS);
        List<class_1297> targets = world.method_8333(
                player,
                area,
                entity -> entity instanceof class_1309 livingEntity
                        && livingEntity.method_5805()
                        && !entity.method_7325()
        );

        Map<UUID, Integer> marks = SOUL_MARKED_ENTITIES.get(playerUuid);
        Set<UUID> detonatedSouls = new HashSet<>();
        for (class_1297 entity : targets) {
            if (player.method_5858(entity) > GHOST_SOUL_NOVA_RADIUS * GHOST_SOUL_NOVA_RADIUS) {
                continue;
            }
            class_1309 target = (class_1309) entity;
            target.method_64397(world, world.method_48963().method_48802(player), GHOST_SOUL_NOVA_DAMAGE);
            if (marks != null && marks.containsKey(target.method_5667())) {
                detonatedSouls.add(target.method_5667());
            }
            class_243 away = target.method_73189().method_1020(center);
            double distance = away.method_1033();
            if (distance > 0.001D) {
                class_243 knockback = away.method_1021(2.6D / distance);
                target.method_5762(knockback.field_1352, 0.9D, knockback.field_1350);
                target.field_64356 = true;
            }
        }

        int detonations = 0;
        for (UUID soulUuid : detonatedSouls) {
            class_1297 soulEntity = world.method_66347(soulUuid);
            if (!(soulEntity instanceof class_1309 markedTarget) || !markedTarget.method_5805()) {
                continue;
            }
            detonations++;
            markedTarget.method_64397(world, world.method_48963().method_48802(player), GHOST_SOUL_NOVA_MARK_DAMAGE);

            class_243 soulPos = markedTarget.method_73189().method_1031(0.0D, markedTarget.method_17682() * 0.5D, 0.0D);
            world.method_65096(
                    class_2398.field_38002,
                    soulPos.field_1352,
                    soulPos.field_1351,
                    soulPos.field_1350,
                    30,
                    1.2D,
                    1.2D,
                    1.2D,
                    0.12D
            );
            world.method_65096(
                    class_2398.field_22246,
                    soulPos.field_1352,
                    soulPos.field_1351,
                    soulPos.field_1350,
                    12,
                    0.6D,
                    0.6D,
                    0.6D,
                    0.06D
            );
            world.method_43128(
                    null,
                    soulPos.field_1352,
                    soulPos.field_1351,
                    soulPos.field_1350,
                    class_3417.field_15231,
                    class_3419.field_15248,
                    1.4F,
                    0.4F
            );

            class_238 chainArea = markedTarget.method_5829().method_1014(GHOST_SOUL_NOVA_CHAIN_RADIUS);
            List<class_1297> chainTargets = world.method_8333(
                    player,
                    chainArea,
                    entity -> entity instanceof class_1309 livingEntity
                            && livingEntity.method_5805()
                            && !entity.method_7325()
                            && entity != markedTarget
            );
            for (class_1297 chainEntity : chainTargets) {
                if (chainEntity.method_5858(markedTarget)
                        > GHOST_SOUL_NOVA_CHAIN_RADIUS * GHOST_SOUL_NOVA_CHAIN_RADIUS) {
                    continue;
                }
                class_1309 chainTarget = (class_1309) chainEntity;
                chainTarget.method_64397(world, world.method_48963().method_48802(player), GHOST_SOUL_NOVA_CHAIN_DAMAGE);
                class_243 away = chainTarget.method_73189().method_1020(markedTarget.method_73189());
                double distance = away.method_1033();
                if (distance > 0.001D) {
                    class_243 knockback = away.method_1021(1.8D / distance);
                    chainTarget.method_5762(knockback.field_1352, 0.5D, knockback.field_1350);
                    chainTarget.field_64356 = true;
                }
            }
        }

        player.method_6025(GHOST_SOUL_NOVA_HEAL + detonations * GHOST_SOUL_NOVA_HEAL_PER_SOUL);
        if (marks != null) {
            marks.keySet().removeAll(detonatedSouls);
        }

        world.method_65096(
                class_2398.field_38002,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                200,
                GHOST_SOUL_NOVA_RADIUS,
                2.0D,
                GHOST_SOUL_NOVA_RADIUS,
                0.1D
        );
        world.method_65096(
                class_2398.field_22246,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                120,
                GHOST_SOUL_NOVA_RADIUS * 0.5D,
                1.5D,
                GHOST_SOUL_NOVA_RADIUS * 0.5D,
                0.05D
        );
        for (int angle = 0; angle < 360; angle += 15) {
            double radians = Math.toRadians(angle);
            double x = player.method_23317() + Math.cos(radians) * GHOST_SOUL_NOVA_RADIUS;
            double z = player.method_23321() + Math.sin(radians) * GHOST_SOUL_NOVA_RADIUS;
            world.method_65096(class_2398.field_38002, x, player.method_23318() + 0.3D, z, 4, 0.15D, 0.5D, 0.15D, 0.02D);
        }
        world.method_43128(
                null,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                class_3417.field_37364,
                class_3419.field_15248,
                2.0F,
                0.6F
        );
        if (detonations > 0) {
            player.method_7353(class_2561.method_43470(
                    "Soul Nova — " + detonations + " marked " + (detonations == 1 ? "soul" : "souls") + " detonated!"
            ), true);
        } else {
            player.method_7353(class_2561.method_43470("Soul Nova — the dead cry out, but no marked souls are claimed."), true);
        }
    }

    static void tickPlayer(class_3222 player) {
        if (GHOST_FORM_PLAYERS.contains(player.method_5667()) && !player.method_31549().field_7479) {
            // Ghost Form phases through walls only while flying; keep the
            // server-side state airborne so the form can't be dropped.
            player.method_31549().field_7479 = true;
            player.method_7355();
        }
        tickPossession(player);
    }

    static void tick(class_3218 world) {
        if (SOUL_MARKED_ENTITIES.isEmpty()) {
            return;
        }

        SOUL_MARKED_ENTITIES.entrySet().removeIf(ownerEntry -> {
            ownerEntry.getValue().entrySet().removeIf(markEntry -> {
                int remainingTicks = markEntry.getValue() - 1;
                if (remainingTicks <= 0) {
                    return true;
                }
                markEntry.setValue(remainingTicks);
                class_1297 target = world.method_66347(markEntry.getKey());
                if (target != null && target.method_5805() && remainingTicks % GHOST_SOUL_MARK_TICK_INTERVAL == 0) {
                    class_243 position = target.method_73189().method_1031(0.0D, target.method_17682() * 0.5D, 0.0D);
                    world.method_65096(
                            class_2398.field_38002,
                            position.field_1352,
                            position.field_1351,
                            position.field_1350,
                            2,
                            0.25D,
                            0.25D,
                            0.25D,
                            0.02D
                    );
                }
                return false;
            });
            return ownerEntry.getValue().isEmpty();
        });
    }

    private static void startPossession(class_3222 player, class_1308 mob) {
        UUID playerUuid = player.method_5667();
        POSSESSED_MOBS.put(playerUuid, mob.method_5667());
        player.method_5648(true);
        mob.method_5977(true);
        mob.method_5980(null);
        mob.method_5942().method_6340();
        mob.method_5971();
        snapPlayerToMob(player, mob);
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470(
                "You possess the " + mob.method_5476().getString() + "! Sneak to return to your spectral body."
        ), true);
    }

    private static void tickPossession(class_3222 player) {
        UUID playerUuid = player.method_5667();
        UUID mobUuid = POSSESSED_MOBS.get(playerUuid);
        if (mobUuid == null) {
            return;
        }
        if (!(player.method_51469() instanceof class_3218 world)
                || !(world.method_66347(mobUuid) instanceof class_1308 mob)
                || !mob.method_5805()) {
            endPossession(player);
            return;
        }

        // Keep the possessed body docile and protected from fire.
        mob.method_5977(true);
        mob.method_5980(null);
        mob.method_5942().method_6340();
        if (!mob.method_6059(class_1294.field_5918)) {
            mob.method_6092(new class_1293(
                    class_1294.field_5918,
                    40,
                    0,
                    false,
                    false,
                    false
            ));
        }

        // Face the body wherever the player looks so input maps to first-person control.
        float yaw = player.method_36454();
        mob.method_36456(yaw);
        mob.method_5847(yaw);
        mob.method_5636(yaw);

        steerPossessedBody(mob, player.method_63562(), yaw);

        // Lock the player to the body: player position = mob position, so moving the
        // mob moves the player and interactions happen at the body's position.
        snapPlayerToMob(player, mob);

        if (player.method_5715()) {
            endPossession(player);
        }
    }

    private static void steerPossessedBody(class_1308 mob, class_10185 input, float yaw) {
        double forward = (input.comp_3159() ? 1.0D : 0.0D) - (input.comp_3160() ? 1.0D : 0.0D);
        // Vanilla's strafe convention: positive = left (A), negative = right (D).
        double strafe = (input.comp_3161() ? 1.0D : 0.0D) - (input.comp_3162() ? 1.0D : 0.0D);

        double yawRadians = Math.toRadians(yaw);
        double sin = Math.sin(yawRadians);
        double cos = Math.cos(yawRadians);
        double dx = -sin * forward + cos * strafe;
        double dz = cos * forward + sin * strafe;
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length > 0.001D) {
            dx /= length;
            dz /= length;
        }
        // The movementSpeed field is only kept fresh by the mob's AI (MoveControl), which is
        // disabled while possessed, so read the underlying attribute instead.
        double speed = mob.method_45325(class_5134.field_23719);

        double vy = mob.method_18798().field_1351;
        if (mob.method_24828()) {
            vy = 0.0D;
        } else {
            vy = Math.max(vy - POSSESSION_GRAVITY, -POSSESSION_TERMINAL_FALL_SPEED);
        }
        if (input.comp_3163() && mob.method_24828()) {
            mob.method_6043();
            vy = mob.method_18798().field_1351;
        }

        mob.method_18800(dx * speed, vy, dz * speed);
        mob.method_5784(class_1313.field_6308, new class_243(dx * speed, vy, dz * speed));
        mob.field_64356 = true;
    }

    private static void snapPlayerToMob(class_3222 player, class_1308 mob) {
        player.method_5814(mob.method_23317(), mob.method_23318(), mob.method_23321());
        player.method_18799(mob.method_18798());
        player.field_64356 = true;
    }

    private static void endPossession(class_3222 player) {
        UUID playerUuid = player.method_5667();
        UUID mobUuid = POSSESSED_MOBS.remove(playerUuid);
        if (mobUuid == null) {
            return;
        }

        player.method_5648(false);
        if (player.method_51469() instanceof class_3218 world
                && world.method_66347(mobUuid) instanceof class_1308 mob) {
            mob.method_5977(false);
            mob.method_5942().method_6340();
            mob.method_6016(class_1294.field_5918);
        }
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("You release the body and return to your spectral form."), true);
    }

    static void removePlayer(class_3222 player) {
        disableForm(player);
        UUID playerUuid = player.method_5667();
        SOUL_MARKED_ENTITIES.remove(playerUuid);
        CLIENT_GHOST_FORM_PLAYERS.remove(playerUuid);
    }

    static void clearAll() {
        GHOST_FORM_PLAYERS.clear();
        GHOST_PREVIOUS_GAMEMODES.clear();
        GHOST_PREVIOUS_FLY_SPEEDS.clear();
        CLIENT_GHOST_FORM_PLAYERS.clear();
        SOUL_MARKED_ENTITIES.clear();
        POSSESSED_MOBS.clear();
    }
}
