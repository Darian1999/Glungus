package org.xiaojian999.superpowers;

import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.xiaojian999.superpowers.network.AutoPayload;
import org.xiaojian999.superpowers.network.PayloadDirection;

/**
 * Tells every client when a player's Earthquake of Lucifer (the Nature
 * ultimate) starts and ends, so cameras near the epicenter can shake.
 */
@AutoPayload(direction = PayloadDirection.S2C)
public record NatureEarthquakePayload(UUID playerUuid, boolean active) implements class_8710 {
    public static final class_8710.class_9154<NatureEarthquakePayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(Glungus.MOD_ID, "nature_earthquake"));
    public static final class_9139<class_9129, NatureEarthquakePayload> CODEC = class_9139.method_56435(
            class_4844.field_48453,
            NatureEarthquakePayload::playerUuid,
            class_9135.field_48547,
            NatureEarthquakePayload::active,
            NatureEarthquakePayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}