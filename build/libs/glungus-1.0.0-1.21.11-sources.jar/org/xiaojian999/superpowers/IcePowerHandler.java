package org.xiaojian999.superpowers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1675;
import net.minecraft.class_1680;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

/** Ice powers: ice beam, empowered snowballs that freeze terrain, and the Glacial Cataclysm ultimate. */
final class IcePowerHandler {
    private static final double ICE_BEAM_RANGE = 20.0D;
    private static final float ICE_BEAM_DAMAGE = 0.5F;
    private static final int ICE_SLOWNESS_DURATION = 100;
    private static final int ICE_SLOWNESS_AMPLIFIER = 3;
    private static final int ICE_BEAM_COOLDOWN = 40;
    private static final int ICE_SNOWBALL_COOLDOWN = 100;
    private static final int TEMPORARY_ICE_DURATION = 200;
    private static final double ULTIMATE_RADIUS = 12.0D;
    private static final float ULTIMATE_DAMAGE = 6.0F;
    private static final int ULTIMATE_SLOWNESS_DURATION = 160;
    private static final int ULTIMATE_SLOWNESS_AMPLIFIER = 4;
    private static final int ULTIMATE_FROZEN_TICKS = 160;

    private static final Set<UUID> ARMED_SNOWBALL_PLAYERS = new HashSet<>();
    private static final Set<UUID> EMPOWERED_SNOWBALLS = new HashSet<>();
    private static final Map<class_3218, List<TemporaryIceCube>> TEMPORARY_ICE_CUBES = new HashMap<>();
    private static final Map<class_3218, Map<class_2338, class_2680>> ORIGINAL_ICE_STATES = new HashMap<>();
    private static final Map<class_3218, Map<class_2338, Integer>> ICE_BLOCK_COUNTS = new HashMap<>();

    private IcePowerHandler() {
    }

    static int fireIceBeam(class_3222 player, SlotKey slotKey) {
        int remainingTicks = PowerCooldowns.beamRemaining(slotKey);
        if (remainingTicks > 0) {
            PowerManager.sendPowerStatus(player);
            PowerManager.sendCooldownMessage(player, "Ice beam", remainingTicks);
            return 0;
        }

        fireIceBeam(player);
        PowerCooldowns.setBeam(slotKey, ICE_BEAM_COOLDOWN);
        PowerManager.sendPowerStatus(player);
        return 1;
    }

    static int primeIceSnowball(class_3222 player, SlotKey slotKey) {
        int remainingTicks = PowerCooldowns.secondPowerRemaining(slotKey);
        if (remainingTicks > 0) {
            PowerManager.sendPowerStatus(player);
            PowerManager.sendCooldownMessage(player, "Ice snowball", remainingTicks);
            return 0;
        }
        if (ARMED_SNOWBALL_PLAYERS.contains(player.method_5667())) {
            PowerManager.sendPowerStatus(player);
            player.method_7353(class_2561.method_43470("Your Ice snowball power is already primed."), true);
            return 0;
        }

        ARMED_SNOWBALL_PLAYERS.add(player.method_5667());
        PowerManager.sendPowerStatus(player);
        player.method_7353(class_2561.method_43470("Your next thrown snowball will create temporary ice."), true);
        return 1;
    }

    static void onSnowballLoaded(class_1680 snowball, class_3222 owner) {
        UUID ownerUuid = owner.method_5667();
        Power primary = PowerManager.getEquippedPower(ownerUuid, 0);
        Power secondary = PowerManager.getEquippedPower(ownerUuid, 1);
        if ((primary != Power.ICE && secondary != Power.ICE) || !ARMED_SNOWBALL_PLAYERS.remove(ownerUuid)) {
            return;
        }

        EMPOWERED_SNOWBALLS.add(snowball.method_5667());
        int iceSlot = primary == Power.ICE ? 0 : 1;
        PowerCooldowns.setSecondPower(new SlotKey(ownerUuid, iceSlot), ICE_SNOWBALL_COOLDOWN);
        PowerManager.sendPowerStatus(owner);
    }

    static void handleSnowballCollision(class_1680 snowball, class_239 hitResult) {
        if (snowball.method_73183() instanceof class_3218 world
                && EMPOWERED_SNOWBALLS.remove(snowball.method_5667())) {
            spawnTemporaryIceCube(world, hitResult);
        }
    }

    static void clearPrimedSnowball(UUID playerUuid) {
        ARMED_SNOWBALL_PLAYERS.remove(playerUuid);
    }

    static boolean isSnowballPrimed(UUID playerUuid) {
        return ARMED_SNOWBALL_PLAYERS.contains(playerUuid);
    }

    static void unleashGlacialCataclysm(class_3222 player) {
        class_3218 world = (class_3218) player.method_51469();
        class_238 area = player.method_5829().method_1014(ULTIMATE_RADIUS);
        List<class_1297> targets = world.method_8333(
                player,
                area,
                entity -> entity instanceof class_1309 livingEntity
                        && livingEntity.method_5805()
                        && !livingEntity.method_7325()
        );

        for (class_1297 entity : targets) {
            if (player.method_5858(entity) > ULTIMATE_RADIUS * ULTIMATE_RADIUS) {
                continue;
            }

            class_1309 target = (class_1309) entity;
            target.method_64397(world, world.method_48963().method_48802(player), ULTIMATE_DAMAGE);
            target.method_37222(new class_1293(
                    class_1294.field_5909,
                    ULTIMATE_SLOWNESS_DURATION,
                    ULTIMATE_SLOWNESS_AMPLIFIER,
                    false,
                    true,
                    true
            ), player);
            target.method_32317(Math.max(target.method_32312(), ULTIMATE_FROZEN_TICKS));

            class_243 away = target.method_73189().method_1020(player.method_73189());
            double distance = away.method_1033();
            if (distance > 0.001D) {
                class_243 knockback = away.method_1021(1.4D / distance);
                target.method_5762(knockback.field_1352, 0.7D, knockback.field_1350);
                target.field_64356 = true;
            }
        }

        class_243 center = player.method_73189().method_1031(0.0D, 1.0D, 0.0D);
        world.method_65096(
                class_2398.field_28013,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                250,
                ULTIMATE_RADIUS,
                3.0D,
                ULTIMATE_RADIUS,
                0.08D
        );
        world.method_65096(
                class_2398.field_11204,
                center.field_1352,
                center.field_1351,
                center.field_1350,
                80,
                ULTIMATE_RADIUS * 0.7D,
                1.0D,
                ULTIMATE_RADIUS * 0.7D,
                0.12D
        );
        for (int angle = 0; angle < 360; angle += 12) {
            double radians = Math.toRadians(angle);
            double x = player.method_23317() + Math.cos(radians) * ULTIMATE_RADIUS;
            double z = player.method_23321() + Math.sin(radians) * ULTIMATE_RADIUS;
            world.method_65096(class_2398.field_28013, x, player.method_23318() + 0.2D, z, 5, 0.15D, 0.8D, 0.15D, 0.03D);
        }
        world.method_43128(
                null,
                player.method_23317(),
                player.method_23318(),
                player.method_23321(),
                class_3417.field_15081,
                class_3419.field_15248,
                2.0F,
                0.5F
        );
        player.method_7353(class_2561.method_43470("Glacial Cataclysm unleashed!"), true);
    }

    private static void fireIceBeam(class_3222 player) {
        class_3218 world = (class_3218) player.method_51469();
        class_243 start = player.method_5836(1.0F);
        class_243 direction = player.method_5828(1.0F).method_1029();
        class_243 maximumEnd = start.method_1019(direction.method_1021(ICE_BEAM_RANGE));

        class_3965 blockHit = world.method_17742(new class_3959(
                start,
                maximumEnd,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                player
        ));
        class_243 beamEnd = blockHit.method_17783() == class_239.class_240.field_1333 ? maximumEnd : blockHit.method_17784();

        class_238 searchBox = player.method_5829().method_18804(direction.method_1021(ICE_BEAM_RANGE)).method_1014(1.0D);
        class_3966 entityHit = class_1675.method_18075(
                player,
                start,
                maximumEnd,
                searchBox,
                entity -> !entity.method_7325() && entity.method_5863(),
                ICE_BEAM_RANGE * ICE_BEAM_RANGE
        );

        if (entityHit != null
                && (blockHit.method_17783() == class_239.class_240.field_1333
                || entityHit.method_17784().method_1025(start) <= beamEnd.method_1025(start))) {
            beamEnd = entityHit.method_17784();
            class_1297 target = entityHit.method_17782();
            target.method_64397(world, world.method_48963().method_48802(player), ICE_BEAM_DAMAGE);
            if (target instanceof class_1309 livingTarget) {
                livingTarget.method_37222(new class_1293(
                        class_1294.field_5909,
                        ICE_SLOWNESS_DURATION,
                        ICE_SLOWNESS_AMPLIFIER,
                        false,
                        true,
                        true
                ), player);
            }
        }

        spawnBeamParticles(world, start, beamEnd);
        world.method_43128(
                null,
                beamEnd.field_1352,
                beamEnd.field_1351,
                beamEnd.field_1350,
                class_3417.field_14583,
                class_3419.field_15248,
                0.7F,
                1.5F
        );
    }

    private static void spawnBeamParticles(class_3218 world, class_243 start, class_243 end) {
        class_243 beam = end.method_1020(start);
        double length = beam.method_1033();
        if (length == 0.0D) {
            return;
        }

        class_243 direction = beam.method_1029();
        for (double distance = 0.0D; distance <= length; distance += 0.35D) {
            class_243 position = start.method_1019(direction.method_1021(distance));
            world.method_65096(
                    class_2398.field_11207,
                    position.field_1352,
                    position.field_1351,
                    position.field_1350,
                    1,
                    0.015D,
                    0.015D,
                    0.015D,
                    0.0D
            );
            if ((int) (distance * 10.0D) % 10 == 0) {
                world.method_65096(
                        class_2398.field_28013,
                        position.field_1352,
                        position.field_1351,
                        position.field_1350,
                        2,
                        0.04D,
                        0.04D,
                        0.04D,
                        0.0D
                );
            }
        }
        world.method_65096(
                class_2398.field_28013,
                end.field_1352,
                end.field_1351,
                end.field_1350,
                18,
                0.25D,
                0.25D,
                0.25D,
                0.04D
        );
    }

    private static void spawnTemporaryIceCube(class_3218 world, class_239 hitResult) {
        class_2338 center;
        if (hitResult instanceof class_3965 blockHit) {
            center = blockHit.method_17777().method_10093(blockHit.method_17780());
        } else {
            center = class_2338.method_49638(hitResult.method_17784());
        }

        Set<class_2338> positions = new HashSet<>();
        Map<class_2338, class_2680> originalStates = ORIGINAL_ICE_STATES.computeIfAbsent(world, ignored -> new HashMap<>());
        Map<class_2338, Integer> blockCounts = ICE_BLOCK_COUNTS.computeIfAbsent(world, ignored -> new HashMap<>());

        for (int x = -2; x <= 2; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -2; z <= 2; z++) {
                    class_2338 position = center.method_10069(x, y, z).method_10062();
                    positions.add(position);
                    originalStates.putIfAbsent(position, world.method_8320(position));
                    blockCounts.merge(position, 1, Integer::sum);
                    world.method_8652(position, class_2246.field_10295.method_9564(), class_2248.field_31036);
                }
            }
        }

        TEMPORARY_ICE_CUBES.computeIfAbsent(world, ignored -> new ArrayList<>())
                .add(new TemporaryIceCube(positions, TEMPORARY_ICE_DURATION));
        world.method_65096(
                class_2398.field_28013,
                center.method_10263() + 0.5D,
                center.method_10264() + 0.5D,
                center.method_10260() + 0.5D,
                100,
                2.5D,
                2.5D,
                2.5D,
                0.08D
        );
        world.method_8396(
                null,
                center,
                class_3417.field_14843,
                class_3419.field_15248,
                1.2F,
                1.2F
        );
    }

    static void tick(class_3218 world) {
        List<TemporaryIceCube> cubes = TEMPORARY_ICE_CUBES.get(world);
        if (cubes == null) {
            return;
        }

        for (int index = cubes.size() - 1; index >= 0; index--) {
            TemporaryIceCube cube = cubes.get(index);
            cube.remainingTicks--;
            if (cube.remainingTicks <= 0) {
                restoreIceCube(world, cube.positions);
                cubes.remove(index);
            }
        }

        if (cubes.isEmpty()) {
            TEMPORARY_ICE_CUBES.remove(world);
        }
    }

    private static void restoreIceCube(class_3218 world, Set<class_2338> positions) {
        Map<class_2338, class_2680> originalStates = ORIGINAL_ICE_STATES.get(world);
        Map<class_2338, Integer> blockCounts = ICE_BLOCK_COUNTS.get(world);
        if (originalStates == null || blockCounts == null) {
            return;
        }

        for (class_2338 position : positions) {
            int remainingCubes = blockCounts.getOrDefault(position, 0) - 1;
            if (remainingCubes > 0) {
                blockCounts.put(position, remainingCubes);
                continue;
            }

            class_2680 originalState = originalStates.remove(position);
            blockCounts.remove(position);
            if (originalState != null && world.method_8320(position).method_27852(class_2246.field_10295)) {
                world.method_8652(position, originalState, class_2248.field_31036);
            }
        }

        if (originalStates.isEmpty()) {
            ORIGINAL_ICE_STATES.remove(world);
        }
        if (blockCounts.isEmpty()) {
            ICE_BLOCK_COUNTS.remove(world);
        }
    }

    static void removePlayer(UUID playerUuid) {
        ARMED_SNOWBALL_PLAYERS.remove(playerUuid);
    }

    static void clearAll() {
        ARMED_SNOWBALL_PLAYERS.clear();
        EMPOWERED_SNOWBALLS.clear();
        TEMPORARY_ICE_CUBES.clear();
        ORIGINAL_ICE_STATES.clear();
        ICE_BLOCK_COUNTS.clear();
    }

    private static final class TemporaryIceCube {
        private final Set<class_2338> positions;
        private int remainingTicks;

        private TemporaryIceCube(Set<class_2338> positions, int remainingTicks) {
            this.positions = positions;
            this.remainingTicks = remainingTicks;
        }
    }
}
