package org.xiaojian999.superpowers;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.xiaojian999.superpowers.network.AutoPayload;
import org.xiaojian999.superpowers.network.PayloadDirection;

@AutoPayload(direction = PayloadDirection.S2C)
public record PowerStatusPayload(
        int flags,
        int beamCooldown,
        int snowballCooldown,
        int ultimateCooldown,
        int possessedMobId,
        float cameraOffsetY,
        int slotIndex
) implements class_8710 {
    public static final int ICE_EQUIPPED = 1;
    public static final int SNOWBALL_PRIMED = 1 << 1;
    public static final int ULTIMATE_PRIMED = 1 << 2;
    public static final int AIR_EQUIPPED = 1 << 3;
    public static final int AIR_FLIGHT_ACTIVE = 1 << 4;
    public static final int FIRE_EQUIPPED = 1 << 5;
    public static final int FIRE_BEAM_ACTIVE = 1 << 6;
    public static final int FIRE_IMMUNE_ACTIVE = 1 << 7;
    public static final int WATER_EQUIPPED = 1 << 8;
    public static final int GHOST_EQUIPPED = 1 << 9;
    public static final int GHOST_FORM_ACTIVE = 1 << 10;
    public static final int GHOST_POSSESSING = 1 << 11;
    public static final int LIGHTNING_EQUIPPED = 1 << 12;
    public static final int LIGHTNING_FORM_ACTIVE = 1 << 13;
    public static final int NATURE_EQUIPPED = 1 << 14;
    public static final int NATURE_FLOWER_TRAIL_ACTIVE = 1 << 15;
    public static final int NATURE_VINE_RING_ACTIVE = 1 << 16;
    public static final int NATURE_EARTHQUAKE_ACTIVE = 1 << 17;
    public static final int GOD_EQUIPPED = 1 << 18;
    public static final int GOD_MODE_ACTIVE = 1 << 19;
    public static final int GOD_NOCLIP_ACTIVE = 1 << 20;

    public static final class_8710.class_9154<PowerStatusPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(Glungus.MOD_ID, "power_status"));
    public static final class_9139<class_9129, PowerStatusPayload> CODEC = class_9139.method_64265(
            class_9135.field_48550,
            PowerStatusPayload::flags,
            class_9135.field_48550,
            PowerStatusPayload::beamCooldown,
            class_9135.field_48550,
            PowerStatusPayload::snowballCooldown,
            class_9135.field_48550,
            PowerStatusPayload::ultimateCooldown,
            class_9135.field_48550,
            PowerStatusPayload::possessedMobId,
            class_9135.field_48552,
            PowerStatusPayload::cameraOffsetY,
            class_9135.field_48550,
            PowerStatusPayload::slotIndex,
            PowerStatusPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}